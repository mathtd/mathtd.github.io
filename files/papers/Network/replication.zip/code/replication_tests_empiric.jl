 # This script tests the solution approach
# This code was built for Julia 0.6.4

# Add processors for parallel computing
# if Sys.KERNEL==:Linux
#     addprocs(16)
# else
#     addprocs(4)
# end

addprocs(60)

@everywhere using Distributions
@everywhere using Base.Iterators
@everywhere using GLM

@everywhere include("src/creation_network.jl")
@everywhere include("src/solutions_hetero.jl")
@everywhere include("src/testing_small.jl")
@everywhere include("src/analysis_stats.jl")


# Define parameters of the simulation

nb_sim_per_trials = 300

# f, ϵ, α, β and Ω are drawn from uniform distribution with the following bounds

f_lb = 0.05
f_ub = 0.05

ϵ_lb = 5
ϵ_ub = 5

α_lb = 0.5
α_ub = 0.5

β_lb = 1.0
β_ub = 1.0

Ω_lb = 1.0
Ω_ub = 1.0


std_z_vec = [0.39]

# Replicate Table 1 in the paper

σ_vec = [5]

@everywhere shape = 1.79    # Power law coefficient for distribution of potential connection
@everywhere correl = true   # Allow for correlation between potential firm in-degree and out-degree

# Define a network generator using these parameters
@everywhere network_fct(n_in,seed_in) = scaleFreeNetwork(n_in,seed_in,shape,1,correl)

# network_vec = [zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork]

network_vec = [network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct network_fct]

# network_vec = [zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork zipfNetwork]

# n = 8
# series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)
#
# n = 10
# series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)
#
# n = 12
# series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)
# #
# n = 14
# series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)
#
# n = 16
# series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)
#
# n = 18
# series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 20
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)


# Remove processors if using parallel conputing
rmprocs(workers());
