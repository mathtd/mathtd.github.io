# This file contains plotting tools for ModelNetwork
using Graphs # The original graph has some bug use: https://github.com/mathtd/Graphs.jl
using Iterators
using GLM
using DataFrames
using LightGraphs

include("src/simulations.jl")
include("src/solutions.jl")
include("src/creation_network.jl")
include("src/analysis_stats.jl")
include("src/analysis_graphs.jl")

# Graphviz must be installed with pangocairo which homebrew does not allow. Here is the procedure:

# brew uninstall graphviz
# brew upgrade pango librsvg
#
# cd /tmp
# wget https://graphviz.gitlab.io/pub/graphviz/stable/SOURCES/graphviz.tar.gz
# tar xvfz graphviz.tar.gz
# cd graphviz-2.40.1/
#
# rm -rf /usr/local/lib/graphviz # in case old stuff is there
# ./configure --includedir=/usr/local/include/graphviz --with-pangocairo=yes
# make -j 4 # 4 threads
# make install

# This function plots the simples graphs to explain the model
function plotBasic(active,just_firms)

    Ω = [0 0 0 1 0 0;0 0 0 0 0 1;1 1 0 1 1 1;1 0 1 0 0 0;0 0 1 0 0 1;1 0 1 1 0 0]
    Θ = [1;0;1;1;0;1] # Some active firms

    nnodes = size(Ω, 1)
    nedges = sum(Ω)

    vlist = Array(ExVertex, nnodes)

    if active
        filename = "basic_active"
    else
        filename = "basic_nonactive"
    end

    for i = 1:nnodes
        temp = 1
        vlist[i] = ExVertex(i, "$temp")

        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font><br/> <I>z = $(round(m.z[i],2))</I><br/> <I>q = $(round(m.q[i],2))</I>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font>>"
        vlist[i].attributes["label"] = "<<font POINT-SIZE=\"25\">$i</font>>"

        vlist[i].attributes["font"] = "\"Computer Modern\""
        vlist[i].attributes["fontsize"] = "\"26\""

        vlist[i].attributes["height"] = "\"0.8\""
        vlist[i].attributes["width"] = "\"0.8\""
        vlist[i].attributes["penwidth"] = "\"2.25\""

        if Θ[i] == 0 || ~active || just_firms
            vlist[i].attributes["color"] = "\"#949494\""
            vlist[i].attributes["fontcolor"] = "\"#949494\""
            vlist[i].attributes["style"] = "\"dashed\""
        else
            vlist[i].attributes["color"] = "\"#377EB8\""
            vlist[i].attributes["fontcolor"] = "\"#377EB8\""
        end
    end


    ecounter = 1
    elist = Array(ExEdge{typeof(vlist[1])}, nedges)
    for i = 1:nnodes
        for j = 1:nnodes
            if i != j

                # Start with the dead edges

                if just_firms
                    if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0)) || (Ω[i,j] == 1 && ~active)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"16\"> Ω<SUB>$i$j</SUB></font>>"
                        elist[ecounter].attributes["font"] = "\"Computer Modern\""
                        elist[ecounter].attributes["color"] = "\"white\""
                        elist[ecounter].attributes["fontcolor"] = "\"white\""
                        elist[ecounter].attributes["style"] = "\"dashed\""
                        ecounter += 1
                    end

                else


                    if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0)) || (Ω[i,j] == 1 && ~active)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"16\"> Ω<SUB>$i$j</SUB></font>>"

                        elist[ecounter].attributes["color"] = "\"#949494\""
                        elist[ecounter].attributes["fontcolor"] = "\"#949494\""
                        elist[ecounter].attributes["font"] = "\"Computer Modern\""
                        elist[ecounter].attributes["style"] = "\"dashed\""
                        ecounter += 1
                    elseif (Ω[i,j] == 1 && Θ[i] == 1 && Θ[j] == 1)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"16\"> Ω<SUB>$i$j</SUB></font>>"
                        elist[ecounter].attributes["font"] = "\"Computer Modern\""
                        # elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"26\"> Ω<SUB>71</SUB></font>>"
                        elist[ecounter].attributes["fontcolor"] = "\"#377EB8\""
                        elist[ecounter].attributes["color"] = "\"#377EB8\""
                        ecounter += 1
                    end
                end

            end
        end
    end


    g = graph(vlist, elist, is_directed = true)

    # Save dot output
    # Use this dict with neato
    # att_dict = AttributeDict("size"=>"\"1.25,1.25\"","ratio"=>"\"fill\"","dpi" => "\"500\"")
    att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"")


    cd("example_plots")

    f = open("$filename.txt","w")
    write(f,to_dot(g,att_dict))
    # write(f,to_dot(g))
    close(f)

    # Compile dot output into image
    # run(`fdp -Tdot $filename.txt -o $filename.pos.txt`)
    run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(`rm $filename.txt`)
    # run(`rm $filename.pos.txt`)
    # run(`dot -Tpng:quartz:quartz -o $filename.png $filename.txt`)
    # run(`dot -Txdot -o $filename.dot $filename.txt`)
    # run(`dot -Teps -o $filename.eps $filename.txt`)

    cd("..")
    # run(`neato -Tpng -o $filename.png $filename.txt`)
    # Commands to print in IJulia
    # GraphViz(to_dot(g), "circo", "svg")
    # GraphViz(to_dot(g), "dot", "svg")

end

# This function adds a link to the graph
function plotBasicLink()

    Ω = [0 0 0 1 0 0;0 0 0 0 0 1;1 1 0 1 1 1;1 0 1 0 0 0;0 0 1 0 0 1;1 0 1 1 0 0]
    Θ = [1;0;1;1;0;1]

    nnodes = size(Ω, 1)
    nedges = sum(Ω)

    vlist = Array(ExVertex, nnodes+1)

    active = true
    just_firms = false
    filename = "basic_link"

    for i = 1:nnodes
        temp = 1
        vlist[i] = ExVertex(i, "$temp")

        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font><br/> <I>z = $(round(m.z[i],2))</I><br/> <I>q = $(round(m.q[i],2))</I>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font>>"
        vlist[i].attributes["label"] = "<<font POINT-SIZE=\"30\">$i</font>>"

        vlist[i].attributes["font"] = "\"Computer Modern\""
        vlist[i].attributes["fontsize"] = "\"26\""

        vlist[i].attributes["height"] = "\"0.8\""
        vlist[i].attributes["width"] = "\"0.8\""
        vlist[i].attributes["penwidth"] = "\"2.25\""

        if Θ[i] == 0 || ~active || just_firms
            vlist[i].attributes["color"] = "\"#949494\""
            vlist[i].attributes["fontcolor"] = "\"#949494\""
            vlist[i].attributes["style"] = "\"dashed\""
        else
            vlist[i].attributes["color"] = "\"#377EB8\""
            vlist[i].attributes["fontcolor"] = "\"#377EB8\""
        end
    end

    vlist[7] = ExVertex(7, "7")
    vlist[7].attributes["label"] = "<<font POINT-SIZE=\"30\">7</font>>"

    vlist[7].attributes["font"] = "\"Computer Modern\""
    vlist[7].attributes["fontsize"] = "\"26\""

    vlist[7].attributes["height"] = "\"0.8\""
    vlist[7].attributes["width"] = "\"0.8\""
    vlist[7].attributes["penwidth"] = "\"2.25\""
    vlist[7].attributes["color"] = "\"#e41a1c\""


    ecounter = 1
    elist = Array(ExEdge{typeof(vlist[1])}, nedges)
    for i = 1:nnodes
        for j = 1:nnodes
            if i != j

                # Start with the dead edges

                if just_firms
                    if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0)) || (Ω[i,j] == 1 && ~active)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"26\"> Ω<SUB>$i$j</SUB></font>>"

                        elist[ecounter].attributes["color"] = "\"white\""
                        elist[ecounter].attributes["fontcolor"] = "\"white\""
                        elist[ecounter].attributes["style"] = "\"dashed\""
                        ecounter += 1
                    end

                else


                    if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0)) || (Ω[i,j] == 1 && ~active)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"26\"> Ω<SUB>$i$j</SUB></font>>"

                        elist[ecounter].attributes["color"] = "\"#949494\""
                        elist[ecounter].attributes["fontcolor"] = "\"#949494\""
                        elist[ecounter].attributes["style"] = "\"dashed\""
                        ecounter += 1
                    elseif (Ω[i,j] == 1 && Θ[i] == 1 && Θ[j] == 1)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"26\"> Ω<SUB>$i$j</SUB></font>>"
                        elist[ecounter].attributes["fontcolor"] = "\"#377EB8\""
                        elist[ecounter].attributes["color"] = "\"#377EB8\""

                        if i == 6 && j ==1
                            # elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"26\"> Ω<SUB>71</SUB></font>>"
                            elist[ecounter].attributes["label"] = "<<font POINT-SIZE=\"26\"> Ω<SUB>71</SUB>  Ω<SUB>67</SUB></font>>"
                            elist[ecounter].attributes["fontcolor"] = "\"#e41a1c\""
                            elist[ecounter].attributes["color"] = "\"#e41a1c\""
                        end


                        ecounter += 1
                    end
                end

            end
        end
    end


    g = graph(vlist, elist, is_directed = true)

    # Save dot output
    # Use this dict with neato
    # att_dict = AttributeDict("size"=>"\"1.25,1.25\"","ratio"=>"\"fill\"","dpi" => "\"500\"")
    att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"")


    cd("example_plots")

    f = open("$filename.txt","w")
    write(f,to_dot(g,att_dict))
    # write(f,to_dot(g))
    close(f)

    # Compile dot output into image
    # run(`fdp -Tdot $filename.txt -o $filename.pos.txt`)
    run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(`rm $filename.txt`)
    # run(`dot -Txdot -o $filename.dot $filename.txt`)
    # run(`dot -Teps -o $filename.eps $filename.txt`)

    cd("..")
    # run(`neato -Tpng -o $filename.png $filename.txt`)
    # Commands to print in IJulia
    # GraphViz(to_dot(g), "circo", "svg")
    # GraphViz(to_dot(g), "dot", "svg")

end



function plotCluster(step)


    n = 10

    Ω = falses(n,n)

    for i=1:5
        for j=1:5
            if i!=j
                Ω[i,j] = true
            end
        end
    end

    for i=6:10
        for j=6:10
            if i!=j
                Ω[i,j] = true
            end
        end
    end

    Ω[1,6] = true
    Ω[6,1] = true

    if step == 1
        # First sim
        z = [1.03;1.04;0.94;1.00;0.92;1.03;1.26;0.80;1.05;1.04]
        filename = "cluster1"
    elseif step == 2

        # Second sim
        z = [1.13;0.78;1.23;0.91;0.99;0.86;1.01;1.00;1.11;1.09]
        filename = "cluster2"

    elseif step == 3

        # Third sim
        z = [1.03;0.78;1.23;0.91;0.99;0.86;1.01;1.00;1.11;1.09]
        filename = "discont3"
        #
    elseif step ==4
        z = [1.02;0.78;1.23;0.91;0.99;0.86;1.01;1.00;1.11;1.09]
        filename = "discont4"
    end

    param = Parameters(10,0.4/10,0.0,0.0,6.0,6.0,0.5,sparse(Ω))

    Θ = solveExhaustive(param,z,true)
    q = zeros(n)

    println(Θ)

    nnodes = size(Ω, 1)
    nedges = sum(Ω)

    vlist = Array(ExVertex, nnodes)

    active = true
    just_firms = false


    vlist = Array(ExVertex, nnodes)
    for i = 1:nnodes
        temp = z[i]
        vlist[i] = ExVertex(i, "$temp")

        if Θ[i] == 0

            vlist[i].attributes["color"] = "\"#949494\""
            vlist[i].attributes["style"] = "\"dashed\""
        else

            # vlist[i].attributes["height"] = "\"$(max(m.q[i]*2,1.75))\""
            # vlist[i].attributes["width"] = "\"$(max(m.q[i]*2,1.75))\""
            # vlist[i].attributes["penwidth"] = "\"$(max(m.q[i]*5,1.5))\""
            vlist[i].attributes["color"] = "\"#377EB8\""
            # vlist[i].attributes["fontsize"] = "\"$(max((m.y[i]-mean_y)/std_y * 4 + 18.0,14.0))\""
        end

        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font><br/> <I>z = $(@sprintf("%0.2f",z[i]))</I><br/> <I>q = $(@sprintf("%0.2f",q[i]))</I>>"

        if filename == "discont3" && i == 1
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$i</B></font><br/> <I>z = 1 + ε</I>>"
            # vlist[i].attributes["label"] = "<<I>z = 1.03+ε</I>>"
            vlist[i].attributes["label"] = "<<I>z' = z+ε</I>>"
            vlist[i].attributes["color"] = "\"#e41a1c\""
        elseif filename == "discont4" && i == 1
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$i</B></font><br/> <I>z = 1.03 - ε</I>>"
            # vlist[i].attributes["label"] = "<<I>z = 1.03-ε</I>>"
            vlist[i].attributes["label"] = "<<I>z' = z−ε</I>>"
            vlist[i].attributes["color"] = "\"#e41a1c\""
        else
            vlist[i].attributes["label"] = "<<I>z = $(@sprintf("%0.2f",z[i]))</I>>"
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$i</B></font><br/> <I>z = $(@sprintf("%0.2f",z[i]))</I>>"
        end
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$i</B></font><br/> <font POINT-SIZE=\"24\"><I>z = $(@sprintf("%0.2f",z[i]))</I></font>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><I>z = $(@sprintf("%0.2f",z[i]))</I></font>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"28\"><B>$i</B></font>>"

        vlist[i].attributes["font"] = "\"Computer Modern\""
        vlist[i].attributes["fontsize"] = "\"20\""
        vlist[i].attributes["shape"] = "\"circle\""

        vlist[i].attributes["height"] = "\"1.0\""
        vlist[i].attributes["width"] = "\"1.0\""
        vlist[i].attributes["penwidth"] = "\"2.25\""


    end


    ecounter = 1
    elist = Array(ExEdge{typeof(vlist[1])}, nedges)
    for i = 1:nnodes
        for j = 1:nnodes
            if i != j



                # Start with the dead edges
                if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0))
                    elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                    elist[ecounter].attributes["penwidth"] = "\"1.2\""
                    elist[ecounter].attributes["color"] = "\"#949494\""
                    elist[ecounter].attributes["style"] = "\"dashed\""
                    ecounter += 1
                elseif (Ω[i,j] == 1 && Θ[i] == 1 && Θ[j] == 1)
                    elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                    elist[ecounter].attributes["penwidth"] = "\"1.2\""
                    elist[ecounter].attributes["color"] = "\"#377EB8\""
                    ecounter += 1
                end

                if (i==1 && j==6) || (i==6 && j==1)
                    elist[ecounter-1].attributes["len"] = "\"0.7\""
                #     # elist[ecounter-1].attributes["weight"] = "\"10000\""
                #     # elist[ecounter-1].attributes["constraint"] = "\"false\""
                end

            end
        end
    end


    g = graph(vlist, elist, is_directed = true)

    # Save dot output
    # Use this dict with neato
    # att_dict = AttributeDict("size"=>"\"1.25,1.25\"","ratio"=>"\"fill\"","dpi" => "\"500\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"")
    # att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"2000\"","maxiter" => "\"10000000\"","startType" => "\"23\"")
    att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"2000\"","maxiter" => "\"10000000\"")
    # att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"","overlap" => "\"false\"","K" => "\"0.4\"")

    cd("example_plots")

    f = open("$filename.txt","w")
    write(f,to_dot(g,att_dict))
    # write(f,to_dot(g))
    close(f)

    # Compile dot output into image
    # run(`fdp -Tdot $filename.txt -o $filename.pos.txt`)
    # run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(`dot -Kfdp -n -Tpng:cairo -o $filename.png $filename.txt`)
    run(`rm $filename.txt`)

    # run(`dot -Kneato -Tpng:cairo -o $filename.png $filename.txt`)
    # run(`neato -Tpng -o $filename.png $filename.txt`)

    # run(`dot -Txdot -o $filename.dot $filename.txt`)
    # run(`dot -Teps -o $filename.eps $filename.txt`)

    cd("..")
    # run(`neato -Tpng -o $filename.png $filename.txt`)
    # Commands to print in IJulia
    # GraphViz(to_dot(g), "circo", "svg")
    # GraphViz(to_dot(g), "dot", "svg")

end


function plotChangeParam(σ,ϵ)

    seed = 1
    srand(seed)

    # n = 10
    #
    # Ω = zeros(Bool,n,n)
    #
    # Ω[1,2] = true
    # Ω[1,6] = true
    # Ω[1,7] = true
    # Ω[2,1] = true
    # Ω[2,10] = true
    # Ω[3,1] = true
    # Ω[4,1] = true
    # Ω[5,9] = true
    # Ω[5,1] = true
    # Ω[6,8] = true
    # Ω[7,8] = true
    # Ω[9,7] = true
    # Ω[10,3] = true
    # Ω[10,4] = true
    # Ω[10,5] = true
    #
    #
    # f = 0.45/n
    #
    # filename = "chang_param_s$(σ)_e$(ϵ)"
    #
    # param = Parameters(n,f,0.0,0.0,σ,ϵ,0.5,sparse(Ω))
    #
    # z = max.(randn(n)*0.3+1.0,0.0)
    # z[1] = 1.3
    # z[2] = 1.3
    # z[3] = 1.1
    # z[4] = 1.1
    # z[10] = 1.0
    # z[8] = 1.1
    #
    # z[7] = 1

    n = 8

    Ω = zeros(Bool,n,n)

    Ω[1,2] = true
    Ω[1,6] = true
    Ω[1,7] = true
    Ω[2,1] = true
    Ω[2,5] = true
    Ω[3,1] = true
    Ω[4,1] = true
    Ω[5,1] = true
    Ω[6,8] = true
    Ω[7,8] = true
    Ω[5,3] = true
    Ω[5,4] = true


    f = 0.45/n

    filename = "chang_param_s$(σ)_e$(ϵ)"

    param = Parameters(n,f,0.0,0.0,σ,ϵ,0.5,sparse(Ω))

    z = max.(randn(n)*0.3+1.0,0.0)
    z[1] = 1.3
    z[2] = 1.3
    z[3] = 1.1
    z[4] = 1.1
    z[5] = 1.0
    z[6] = 1.1
    z[7] = 1.1
    z[8] = 1.2




    Θ = solveExhaustive(param,z,true)
    q = zeros(n)

    println(Θ)

    nnodes = size(Ω, 1)
    nedges = sum(Ω)

    vlist = Array(ExVertex, nnodes)

    active = true
    just_firms = false


    vlist = Array(ExVertex, nnodes)
    for i = 1:nnodes
        temp = z[i]
        vlist[i] = ExVertex(i, "$temp")

        if Θ[i] == 0

            vlist[i].attributes["color"] = "\"#949494\""
            vlist[i].attributes["style"] = "\"dashed\""
        else

            # vlist[i].attributes["height"] = "\"$(max(m.q[i]*2,1.75))\""
            # vlist[i].attributes["width"] = "\"$(max(m.q[i]*2,1.75))\""
            # vlist[i].attributes["penwidth"] = "\"$(max(m.q[i]*5,1.5))\""
            vlist[i].attributes["color"] = "\"#377EB8\""
            # vlist[i].attributes["fontsize"] = "\"$(max((m.y[i]-mean_y)/std_y * 4 + 18.0,14.0))\""
        end



        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font><br/> <I>z = $(@sprintf("%0.2f",z[i]))</I><br/> <I>q = $(@sprintf("%0.2f",q[i]))</I>>"


        # vlist[i].attributes["label"] = "<<I>z = $(@sprintf("%0.2f",z[i]))</I>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"10\">$i</font>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"15\"><B>$i</B></font><br/> <I>z = $(@sprintf("%0.2f",z[i]))</I>>"
        vlist[i].attributes["label"] = "<<font POINT-SIZE=\"15\"><B>$i</B></font><br/> <I>z = $(@sprintf("%0.1f",z[i]))</I>>"

        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$i</B></font><br/> <font POINT-SIZE=\"24\"><I>z = $(@sprintf("%0.2f",z[i]))</I></font>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><I>z = $(@sprintf("%0.2f",z[i]))</I></font>>"
        # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"28\"><B>$i</B></font>>"

        vlist[i].attributes["font"] = "\"Computer Modern\""
        vlist[i].attributes["fontsize"] = "\"15\""
        vlist[i].attributes["shape"] = "\"circle\""

        vlist[i].attributes["height"] = "\"1.0\""
        vlist[i].attributes["width"] = "\"1.0\""
        vlist[i].attributes["penwidth"] = "\"2.25\""


    end


    ecounter = 1
    elist = Array(ExEdge{typeof(vlist[1])}, nedges)
    for i = 1:nnodes
        for j = 1:nnodes
            if i != j
                # Start with the dead edges
                if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0))
                    elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                    elist[ecounter].attributes["penwidth"] = "\"1.2\""
                    elist[ecounter].attributes["color"] = "\"#949494\""
                    elist[ecounter].attributes["style"] = "\"dashed\""
                    ecounter += 1
                elseif (Ω[i,j] == 1 && Θ[i] == 1 && Θ[j] == 1)
                    elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                    elist[ecounter].attributes["penwidth"] = "\"1.2\""
                    elist[ecounter].attributes["color"] = "\"#377EB8\""
                    ecounter += 1
                end
            end
        end
    end

    g = graph(vlist, elist, is_directed = true)

    # Save dot output
    # Use this dict with neato
    # att_dict = AttributeDict("size"=>"\"1.25,1.25\"","ratio"=>"\"fill\"","dpi" => "\"500\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","K" => "\"0.8\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"","root" => "\"1\"")
    att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"","root" => "\"1\"","K" => "\"0.8\"")
    # att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"2000\"","maxiter" => "\"10000000\"","startType" => "\"23\"")
    # att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"2000\"","maxiter" => "\"10000000\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"","overlap" => "\"false\"","K" => "\"0.4\"")

    cd("example_plots")

    f = open("$filename.txt","w")
    write(f,to_dot(g,att_dict))
    write(f,to_dot(g))
    close(f)

    # Compile dot output into image
    # run(`fdp -Tdot $filename.txt -o $filename.pos.txt`)
    # run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(`dot -Kfdp -n -Tpng:cairo -o $filename.png $filename.txt`)
    # run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(`rm $filename.txt`)

    # run(`dot -Kneato -Tpng:cairo -o $filename.png $filename.txt`)
    # run(`neato -Tpng -o $filename.png $filename.txt`)

    # run(`dot -Txdot -o $filename.dot $filename.txt`)
    # run(`dot -Teps -o $filename.eps $filename.txt`)

    cd("..")
    # run(`neato -Tpng -o $filename.png $filename.txt`)
    # Commands to print in IJulia
    # GraphViz(to_dot(g), "circo", "svg")
    # GraphViz(to_dot(g), "dot", "svg")

end


function plotBCcorrel(recession)
    # Build a figure to explain correlation between BC and network
    seed = 1
    srand(seed)

    # More details on graphs but less pretty
    debug = false

    # n = 50
    # #
    # Ω = zipfNetwork(n,seed)

    n = 18

    Ω = zeros(Bool,n,n)

    Ω[1,2] = true
    Ω[1,3] = true
    Ω[1,6] = true
    Ω[1,14] = true
    Ω[1,8] = true
    Ω[2,1] = true
    Ω[2,9] = true
    Ω[2,8] = true
    Ω[2,10] = true
    Ω[2,13] = true
    Ω[3,1] = true
    Ω[3,4] = true
    Ω[4,10] = true
    Ω[5,1] = true
    Ω[5,6] = true
    Ω[6,5] = true
    Ω[6,7] = true
    Ω[7,6] = true
    Ω[8,2] = true
    Ω[8,9] = true
    Ω[9,2] = true
    Ω[9,8] = true
    Ω[10,2] = true
    Ω[10,4] = true

    Ω[11,5] = true
    Ω[11,1] = true
    Ω[6,11] = true
    Ω[8,11] = true

    Ω[12,3] = true
    Ω[7,12] = true
    Ω[4,12] = true

    Ω[13,9] = true
    Ω[13,10] = true
    Ω[13,2] = true
    Ω[9,13] = true

    Ω[14,1] = true
    Ω[14,2] = true
    Ω[10,14] = true

    Ω[15,8] = true
    Ω[15,5] = true
    # Ω[1,15] = true
    # Ω[15,1] = true
    Ω[8,15] = true

    Ω[6,16] = true
    Ω[16,18] = true
    Ω[16,6] = true

    Ω[12,17] = true
    Ω[15,18] = true

    f = 0.20/n

    if recession
        filename = "BC_correl_bust"
    else
        filename = "BC_correl_boom"
    end

    σ = 5
    ϵ = 5

    param = Parameters(n,f,0.0,0.0,σ,ϵ,0.5,sparse(Ω))


    # param = Parameters_hetero(n,f*ones(n),0.0,0.0,σ,ϵ*ones(n),0.5*ones(n),ones(n),sparse(Ω))

    z = max.(randn(n)*0.3+1.0,0.0)
    z[13] = 0.998
    z[3]=1.9

    # z[5]=0.85
    z[14]=1.3
    z[16]=1.6
    z[4]=1.05
    z[12]=0.6
    z[8]=1.3

    # C = 2.968062036910292
    # cluster = 0.15
    # indeg_alpha = 1.6371192545332398
    # outdeg_alpha = 1.6371192545332398
    # [1.0, 2.0, 3.0]
    # [0.5, 0.2, 0.1]

    if recession
        z[1]=0.6
        z[2]=0.6
        z[17]=1.2
        z[18]=1.2
        z[5]=1.2
        z[12]=1.2
        z[3]=0.9
    end

    # C = 3.255551857530786
    # cluster = 0.2727272727272727
    # indeg_alpha = 1.9368679636376207
    # outdeg_alpha = 1.4966532488665918
    # [1.0, 2.0]
    # [0.25, 0.125]



    # Θ,flag = foc_iterations(param,z)
    Θ = solveExhaustive(param,z,true)
    q = solveq(param,z,Θ,true)

    Q = (sum(1.*q.^(σ-1)))^(1/(σ-1))
    C = (1.0-sum(f.*Θ))*Q

    nnodes = size(Ω, 1)
    nedges = sum(Ω)

    vlist = Array(ExVertex, nnodes)

    active = true
    just_firms = false


    if debug

        # vlist = Array(ExVertex, nnodes)
        for i = 1:nnodes
            temp = z[i]
            vlist[i] = ExVertex(i, "$temp")

            if Θ[i] == 0

                vlist[i].attributes["color"] = "\"#949494\""
                vlist[i].attributes["style"] = "\"dashed\""
            else

                # vlist[i].attributes["height"] = "\"$(max(m.q[i]*2,1.75))\""
                # vlist[i].attributes["width"] = "\"$(max(m.q[i]*2,1.75))\""
                # vlist[i].attributes["penwidth"] = "\"$(max(m.q[i]*5,1.5))\""
                vlist[i].attributes["color"] = "\"#377EB8\""
                # vlist[i].attributes["fontsize"] = "\"$(max((m.y[i]-mean_y)/std_y * 4 + 18.0,14.0))\""
            end



            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$(Char(i+64))</B></font><br/> <I>z = $(@sprintf("%0.2f",z[i]))</I><br/> <I>q = $(@sprintf("%0.2f",q[i]))</I>>"


            # vlist[i].attributes["label"] = "<<I>z = $(@sprintf("%0.2f",z[i]))</I>>"
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"10\">$i</font>>"
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"15\"><B>$i</B></font><br/> <I>z = $(@sprintf("%0.2f",z[i]))</I>>"
            vlist[i].attributes["label"] = "<<font POINT-SIZE=\"15\"><B>$i</B></font><br/> <I>z = $(@sprintf("%0.1f",z[i]))</I>>"

            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><B>$i</B></font><br/> <font POINT-SIZE=\"24\"><I>z = $(@sprintf("%0.2f",z[i]))</I></font>>"
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"26\"><I>z = $(@sprintf("%0.2f",z[i]))</I></font>>"
            # vlist[i].attributes["label"] = "<<font POINT-SIZE=\"28\"><B>$i</B></font>>"

            vlist[i].attributes["font"] = "\"Computer Modern\""
            vlist[i].attributes["fontsize"] = "\"15\""
            vlist[i].attributes["shape"] = "\"circle\""

            vlist[i].attributes["height"] = "\"1.0\""
            vlist[i].attributes["width"] = "\"1.0\""
            vlist[i].attributes["penwidth"] = "\"2.25\""


        end


        ecounter = 1
        elist = Array(ExEdge{typeof(vlist[1])}, nedges)
        for i = 1:nnodes
            for j = 1:nnodes
                if i != j
                    # Start with the dead edges
                    if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0))
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["color"] = "\"#949494\""
                        elist[ecounter].attributes["style"] = "\"dashed\""
                        ecounter += 1
                    elseif (Ω[i,j] == 1 && Θ[i] == 1 && Θ[j] == 1)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["color"] = "\"#377EB8\""
                        ecounter += 1
                    end
                end
            end
        end

    else

        for i = 1:nnodes
            temp = 1
            vlist[i] = ExVertex(i, "$temp")
            vlist[i].attributes["label"] = "<<font POINT-SIZE=\"25\">$i</font>>"

            vlist[i].attributes["font"] = "\"Computer Modern\""
            vlist[i].attributes["fontsize"] = "\"26\""

            vlist[i].attributes["height"] = "\"0.8\""
            vlist[i].attributes["width"] = "\"0.8\""
            vlist[i].attributes["penwidth"] = "\"2.25\""

            if Θ[i] == 0 || ~active || just_firms
                vlist[i].attributes["color"] = "\"#949494\""
                vlist[i].attributes["fontcolor"] = "\"#949494\""
                vlist[i].attributes["style"] = "\"dashed\""
            else
                vlist[i].attributes["color"] = "\"#377EB8\""
                vlist[i].attributes["fontcolor"] = "\"#377EB8\""
            end
        end


        ecounter = 1
        elist = Array(ExEdge{typeof(vlist[1])}, nedges)
        for i = 1:nnodes
            for j = 1:nnodes
                if i != j
                    # Start with the dead edges
                    if (Ω[i,j] == 1 && (Θ[i] == 0 || Θ[j] == 0))
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["color"] = "\"#949494\""
                        elist[ecounter].attributes["style"] = "\"dashed\""
                        ecounter += 1
                    elseif (Ω[i,j] == 1 && Θ[i] == 1 && Θ[j] == 1)
                        elist[ecounter] = ExEdge(ecounter, vlist[i], vlist[j])
                        elist[ecounter].attributes["penwidth"] = "\"1.2\""
                        elist[ecounter].attributes["color"] = "\"#377EB8\""
                        ecounter += 1
                    end
                end
            end
        end
    end

    g = graph(vlist, elist, is_directed = true)

    # Save dot output
    # Use this dict with neato
    # att_dict = AttributeDict("size"=>"\"1.25,1.25\"","ratio"=>"\"fill\"","dpi" => "\"500\"")
    att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"1000000\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"","root" => "\"1\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"")
    # att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"2000\"","maxiter" => "\"10000000\"","startType" => "\"23\"")
    # att_dict = AttributeDict("size"=>"\"0.5,0.75\"","dpi" => "\"2000\"","maxiter" => "\"10000000\"")
    # att_dict = AttributeDict("size"=>"\"1.0,1.0\"","dpi" => "\"1000\"","maxiter" => "\"10000000\"","overlap" => "\"false\"","K" => "\"0.4\"")

    cd("example_plots")

    f = open("$filename.txt","w")
    write(f,to_dot(g,att_dict))
    write(f,to_dot(g))
    close(f)

    # Compile dot output into image
    # run(`fdp -Tdot $filename.txt -o $filename.pos.txt`)
    # run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(pipeline(`dot -Kfdp -n -Tpng:cairo -o $filename.png $filename.txt`,"temp.tmp"))

    # run(`dot -Tpng:cairo -o $filename.png $filename.txt`)
    run(pipeline(`rm $filename.txt`,"temp.tmp"))

    # run(`dot -Kneato -Tpng:cairo -o $filename.png $filename.txt`)
    # run(`neato -Tpng -o $filename.png $filename.txt`)

    # run(`dot -Txdot -o $filename.dot $filename.txt`)
    # run(`dot -Teps -o $filename.eps $filename.txt`)


    # run(`neato -Tpng -o $filename.png $filename.txt`)
    # Commands to print in IJulia
    # GraphViz(to_dot(g), "circo", "svg")
    # GraphViz(to_dot(g), "dot", "svg")


    g = LightGraphs.DiGraph(build_active_network_matrix(Ω,BitArray(Θ)))
    x_in,y_in,x_out,y_out = degree_distributions(g,true)
    cluster = custom_clustering_coefficient(g)



    indeg_alpha = pareto_alpha_estimate_only_pos(indegree(g),1.0)
    outdeg_alpha = pareto_alpha_estimate_only_pos(outdegree(g),1.0)

    println()
    if recession
        println("Bust")
        writedlm("BC_correl_bust_indeg",[x_in y_in])
        writedlm("BC_correl_bust_outdeg",[x_out y_out])
    else
        println("Boom")
        writedlm("BC_correl_boom_indeg",[x_in y_in])
        writedlm("BC_correl_boom_outdeg",[x_out y_out])
    end

    println("C = $C")
    println("cluster = $cluster")
    println("indeg_alpha = $indeg_alpha")
    println("outdeg_alpha = $outdeg_alpha")

    println(x_in)
    println(y_in)

    println(x_out)
    println(y_out)
    cd("..")

end

plotBasic(true,false)
plotBasic(false,false)
plotBasicLink()
plotCluster(1)
plotCluster(2)
plotCluster(3)
plotCluster(4)

plotChangeParam(10.0,10.0)
plotChangeParam(3.0,10.0)
plotChangeParam(10.0,3.0)
plotChangeParam(3.0,3.0)

plotBCcorrel(false)
plotBCcorrel(true)
