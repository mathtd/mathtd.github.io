# Compare to solution.jl algorithms

# using LightGraphs
# Compares the performance of two functions f1 and f2
function test(f1::Function,f2::Function,trials,n,seed,σ,std_z,network,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,mute)

    # Vectors to store results
    theta_identical_reshape = falses(trials)
    fraction_discr_theta_reshape = ones(trials)
    C_diff_reshape = ones(trials)
    error_solution_reshape = falses(trials)
    sum_theta_reshape = zeros(trials)
    fraction_theta_non_convergence_01_reshape = zeros(trials)

    theta_identical_noreshape = falses(trials)
    fraction_discr_theta_noreshape = ones(trials)
    C_diff_noreshape = ones(trials)
    error_solution_noreshape = falses(trials)
    sum_theta_noreshape = zeros(trials)
    fraction_theta_non_convergence_01_noreshape = zeros(trials)


    # @sync @parallel for trial in 1:trials
    for trial in 1:trials

        # Draw relevant variables for all firms
        srand(seed+trial)

        repeat_draw = true # Dummy to repeat the draw if pathological
        nb_draw = 0

        while repeat_draw
            nb_draw = nb_draw + 1
            repeat_draw = false

            f = rand(n) * (f_ub - f_lb) + f_lb
            ϵ = rand(n) * (ϵ_ub - ϵ_lb) + ϵ_lb
            α = rand(n) * (α_ub - α_lb) + α_lb
            β = rand(n) * (β_ub - β_lb) + β_lb

            z = exp.(rand(Normal(0.0, std_z),n))

            Ω = full(network(n,seed+trial*nb_draw*100000))
            Ω = Ω.*(rand(n,n)*(Ω_ub-Ω_lb)+Ω_lb)

            param = Parameters_hetero(n,f/n,std_z,0,σ,ϵ,α,β,Ω)

            L = 1

            # Solve the model using the exhaustive search
            Θ1 = f1(param,z,true)
            q1 = solveq(param,z,Θ1,mute)
            Q1 = (sum(β.*q1.^(σ-1)))^(1/(σ-1))
            C1 = (L-sum(f/n.*Θ1))*Q1

            # Solve the model using reshaping algorithm
            Θ2_reshape,flag_error_reshape,nb_non_converged_theta_reshape = f2(param,z,true,true,ones(n)./(σ-1),1-(ϵ-1)/(σ-1))
            q2_reshape = solveq(param,z,Θ2_reshape,mute)
            Q2_reshape = (sum(β.*q2_reshape.^(σ-1)))^(1/(σ-1))
            C2_reshape = (L-sum(f/n.*Θ2_reshape))*Q2_reshape


            # Compute difference in consumption
            C_diff_reshape[trial] = abs((C2_reshape-C1)/C1)

            if C2_reshape == 0.0
                # Pathological case with division by 0, exclude
                repeat_draw = true
            end

            fraction_discr_theta_reshape[trial] = sum(abs.(Θ1-Θ2_reshape))/n
            fraction_theta_non_convergence_01_reshape[trial] = nb_non_converged_theta_reshape/n


            if Θ1 == Θ2_reshape
                theta_identical_reshape[trial] = true
            end

            error_solution_reshape[trial] = false

            if flag_error_reshape
                # The FOC did not converge to {0,1}
                if ~mute; println("Error in trial reshape $trial"); end
                error_solution_reshape[trial] = true
            end

            if !flag_error_reshape && C2_reshape>C1
                error("higher consumption in foc_iterations reshape")
            end

            # Deal with simulation under no reshaping now

            Θ2_noreshape,flag_error_noreshape,nb_non_converged_theta_noreshape = f2(param,z,true,false,ones(n),zeros(n))

            q2_noreshape = solveq(param,z,Θ2_noreshape,mute)
            Q2_noreshape = (sum(β.*q2_noreshape.^(σ-1)))^(1/(σ-1))
            C2_noreshape = (L-sum(f/n.*Θ2_noreshape))*Q2_noreshape
            C_diff_noreshape[trial] = abs((C2_noreshape-C1)/C1)

            if C2_noreshape == 0.0
                # Pathological case with division by 0, exclude
                repeat_draw = true
            end

            fraction_discr_theta_noreshape[trial] = sum(abs.(Θ1-Θ2_noreshape))/n
            fraction_theta_non_convergence_01_noreshape[trial] = nb_non_converged_theta_noreshape/n

            if Θ1 == Θ2_noreshape
                theta_identical_noreshape[trial] = true
            end

            error_solution_noreshape[trial] = false

            if flag_error_noreshape
                if ~mute; println("Error in trial noreshape $trial"); end
                error_solution_noreshape[trial] = true
            end

            if !flag_error_noreshape && C2_noreshape>C1
                error("higher consumption in foc_iterations noreshape")
            end
        end

    end




    return theta_identical_reshape,fraction_discr_theta_reshape,C_diff_reshape,error_solution_reshape,theta_identical_noreshape,fraction_discr_theta_noreshape,C_diff_noreshape,error_solution_noreshape,fraction_theta_non_convergence_01_reshape,fraction_theta_non_convergence_01_noreshape

end


function series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

    combinations = product((1:length(std_z_vec)),(1:length(σ_vec)),(1:length(network_vec)))
    comb_no_iter = collect(combinations)

    nb_trials = length(std_z_vec)*length(σ_vec)*length(network_vec)


    # Use SharedArray to allow parallel computing across trials
    std_z_sh = convert(SharedArray,zeros(Int64,nb_trials,1))
    σ_sh = convert(SharedArray,zeros(Int64,nb_trials,1))
    network_sh = convert(SharedArray,zeros(Int64,nb_trials,1))

    # Build containers for parallel computations
    nb_error_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_sh_reshape_with_error = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    sum_theta_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_theta_non_convergence_01_sh_reshape = convert(SharedArray,zeros(nb_trials,1))

    nb_error_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_sh_noreshape_with_error = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    sum_theta_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_theta_non_convergence_01_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))

    mute = true
    seed = 1

    srand(0)

    @sync @parallel for i = 1:nb_trials
    # for i = 1:nb_trials
        std_z = std_z_vec[comb_no_iter[i][1]]
        σ = σ_vec[comb_no_iter[i][2]]
        network = network_vec[comb_no_iter[i][3]]

        std_z_sh[i] = comb_no_iter[i][1]
        σ_sh[i] = comb_no_iter[i][2]
        network_sh[i] = comb_no_iter[i][3]

        # Shift the seed so that each trial gets different productivity draws
        theta_identical_reshape,fraction_discr_theta_reshape,C_diff_reshape,error_solution_reshape,theta_identical_noreshape,fraction_discr_theta_noreshape,C_diff_noreshape,error_solution_noreshape,fraction_theta_non_convergence_01_reshape,fraction_theta_non_convergence_01_noreshape = test(solveExhaustive,foc_iterations,nb_sim_per_trials,n,seed+n*nb_trials*i,σ,std_z,network,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,mute)


        # the no_err variables refer to cases with FOC convergence
        nb_error_sh_reshape[i] = sum(error_solution_reshape)/nb_sim_per_trials*100
        success_theta_sh_reshape[i] = (sum(theta_identical_reshape)/nb_sim_per_trials*100)
        success_theta_no_err_sh_reshape[i] = sum(theta_identical_reshape .& .~error_solution_reshape)/sum(.~error_solution_reshape)*100
        C_err_sh_reshape[i] = sum(C_diff_reshape)/nb_sim_per_trials*100
        C_err_no_err_sh_reshape[i] = sum(C_diff_reshape.*(.~error_solution_reshape))/sum(.~error_solution_reshape)*100
        fraction_discr_theta_sh_reshape_with_error[i] = sum(fraction_discr_theta_reshape)/nb_sim_per_trials*100
        fraction_discr_theta_no_err_sh_reshape[i] = sum(fraction_discr_theta_reshape[.~error_solution_reshape])/sum(.~error_solution_reshape)*100



        # Without reshaping
        nb_error_sh_noreshape[i] = sum(error_solution_noreshape)/nb_sim_per_trials*100
        success_theta_sh_noreshape[i] = (sum(theta_identical_noreshape)/nb_sim_per_trials*100)
        success_theta_no_err_sh_noreshape[i] = sum(theta_identical_noreshape .& .~error_solution_noreshape)/sum(.~error_solution_noreshape)*100
        C_err_sh_noreshape[i] = sum(C_diff_noreshape)/nb_sim_per_trials*100
        C_err_no_err_sh_noreshape[i] = sum(C_diff_noreshape.*(.~error_solution_noreshape))/sum(.~error_solution_noreshape)*100
        fraction_discr_theta_sh_noreshape_with_error[i] = sum(fraction_discr_theta_noreshape)/nb_sim_per_trials*100
        fraction_discr_theta_no_err_sh_noreshape[i] = sum(fraction_discr_theta_noreshape[.~error_solution_noreshape])/sum(.~error_solution_noreshape)*100


    end

    println(success_theta_no_err_sh_reshape)

    println("")
    println("---------------------------------------------------")
    println("Parameters")
    println("---------------------------------------------------")
    println("    n           = $n")
    println("    network_vec = $network_vec")
    println("    nb_sim      = $nb_sim_per_trials")
    println("")
    println("WITH RESHAPING")
    println("   nb_sim_per_trials = $nb_sim_per_trials")
    println("   % FOC converge on {0,1} $(100-sum(nb_error_sh_reshape)/nb_trials)%")
    println("   % Success over full Θ (all cases) $(sum(success_theta_sh_reshape)/nb_trials)%")
    println("   % Success over full Θ (when FOC converge on {0,1}) $(sum(success_theta_no_err_sh_reshape)/nb_trials)%")
    println("   % Average error in C (all cases) $(sum(C_err_sh_reshape)/nb_trials)%")
    println("   % Average error in C (when FOC converge on {0,1}) $(sum(C_err_no_err_sh_reshape)/nb_trials)%")
    println("   % Success over individual θ (all cases) $(100-sum(fraction_discr_theta_sh_reshape_with_error)/nb_trials)%")
    println("   % Success over individual θ (when FOC converge on {0,1}) $(100-sum(fraction_discr_theta_no_err_sh_reshape)/nb_trials)%")
    println("")
    println("WITHOUT RESHAPING")
    println("   nb_sim_per_trials = $nb_sim_per_trials")
    println("   % FOC converge on {0,1} $(100-sum(nb_error_sh_noreshape)/nb_trials)%")
    println("   % Success over full Θ (all cases) $(sum(success_theta_sh_noreshape)/nb_trials)%")
    println("   % Success over full Θ (when FOC converge on {0,1}) $(sum(success_theta_no_err_sh_noreshape)/nb_trials)%")
    println("   % Average error in C (all cases) $(sum(C_err_sh_noreshape)/nb_trials)%")
    println("   % Average error in C (when FOC converge on {0,1}) $(sum(C_err_no_err_sh_noreshape)/nb_trials)%")
    println("   % Success over individual θ (all cases) $(100-sum(fraction_discr_theta_sh_noreshape_with_error)/nb_trials)%")
    println("   % Success over individual θ (when FOC converge on {0,1}) $(100-sum(fraction_discr_theta_no_err_sh_noreshape)/nb_trials)%")
    println("")
end
