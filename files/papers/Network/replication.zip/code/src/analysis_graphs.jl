# Functions to compute various moments of a graph


function build_active_network_matrix(Ω::Union{AbstractArray{Bool},BitArray},Θ::Union{Array{Bool},BitArray})
    Θ = Θ[:]
    active_Ω = (Θ*Θ').*Ω
    return active_Ω
end



# This function build one LightGraphs.DiGraph for each simul
function build_graph(simul::Simulation,active=true)
    n_simul = simul.n_simul

    array_graphs = Array{DiGraph}(n_simul)

    Ω = simul.param.Ω
    for i = 1:n_simul
        if active
            Θ = simul.Θ_stor[i,:]
            array_graphs[i] = LightGraphs.DiGraph(build_active_network_matrix(Ω,Θ))
        else
            array_graphs[i] = LightGraphs.DiGraph(Ω)
        end
    end

    return array_graphs
end




function build_graph(array_simul::Array{Simulation},active=true)
    nb_seeds = length(array_simul)
    n_simul = array_simul[1].n_simul

    array_networks = Array{DiGraph}(nb_seeds,n_simul)

    for i_seed = 1:nb_seeds
        array_networks[i_seed,:] = build_graph(array_simul[i_seed],active)
    end

    return array_networks
end


# Function to compute global clustering coefficient either normalized or not
# See https://arxiv.org/pdf/1410.1997.pdf for normalization
# The LightGraphs packages computes a weird clustering on directed graph so use undirected graph instead
function custom_clustering_coefficient(g,normalization=false)

    if ~normalization
        # No normalization
        # return LightGraphs.global_clustering_coefficient(g)
        # Use undirected graph
        return LightGraphs.global_clustering_coefficient(LightGraphs.SimpleGraph(g))
    else
        # With normalization
        nb_active_firms = nb_active_firms(g)
        # return LightGraphs.global_clustering_coefficient(g) * sqrt(nb_active_firms)
        # Use undirected graph
        return LightGraphs.global_clustering_coefficient(LightGraphs.SimpleGraph(g)) * sqrt(nb_active_firms)
    end
end

# Return the number of active firms (with at least one neighbor) in graph g
function count_active_firms(g)
    return sum(degree(g).>0)
end



# Build the inverse graphs to measure distance in upstream flows
function build_inverse_graph(g::LightGraphs.DiGraph)
    return reverse!(deepcopy(g))
end

# Build the inverse graphs to measure distance in upstream flows
function build_undirected_graph(g::LightGraphs.DiGraph)
    g_undirected = deepcopy(g)

    for edge in edges(g_undirected)
        add_edge!(g_undirected,reverse(edge))
    end

    return g_undirected
end

# Return the data to plot the indegree and outdegree distributions
function degree_distributions(g::LightGraphs.DiGraph,include_zero=false)

    indeg = indegree(g)
    outdeg = outdegree(g)

    x_in,y_in = log_log_ranking(indeg[indeg.>=1],include_zero)
    x_out,y_out = log_log_ranking(outdeg[outdeg.>=1],include_zero)

    return x_in,y_in,x_out,y_out
end

# Same idea but group all the graphs together
function degree_distributions(g::Array{LightGraphs.DiGraph})
    nb_seeds,n_simul = size(g)
    n = nv(g[1,1])

    indeg = zeros(Int64,nb_seeds,n_simul,n)
    outdeg = zeros(Int64,nb_seeds,n_simul,n)

    for i=1:nb_seeds
        for j=1:n_simul
            indeg[i,j,:] = indegree(g[i,j])
            outdeg[i,j,:] = outdegree(g[i,j])
        end
    end

    indeg_col = indeg[:]
    outdeg_col = outdeg[:]

    x_in,y_in = log_log_ranking(indeg_col[indeg_col.>=1])
    x_out,y_out = log_log_ranking(outdeg_col[outdeg_col.>=1])

    return x_in,y_in,x_out,y_out
end

# Check if a graph A is strongly connected
function is_graph_strongly_connected(A::AbstractArray{Bool})
    g = build_graph(A)
    return LightGraphs.is_strongly_connected(g)
end

# https://en.wikipedia.org/wiki/Power_iteration
function power_itr(A,Θ,α)
    n = size(A)[1]

    srand(1)
    b = rand(n)
    b_new = copy(b)

    convergence = false
    tol = 1e-12
    iter = 0
    iter_max = 100000
    while !convergence && iter<iter_max
        iter += 1
        b_new = α*A*b + Θ*(1-α)/sum(Θ)
        # b_new = A*b

        b_new = b_new/norm(b_new,1)
        dist = maximum(abs.(b_new-b))
        if dist<tol
            convergence = true
        else
            b = copy(b_new)
        end
    end

    if iter==iter_max

        println(" ... no convergence on power_itr")
        b_new = zeros(n)
    end

    return b_new

end

function centrality_mat(Ω::AbstractArray{Bool,2},Θ::Array{Bool},α)
    Θ = Θ[:]
    active_Ω = (Θ*Θ').*Ω
    eigvec = power_itr(active_Ω,Θ,α)

    return real(eigvec)
end

function local_clustering_mat(Ω::AbstractArray{Bool,2},Θ::Array{Bool})
    # Compute the local clustering coefficient of the UNDIRECTED GRAPH
    return LightGraphs.local_clustering_coefficient(build_graph(build_active_network_matrix(Ω,Θ),true))
end
