# This files contains the methods to solve graphs and verify the solution in the model with hetergoneity
# It is used for testing. Only the needed functions are included with heterogeneity

mutable struct Parameters_hetero
    n::Int64                            # Number of firms
    f::Vector{Float64}                  # Cost of operation
    std_z::Float64                      # Standard deviation of z shocks
    ρ_z::Float64                        # Persistence of z shocks
    σ::Float64                          # Elasticity of substitution consumption
    ϵ::Vector{Float64}                  # Elasticity of substitution production
    α::Vector{Float64}                  # Labor intensity
    β::Vector{Float64}                  # Household preferences
    Ω::SparseMatrixCSC{Float64,Int64}   # Network - Notice potential heterogeneity here
end

function solveExhaustive(param::Parameters_hetero,z::Array{Float64},mute=true,first_index=1)
    # This function solves the planner's problem by iterating on the equation for the q's
    # This code evaluates all the possible theta's. It can take a very long time!

    if ~mute; println("Solving the network... "); end

    n,σ,ϵ,α,f,Ω,β = param.n,param.σ,param.ϵ,param.α,param.f,full(param.Ω),param.β

    L = 1

    indexes = first_index:n

    Θ_combinations = product(repeated(0:1,length(indexes))...)

    C_best,Θ_best = 0.0,zeros(Int64, n)

    for Θ_trial in Θ_combinations
        Θ_act_trial = ones(Int64,n)
        for i = 1:length(indexes)
            Θ_act_trial[indexes[i]] = collect(Θ_trial)[i]
        end

        q_trial = solveq(param,z,Θ_act_trial,mute)
        Q_trial = (sum(β.*q_trial.^(σ-1)))^(1/(σ-1))
        C_trial = (L-sum(f.*Θ_act_trial))*Q_trial

        if C_trial > C_best
            C_best = copy(C_trial)
            Θ_best = copy(Θ_act_trial)
        end
    end

    Θ_best
end



function sup_norm(x::Array{Float64},y::Array{Float64})
    max = 0.0

    # It's faster to use a loop
    for i=1:length(x)
        temp = abs(x[i]-y[i])
        if temp > max
            max = temp
        end
    end
    return max
end


function solveq(param::Parameters_hetero,z::Array{Float64},Θ,mute::Bool)
    n,ϵ,α,Ω,A = param.n,param.ϵ,param.α,full(param.Ω),1.0

    # Iterate on q until convergence
    tol_conv_q,max_iter_q,iter_q = 1e-5,1000,0
    q,q_new,B = zeros(n),ones(n),zeros(n)

    while sup_norm(q,q_new) > tol_conv_q && iter_q < max_iter_q
        iter_q += 1
        q = q_new

        for j=1:n
            B[j] = sum(Ω[:,j].*q.^(ϵ[j]-1))^(1/(ϵ[j]-1))
        end
        q_new = z.*Θ.*A.*(B.^α)
    end

    if iter_q == max_iter_q
        println("z = $z")
        println("Θ = $Θ")
        println("ϵ = $ϵ")
        println("α = $α")
        display(Ω)

        error("Max iter_q reached")
    else
        if ~mute; println(" ... convergence on q in $iter_q iterations at tol $tol_conv_q"); end
    end

    return q
end


function foc_iterations(param::Parameters_hetero,z::Array{Float64},mute,reshaping,a,b,weight_new=0.9)
    n,σ,ϵ,α,f,Ω,β = param.n,param.σ,param.ϵ,param.α,param.f,full(param.Ω),param.β

    A = 1.0
    L = 1.0

    Delta_mu = - ones(n)/n
    Delta_mu_new = zeros(n)

    has_converged = false
    iter = 0
    iter_max = 1000

    distance = Inf
    distance_old = Inf

    tol = 1e-8

    # Flag to keep track of the FOC convergence
    flag_error = true

    Θ = zeros(Bool,n)
    q = zeros(n)
    B = zeros(n)
    Γ = zeros(n,n)
    E = zeros(n)
    λ = zeros(n)
    theta_divided_by_B = zeros(n)

    while ~has_converged && (iter<iter_max) && !Base.isnan(distance)
        iter += 1

        Θ = Array(round.(Bool,Delta_mu[:] .<= 0.0))
        q = solveq(param,z,Θ,true)

        # \lambda here is actually \zeta*q/\theta from the algorithm in Appendix E.4
        if ~reshaping
            # WITHOUT RESHAPING

            for j=1:n
                B[j] = sum(Θ.*Ω[:,j].*q.^(ϵ[j]-1))^(1/(ϵ[j]-1))
            end

            theta_divided_by_B = zeros(n)
            for k = 1:n
                if B[k] > 0.0
                    theta_divided_by_B[k] = Θ[k]/(B[k]^(ϵ[k]-1))
                end
            end

            for k = 1:n
                for j = 1:n
                    Γ[k,j] = (k == j) - theta_divided_by_B[j].*α[j]*Ω[k,j]*(A*z[k]*B[k]^α[k])^(ϵ[j]-1)
                end
            end

            if sum(β.*q.^(σ.-1)) > 0
                E = β.*((A.*z.*B.^α).^(σ-1).*Θ)./(sum(β.*q.^(σ.-1)))
            else
                E = zeros(n)
            end


            # λ = Γ\E
            λ = pinv(Γ)*E

            for k = 1:n
                temp = zeros(n)
                for j=1:n
                    temp[j] = α[j]/(ϵ[j]-1)*λ[j]*theta_divided_by_B[j]*b[j]*Ω[k,j]*Θ[k]*(A*z[k]*B[k]^α[k])^(ϵ[j]-1)
                end
                Delta_mu_new[k] = f[k]./(L.-sum(f.*Θ)) .- λ[k].*a[k] - sum(temp)
            end
        else
            # WITH RESHAPING
            for j=1:n
                B[j] = sum(Θ.*Ω[:,j].*q.^(ϵ[j]-1))^(1/(ϵ[j]-1))
            end

            theta_divided_by_B = zeros(n)
            for k = 1:n
                if B[k] > 0.0
                    theta_divided_by_B[k] = Θ[k]/(B[k]^(ϵ[k]-1))
                end
            end

            for k = 1:n
                for j = 1:n
                    Γ[k,j] = (k == j) - theta_divided_by_B[j].*α[j]*Ω[k,j]*(A*z[k]*B[k]^α[k])^(ϵ[j]-1)
                end
            end

            if sum(β.*q.^(σ.-1)) > 0
                E = β.*((A.*z.*B.^α).^(σ-1))./(sum(β.*q.^(σ.-1)))
            else
                E = zeros(n)
            end

            # λ = Γ\E
            λ = pinv(Γ)*E


            for k = 1:n
                temp = zeros(n)
                for j = 1:n
                    temp[j] = α[j]/(ϵ[j]-1)*λ[j]*theta_divided_by_B[j]*(1-(ϵ[j]-1)/(σ-1))*Ω[k,j]*(A*z[k]*B[k]^α[k])^(ϵ[j]-1)
                end

                Delta_mu_new[k] = f[k]./(L.-sum(f.*Θ)) .- λ[k]./(σ-1) - sum(temp)
            end
        end

        distance = sup_norm(Delta_mu_new,Delta_mu)

        if ~mute
            println("Distance = $distance")
        end

        # When the distance increases the algorithm rarely converges so stop it right away.
        if distance < tol || distance>=distance_old
            has_converged = true
        else
            distance_old = copy(distance)
            Delta_mu = weight_new*Delta_mu_new+(1-weight_new)*Delta_mu
        end
    end

    Θ = Array(round.(Bool,Delta_mu_new[:] .<= 0.0))



    flag_error = false
    nb_non_converged_theta = 0
    if distance < tol
        if ~mute
            println(" ... FOCs have converged")
        end

        nb_non_converged_theta = 0
    else
        if ~mute
            println(" ... FOCs have not converged")
        end
        # Send a flag about the non convergence
        flag_error = true


        # The algorithm could not converge on some θ that kept moving around
        # Look at the relevent θ here and pick the best one
        # The next line can be commented if only interested in converged cases
        C_best,Θ = find_1dev(param,z,Θ,find(abs.((Delta_mu_new .<= 0.0) - (Delta_mu.<= 0.0))))

        # Compute the number of theta's that kept changing signs at convergence
        nb_non_converged_theta = sum(abs.((Delta_mu_new .<= 0.0) - (Delta_mu.<= 0.0)))
    end

    if Base.isnan(distance)
        error("Distance is NaN in foc iterations")
    end


    Θ,flag_error,nb_non_converged_theta
end


# This function compares the vectors θ over which there are oscillations in foc_iterations
function find_1dev(param::Parameters_hetero,z,Θ,indexes_to_check=1:param.n)
    n = param.n
    σ = param.σ
    f = param.f
    β = param.β

    Θ_best = copy(Θ)
    q_best = solveq(param,z,Θ_best,true)
    Q_best = (sum(β.*q_best.^(σ-1)))^(1/(σ-1))
    C_best = (1-sum(f.*Θ_best))*Q_best

    Θ_init = copy(Θ_best)
    C_init = copy(C_best)

    still_deviations = true

    while still_deviations
        still_deviations = false

        for i in indexes_to_check
            Θ_trial = copy(Θ_best)
            if Θ_trial[i] == true
                Θ_trial[i] = false
            else
                Θ_trial[i] = true
            end

            q_trial = solveq(param,z,Θ_trial,true)
            Q_trial = (sum(β.*q_trial.^(σ-1)))^(1/(σ-1))
            C_trial = (1-sum(f.*Θ_trial))*Q_trial

            if C_trial > C_best
                still_deviations = true

                C_best = copy(C_trial)
                Θ_best = copy(Θ_trial)
                q_best = copy(q_trial)
            end
        end
    end
    return C_best,Θ_best

end
