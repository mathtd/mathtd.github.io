# Methods to solve the model


function solveExhaustive(param::Parameters,z::Array{Float64},mute=true)
    # Solves the planner's problem by iterating on the equation for the q's
    # This code evaluates all the possible theta. It can take a very long time!

    if ~mute; println("Solving the network... "); end

    n,σ,ϵ,α,f,Ω = param.n,param.σ,param.ϵ,param.α,param.f,full(param.Ω)

    L = 1

    indexes = 1:n

    Θ_act_trial = zeros(Int64,(n,1))
    Θ_combinations = product(repeated(0:1,length(indexes))...)

    C_best,Θ_best = 0.0,zeros(Int64, n)

    for Θ_trial in Θ_combinations
            Θ_act_trial = zeros(Int64,n)
            for i = 1:length(indexes)
                Θ_act_trial[indexes[i]] = collect(Θ_trial)[i]
            end

            q_trial = solveq(param,z,Θ_act_trial,mute)
            Q_trial = (sum(q_trial.^(σ-1)))^(1/(σ-1))
            C_trial = (L-sum(f.*Θ_act_trial))*Q_trial

            if C_trial > C_best
                C_best = copy(C_trial)
                Θ_best = copy(Θ_act_trial)
            end
    end
    return Θ_best
end

function sup_norm(x::Array{Float64},y::Array{Float64})
    # Fatser than Julia's norm()
    max = 0.0

    for i=1:length(x)
        temp = abs(x[i]-y[i])
        if temp > max
            max = temp
        end
    end
    return max
end

# function solveq(param::Parameters,z::Array{Float64},Θ::Array{Bool},mute::Bool)
function solveq(param::Parameters,z::Array{Float64},Θ,mute::Bool)
    n,ϵ,α,Ω,A = param.n,param.ϵ,param.α,full(param.Ω),1.0

    # Iterate on q until convergence
    tol_conv_q,max_iter_q,iter_q = 1e-5,1000,0
    q,q_new = zeros(n),ones(n)

    while sup_norm(q,q_new) > tol_conv_q && iter_q < max_iter_q
        iter_q += 1
        q = q_new
        q_new = z.*Θ.*A.*(Ω'*(q.^(ϵ.-1))).^(α./(ϵ.-1))
    end

    if iter_q == max_iter_q
        error("Max iter_q reached")
    else
        if ~mute; println(" ... convergence on q in $iter_q iterations at tol $tol_conv_q"); end
    end

    return q
end


# Finds firms characteristics from q and θ
function solve_ind_from_q(param::Parameters,q::Array{Float64},Θ::Array{Bool},z::Array{Float64})
    L = 1.0
    A = 1.0

    n,σ,ϵ,α,f,Ω = param.n,param.σ,param.ϵ,param.α,param.f,param.Ω

    Q = (sum(q.^(σ-1)))^(1/(σ-1))

    invq = (q.>0).*(1./q)
    Γ = Ω.*repmat((Θ.*(z.*A.*invq).^((ϵ-1)/α))',n,1).*repmat(q.^(ϵ-1),1,n)

    C = (L-f*sum(Θ))*Q
    l = (1-α)*C/Q*inv(eye(n,n)-α*Γ)*((q./Q).^(σ-1))
    y = q.*l/(1-α).*(Θ.==1)
    c = (q./Q).^σ*C

    return y,l,c
end

function solvefromq(q::Array{Float64},Θ::Array{Bool},mute::Bool,n,σ,ϵ,α,L,f,A,Ω,z::Array{Float64})
    # Finds all quantities from q and theta

    # Compute the aggregates
    Q = (sum(q.^(σ-1)))^(1/(σ-1))
    w = Q

    invq = (q.>0).*(1./q)
    Γ = Ω.*repmat((Θ.*(z.*A.*invq).^((ϵ-1)/α))',n,1).*repmat(q.^(ϵ-1),1,n)
    C = (L-f*sum(Θ))*Q
    l = (1-α)*C/Q*inv(eye(n,n)-α*Γ)*((q./Q).^(σ-1))

    if ~mute; println("[done]"); println(""); end

    y = q.*l/(1-α).*(Θ.==1)
    x = α*repmat(q.^ϵ,1,n).*repmat((y.*(Θ.*invq).^ϵ.*(z.*A.*(Θ.*invq).^(1-α)).^((ϵ-1)/α))',n,1).*Ω

    c = (q./w).^σ*C

    Q,C,w,q,l,c,x,Θ,y
end

# Function to solve the economy by iterating on the FOCs
# The option exercise_type makes the z shocks only hit one active firm from the initial simulation
function solve_simulation(param,n_simul::Int64,seed::Int64,exercise_type::Int64,forced_theta::Array{Bool},reshaping=true,allow_error=false)
    n = param.n
    std_z,ρ_z = param.std_z,param.ρ_z

    L = 1.0

    if allow_error
        print_with_color(:red, "\n\nWarning: keeping simulations with FOC not converging on {0,1}^n \n\n",bold=true)
    end

    # Matrices to store the result
    Θ_stor = zeros(Bool, (n_simul,n))
    q_stor = zeros(Float64, (n_simul,n))
    z_stor = zeros(Float64, (n_simul,n))
    A_stor = zeros(Float64, (n_simul,1)) # Aggregate shocks when there are aggregate shocks
    y_stor = zeros(Float64, (n_simul,n)) # iid shocks when there are aggregate shocks



    # Prepare randomness for shocks
    σ_innov = std_z * sqrt(1.0-ρ_z^2)
    z_ergo_dist = Normal(0.0, std_z)
    z_innov_dist = Normal(0.0, σ_innov)

    # Only for aggregate shocks
    y_innov_dist = Normal(0.0, σ_innov)

    # Aggregate shocks
    # This uses the decomposition of overall variance from the aggregate shock proposition
    # See Appendix with large simulations
    if exercise_type == 5


        # Parameters from Watson
        # std_A = 0.0568/2
        # ρ_A = 0.9

        # Parameters from Atalay
        std_A = 0.01285
        ρ_A = 0.9


        println("Simulations with aggregate shocks")
        println("std_A = $std_A")
        println("rho_A = $ρ_A")

        σA_innov = std_A * sqrt(1.0-ρ_A^2)
        A_ergo_dist = Normal(0.0, std_A)
        A_innov_dist = Normal(0.0, σA_innov)
    end

    # Initial draw from ergodic distribution
    for t = 1:n_simul
        attempt = 0
        max_attempt = 200

        success = false

        while !success && (attempt <= max_attempt)
            attempt += 1

            # Make sure the seeds don't overlap
            srand(seed + (attempt-1)*4138743 + (t-1)*19323)


            # draw initial inovation for z
            if t == 1
                z_stor[t,:] = exp.(rand(Normal(0.0, std_z),n))
                if exercise_type == 5
                    y_stor[t,:] = rand(Normal(0.0, std_z),n)
                end
            else
                if exercise_type == 0 || exercise_type == 2 || exercise_type == 3 || exercise_type == 4
                    z_innov = rand(z_innov_dist,n)
                    z_stor[t,:] = exp.(ρ_z*log.(z_stor[t-1,:]) + z_innov)
                # elseif exercise_type == 1
                #     # We are looking at cascades
                #     # Shut down only one active firm from the first period
                #
                #     # Select the firm to shutdown
                #     index = 1:n
                #     index_active_firms = index[Θ_stor[1,:] .== true]
                #     shocked_firm = index_active_firms[rand(1:end)]
                #
                #     # All productivities are the same as in t=1 ...
                #     z_stor[t,:] = z_stor[1,:]
                #
                #     # ... except for the chosen firm
                #     z_stor[t,shocked_firm] = 0.0
                elseif exercise_type == 1
                    # We are looking at cascades
                    # Shut down only one active firm from the first period

                    # Select the firm to shutdown
                    index = 1:n
                    index_active_firms = index[Θ_stor[1,:] .== true]
                    shocked_firm = index_active_firms[rand(1:end)]

                    # All productivities are the same as in t=1 ...
                    z_stor[t,:] = z_stor[1,:]

                    # ... except for the chosen firm that gets a shocks
                    firm_alive = true
                    # We only consider z below z_lowest
                    z_lowest = z_stor[1,shocked_firm]

                    counter = 1
                    while firm_alive
                        counter += 1
                        z_higher = true
                        while z_higher
                            if counter >= 10
                                z_stor[t,shocked_firm] = 0.0
                                z_higher = false
                            else
                                z_draw = exp.(rand(Normal(0.0, std_z)))
                                if z_draw < z_lowest
                                    z_stor[t,shocked_firm] = z_draw
                                    z_lowest = z_stor[t,shocked_firm]
                                    z_higher = false
                                end
                            end
                        end

                        # Verify if the firm shuts down

                        Θ_stor[t,:],flag_error = foc_iterations(param,z_stor[t,:],forced_theta[t,:],param.f,reshaping)
                        if Θ_stor[t,shocked_firm] == false
                            firm_alive = false
                        end
                    end

                elseif exercise_type == 5
                    # We have aggregate shocks
                    A_innov = rand(A_innov_dist,1)
                    y_innov = rand(z_innov_dist,n)

                    y_stor[t,:] = ρ_z*y_stor[t-1,:] + y_innov
                    A_stor[t] = ρ_A*A_stor[t-1] + A_innov[1]

                    z_stor[t,:] = exp.(y_stor[t,:]+A_stor[t])

                else
                    error("Invalid exercise_type")
                end
            end
            if exercise_type == 3
                # Set a random half of the firms with 0 fixed cost
                Θ_stor[t,:],flag_error = foc_iterations(param,z_stor[t,:],forced_theta[t,:],param.f.*(1-rand(n).>0.5),reshaping)
            elseif exercise_type == 4
                # If a firm is already operating, divides its fixed cost by 2
                if t == 1
                    Θ_stor[t,:],flag_error = foc_iterations(param,z_stor[t,:],forced_theta[t,:],param.f,reshaping)
                else
                    Θ_stor[t,:],flag_error = foc_iterations(param,z_stor[t,:],forced_theta[t,:],param.f.*(1-Θ_stor[t-1,:]*0.5),reshaping)
                end
            else
                # Solve the model by iterating on the FOCs
                Θ_stor[t,:],flag_error = foc_iterations(param,z_stor[t,:],forced_theta[t,:],param.f,reshaping)
            end


            if flag_error && !allow_error
                # theta converged outside {0,1}^n
                success = false
            else
                success = true
            end
        end

        q_stor[t,:] = solveq(param,z_stor[t,:],Θ_stor[t,:],true)

        if attempt == max_attempt
            error("Unable to solve under these parameters")
        end
    end

    return Simulation(param,n_simul,Θ_stor,q_stor,z_stor)
end


# This function use the same algorithm as in solutions_hetero.jl. It is more precise but slower than foc_iterations
# I've solved replicate_bench.jl with this code instead and I cannot see any difference

function foc_iterations_precise(param::Parameters,z::Array{Float64},forced_theta=zeros(Bool,param.n),f=param.f,reshaping=true)
    n,σ,ϵ,α,f,Ω = param.n,param.σ,param.ϵ,param.α,param.f,full(param.Ω)

    mute = true
    weight_new = 0.9

    A = 1.0
    L = 1.0
    β = ones(n)

    Delta_mu = - ones(n)/n
    Delta_mu_new = zeros(n)

    has_converged = false
    iter = 0
    iter_max = 1000

    distance = Inf
    distance_old = Inf

    tol = 1e-8

    # Flag to keep track of the FOC convergence
    flag_error = true

    Θ = zeros(Bool,n)
    q = zeros(n)
    B = zeros(n)
    Γ = zeros(n,n)
    E = zeros(n)
    λ = zeros(n)
    theta_divided_by_B = zeros(n)

    while ~has_converged && (iter<iter_max) && !Base.isnan(distance)
        iter += 1

        Θ = Array(round.(Bool,Delta_mu[:] .<= 0.0))
        Θ[forced_theta] = true # If the exercise forces some firms to operate
        q = solveq(param,z,Θ,true)

        # \lambda here is actually \zeta*q/\theta from the algorithm in Appendix E.4
        if ~reshaping
            # WITHOUT RESHAPING
            b = ones(n)

            for j=1:n
                B[j] = sum(Θ.*Ω[:,j].*q.^(ϵ-1))^(1/(ϵ-1))
            end

            theta_divided_by_B = zeros(n)
            for k = 1:n
                if B[k] > 0.0
                    theta_divided_by_B[k] = Θ[k]/(B[k]^(ϵ-1))
                end
            end

            for k = 1:n
                for j = 1:n
                    Γ[k,j] = (k == j) - theta_divided_by_B[j].*α*Ω[k,j]*(A*z[k]*B[k]^α)^(ϵ-1)
                end
            end

            if sum(β.*q.^(σ.-1)) > 0
                E = β.*((A.*z.*B.^α).^(σ-1).*Θ)./(sum(β.*q.^(σ.-1)))
            else
                E = zeros(n)
            end


            # λ = Γ\E
            λ = pinv(Γ)*E

            for k = 1:n
                temp = zeros(n)
                for j=1:n
                    temp[j] = α/(ϵ-1)*λ[j]*theta_divided_by_B[j]*b[j]*Ω[k,j]*Θ[k]*(A*z[k]*B[k]^α)^(ϵ-1)
                end
                Delta_mu_new[k] = f[k]./(L.-sum(f.*Θ)) .- λ[k].*a[k] - sum(temp)
            end
        else
            # WITH RESHAPING
            for j=1:n
                B[j] = sum(Θ.*Ω[:,j].*q.^(ϵ-1))^(1/(ϵ-1))
            end

            theta_divided_by_B = zeros(n)
            for k = 1:n
                if B[k] > 0.0
                    theta_divided_by_B[k] = Θ[k]/(B[k]^(ϵ-1))
                end
            end

            for k = 1:n
                for j = 1:n
                    Γ[k,j] = (k == j) - theta_divided_by_B[j].*α*Ω[k,j]*(A*z[k]*B[k]^α)^(ϵ-1)
                end
            end

            if sum(β.*q.^(σ.-1)) > 0
                E = β.*((A.*z.*B.^α).^(σ-1))./(sum(β.*q.^(σ.-1)))
            else
                E = zeros(n)
            end

            # λ = Γ\E
            λ = pinv(Γ)*E


            for k = 1:n
                temp = zeros(n)
                for j = 1:n
                    temp[j] = α/(ϵ-1)*λ[j]*theta_divided_by_B[j]*(1-(ϵ-1)/(σ-1))*Ω[k,j]*(A*z[k]*B[k]^α)^(ϵ-1)
                end

                Delta_mu_new[k] = f./(L.-sum(f.*Θ)) .- λ[k]./(σ-1) - sum(temp)
            end
        end

        # distance = sup_norm(Delta_mu_new,Delta_mu)
        distance = sup_norm(Delta_mu_new[.~forced_theta],Delta_mu[.~forced_theta])

        if ~mute
            println("Distance = $distance")
        end

        # When the distance increases the algorithm rarely converges so stop it right away.
        if distance < tol || distance>=distance_old
            has_converged = true
        else
            distance_old = copy(distance)
            Delta_mu = weight_new*Delta_mu_new+(1-weight_new)*Delta_mu
        end
    end

    Θ = Array(round.(Bool,Delta_mu_new[:] .<= 0.0))
    Θ[forced_theta] = true # If the exercise forces some firms to operate


    flag_error = false
    if distance < tol
        if ~mute
            println(" ... FOCs have converged")
        end

    else
        if ~mute
            println(" ... FOCs have not converged")
        end
        # Send a flag about the non convergence
        flag_error = true


        # The algorithm could not converge on some θ that kept moving around
        # Look at the relevent θ here and pick the best one
        # The next line can be commented if only interested in converged cases like in the benchmark simulations
        # C_best,Θ = find_1dev(param,z,Θ,find(abs.((Delta_mu_new .<= 0.0) - (Delta_mu.<= 0.0))))

    end

    if Base.isnan(distance)
        error("Distance is NaN in foc iterations")
    end


    Θ,flag_error
end

function foc_iterations(param,z::Array{Float64},forced_theta::Array{Bool},f=param.f,reshaping=true)
    n,σ,ϵ,α,Ω = param.n,param.σ,param.ϵ,param.α,full(param.Ω)

    if σ < ϵ
        error("This code is not adapted for σ < ϵ. The most general code in solutions_hetero.jl.")
    end


    A = 1.0
    L = 1.0
    mute = true

    if reshaping
        a = 1/(σ-1)
        b = 1-(ϵ-1)/(σ-1)
    else
        a = 1
        b = 0
    end


    # Initiualize the difference between Lagrange multipliers
    Delta_mu = - ones(n)/n
    Delta_mu_new = zeros(n)

    has_converged = false
    iter = 0
    iter_max = 100

    distance = Inf
    distance_old = Inf

    # Test bigger tolerances
    # Set tol to 1e-8 for network3
    tol = 1e-5

    flag_error = true

    # Initialize vectors
    θ,q,B,Γ,E,λ,theta_divided_by_B = zeros(Bool,n),zeros(n),zeros(n),zeros(n,n),zeros(n),zeros(n),zeros(n)


    while ~has_converged && (iter<iter_max) && !Base.isnan(distance)
        iter += 1

        Θ = Array(round.(Bool,Delta_mu[:] .< 0.0))
        Θ[forced_theta] = true # If the exercise forces some firms to operate

        # Compute the number of changes in theta_divided_by_B
        q = solveq(param,z,Θ,true)

        B = Ω'*(Θ.^b.*q.^(ϵ.-1))

        # \lambda  is actually \lambda*q/\theta  from the notes

        theta_divided_by_B = Θ./B.*(B.>0)

        if reshaping
            # Simplified equations for reshaping

            # Vectorized code is a bit slower
            # Γ = eye(n) - α.*repmat(((z.*A).^(ϵ.-1)).*(B.^α),1,n).*repmat(theta_divided_by_B',n,1).*Ω
            # E = ((B.^(α./(ϵ.-1))).*z.*A).^(σ.-1)./(sum(q.^(σ.-1)))

            for k = 1:n
                temp = α*(z[k]*A)^(ϵ-1)*(B[k]^α)
                for j = 1:n
                    Γ[k,j] = (k == j) - temp*Ω[k,j]*theta_divided_by_B[j]
                end
                E[k] = (z[k]*A*B[k]^(α/(ϵ-1)))^(σ-1)
            end
            E = E/(sum(q.^(σ.-1)))

            λ = Γ\E
            Delta_mu_new = f./(L.-f.*sum(Θ)) .- λ.*a .- α./(ϵ.-1).*(b).*(z.*A).^(ϵ.-1).*B.^α .* (Ω*(theta_divided_by_B.*λ))

        else
            Γ = eye(n) - α*repmat(Θ.^(b+a*(ϵ-1)-1).*((z*A).^(ϵ-1)).*(B.^α),1,n).*repmat(theta_divided_by_B',n,1).*Ω

            E = (Θ.^(a*(σ-1)-1).*(B.^(α/(ϵ-1))).*z*A).^(σ-1)./(sum(q.^(σ-1)))
            λ = Γ\E
            Delta_mu_new = f/(L-f*sum(Θ)) - λ*a - Θ.^(b-1+a*(ϵ-1)).*α/(ϵ-1).*(b).*(z.*A).^(ϵ-1).*B.^α .* (Ω*(theta_divided_by_B.*λ))
        end

        distance = sup_norm(Delta_mu_new[.~forced_theta],Delta_mu[.~forced_theta])

        if ~mute
            println("Distance = $distance")
        end


        if distance < tol || distance>=distance_old
            has_converged = true
        else
            distance_old = copy(distance)
            Delta_mu = 0.5*Delta_mu_new+0.5*Delta_mu
        end
    end

    Θ = Array(round.(Bool,Delta_mu[:] .< 0.0))
    Θ[forced_theta] = true # If the exercise forces some firms to operate


    if distance < tol
        # FOCs have converged correctly
        if sum(Θ) == n
            println(" ... all firms are active. Check parameters.")
        end

        flag_error = false
    else
        # FOCs have not converged correctly
        flag_error = true
    end

    if iter == iter_max
        error("Itermax reached in foc_iterations")
    end

    Θ,flag_error
end


# function solveall1dev!(m::Economy,mute::Bool,only_one_pass=false,indexes=1:m.n,return_model=false)
#
#     # This function takes a SOLVED model and looks if there is a positive 1 dev
#
#     if ~mute; println("Solving the network for 1 dev... "); end
#
#     n,σ,ϵ,α,L,f,A,Ω,z = m.n,m.σ,m.ϵ,m.α,m.L,m.f,m.A,m.Ω,m.z
#
#     Θ_best = copy(m.Θ)
#     q_best = solveq(m,Θ_best,mute)
#     Q_best = (sum(q_best.^(σ-1)))^(1/(σ-1))
#     C_best = (L-f*sum(Θ_best))*Q_best
#
#     still_deviations = true
#     nb_deviations = 0
#
#     Θ_before = copy(Θ_best)
#
#     while still_deviations
#         still_deviations = false
#
#         for i in indexes
#
#             Θ_trial = copy(Θ_best)
#             if Θ_trial[i] == 1
#                 Θ_trial[i] = 0
#             else
#                 Θ_trial[i] = 1
#             end
#
#             q_trial = solveq(m,Θ_trial,mute)
#             Q_trial = (sum(q_trial.^(σ-1)))^(1/(σ-1))
#             C_trial = (L-f*sum(Θ_trial))*Q_trial
#
#             if C_trial > C_best
#                 still_deviations = true
#                 if ~mute; println("1 dev found"); end
#                 nb_deviations += 1
#                 println("1 dev found")
#                 println("i = $i")
#                 println("(C_trial - C_best)/C_best = $((C_trial-C_best)/C_best)")
#                 println("Nb_input i = $(sum(Ω[:,i]))")
#
#                 C_best = copy(C_trial)
#                 Θ_best = copy(Θ_trial)
#                 q_best = copy(q_trial)
#
#             end
#
#         end
#         if only_one_pass
#             still_deviations = false
#         end
#     end
#
#     if return_model
#         m.Θ = Θ_best
#         m.rawΘ = Θ_best
#         m.q = q_best
#         m = solvefromq(m,q_best,mute)
#         return m
#     else
#
#         return nb_deviations,C_best,Θ_best
#     end
#
# end
