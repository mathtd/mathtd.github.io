# Build the cascades data to be analyzed later
# The output is a set of files that can be used for regressions
# We look at each firm in each year and figure out how many of its neighbors exit
# If a firm is missing in a year it is not included in the database
# We can then regress this on whether the original firm goes dows as well
# We compute other network statistics along the way as control


function build_cascades_data(direct_networks_dict,reverse_networks_dict,undirected_network_dict,valid_exit_year_dict,Nb_firms,start_year,end_year,firm_destruct,dir,suffix)
    nb_years = end_year - start_year + 1
    years_vec = start_year:end_year

    # Consider neighbors up to max_depth
    max_depth = 5


    # Do a quick check to see how many data point we will have
    nb_data = 0
    for i_year in 1:nb_years
        if valid_exit_year_dict[years_vec[i_year]]
            # Go over all the firms
            for i = 1:Nb_firms
                indegree_firm = LightGraphs.indegree(direct_networks_dict[years_vec[i_year]],i)
                outdegree_firm = LightGraphs.outdegree(direct_networks_dict[years_vec[i_year]],i)

                if indegree_firm > 0 || outdegree_firm > 0
                    nb_data += 1
                end
            end
        end
    end
    # Build empty vectors that will contain the data

    # Characteristics of the firm
    firm_exits = Array{Int64,1}(nb_data)
    firm_id = Array{Int64,1}(nb_data)
    year = Array{Int64,1}(nb_data)
    indegree = Array{Int64,1}(nb_data)
    outdegree = Array{Int64,1}(nb_data)
    centrality = Array{Float64,1}(nb_data)

    # Keep track of the neighbors
    nb_neigbors_up = Matrix{Int64}(nb_data, max_depth)
    nb_neigbors_down = Matrix{Int64}(nb_data, max_depth)
    nb_neigbors_all = Matrix{Int64}(nb_data, max_depth)

    nb_neigbors_up_exits = Matrix{Int64}(nb_data, max_depth)
    nb_neigbors_down_exits = Matrix{Int64}(nb_data, max_depth)
    nb_neigbors_all_exits = Matrix{Int64}(nb_data, max_depth)


    # Data point where we are
    i_data = 0

    # Now go over all the firms, year by year and add them to the data vectors
    # The last year does not teach us anything since all firms "exit" then
    for i_year in 1:nb_years
        if valid_exit_year_dict[years_vec[i_year]]
            if i_year % 10 == 0
                println(" ... computing year = $(years_vec[i_year])")
            end
            centrality_firm_graph = LightGraphs.eigenvector_centrality(direct_networks_dict[years_vec[i_year]])


            # Go over all the firms
            for i = 1:Nb_firms

                indegree_firm = LightGraphs.indegree(direct_networks_dict[years_vec[i_year]],i)
                outdegree_firm = LightGraphs.outdegree(direct_networks_dict[years_vec[i_year]],i)
                centrality_firm = centrality_firm_graph[i]

                if indegree_firm == 0 && outdegree_firm == 0
                    # This firm has no neighbor. It's not in that year's sample. Skip it.
                else
                    i_data += 1
                    # Begin stacking the data vector
                    firm_id[i_data] = i
                    year[i_data] = years_vec[i_year]

                    if firm_destruct[i_year,i]
                        firm_exits[i_data] = 1
                    else
                        firm_exits[i_data] = 0
                    end

                    indegree[i_data] = indegree_firm
                    outdegree[i_data] = outdegree_firm
                    centrality[i_data] = centrality_firm

                    # Now look at neighbors and compute exits

                    shortest_down = LightGraphs.dijkstra_shortest_paths(direct_networks_dict[years_vec[i_year]],i)
                    shortest_up = LightGraphs.dijkstra_shortest_paths(reverse_networks_dict[years_vec[i_year]],i)
                    shortest_all = LightGraphs.dijkstra_shortest_paths(undirected_network_dict[years_vec[i_year]],i)

                    nb_neigbors_up_tmp = zeros(Int64,1,max_depth)
                    nb_neigbors_down_tmp = zeros(Int64,1,max_depth)
                    nb_neigbors_all_tmp = zeros(Int64,1,max_depth)

                    nb_neigbors_up_exits_tmp = zeros(Int64,1,max_depth)
                    nb_neigbors_down_exits_tmp = zeros(Int64,1,max_depth)
                    nb_neigbors_all_exits_tmp = zeros(Int64,1,max_depth)

                    # Look at all other nodes ...
                    for j = 1:Nb_firms
                        # ... that are different from the current one ...
                        if i!=j
                            # ... and are within the max depth of exploration ...
                            if shortest_down.dists[j] <= max_depth
                                # ... and keep track of them ...
                                nb_neigbors_down_tmp[shortest_down.dists[j]] += 1
                                # ... and if they shut down afterwards keep track fo that too
                                # if firm_destruct[i_year,j] || firm_destruct[i_year+1,j]
                                if firm_destruct[i_year,j]
                                    nb_neigbors_down_exits_tmp[shortest_down.dists[j]] += 1
                                end
                            end

                            # same thing going upstream
                            if shortest_up.dists[j] <= max_depth
                                # ... and keep track of them ...
                                nb_neigbors_up_tmp[shortest_up.dists[j]] += 1
                                # ... and if they shut down afterwards keep track fo that too
                                # if firm_destruct[i_year,j] || firm_destruct[i_year+1,j]
                                if firm_destruct[i_year,j]
                                    nb_neigbors_up_exits_tmp[shortest_up.dists[j]] += 1
                                end
                            end

                            if shortest_all.dists[j] <= max_depth
                                # ... and keep track of them ...
                                nb_neigbors_all_tmp[shortest_all.dists[j]] += 1
                                # ... and if they shut down afterwards keep track fo that too
                                # if firm_destruct[i_year,j] || firm_destruct[i_year+1,j]
                                if firm_destruct[i_year,j]
                                    nb_neigbors_all_exits_tmp[shortest_all.dists[j]] += 1
                                end
                            end
                        end
                    end

                    # Add the neighbors vectors to the data
                    nb_neigbors_up[i_data,:] = nb_neigbors_up_tmp
                    nb_neigbors_down[i_data,:] = nb_neigbors_down_tmp
                    nb_neigbors_all[i_data,:] = nb_neigbors_all_tmp

                    nb_neigbors_up_exits[i_data,:] = nb_neigbors_up_exits_tmp
                    nb_neigbors_down_exits[i_data,:] = nb_neigbors_down_exits_tmp
                    nb_neigbors_all_exits[i_data,:] = nb_neigbors_all_exits_tmp
                end
            end
        end
    end

    # Export the data to csv files

    # Build empty vectors that will contain the data
    data_header = ["firm_id" "year" "firm_exits" "indegree" "outdegree" "centrality" "nb_neigh1u" "nb_neigh2u" "nb_neigh3u" "nb_neigh4u" "nb_neigh5u" "nb_neigh1d" "nb_neigh2d" "nb_neigh3d" "nb_neigh4d" "nb_neigh5d" "nb_neigh1a" "nb_neigh2a" "nb_neigh3a" "nb_neigh4a" "nb_neigh5a" "nb_neigh1ue" "nb_neigh2ue" "nb_neigh3ue" "nb_neigh4ue" "nb_neigh5ue" "nb_neigh1de" "nb_neigh2de" "nb_neigh3de" "nb_neigh4de" "nb_neigh5de" "nb_neigh1ae" "nb_neigh2ae" "nb_neigh3ae" "nb_neigh4ae" "nb_neigh5ae"]


    data = hcat(firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits)


    data = vcat(data_header,data)
    writedlm("$dir/cascades_data_$suffix.txt",data)

    return firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits
end


# Uses the output of build_cascades_data to estimate the impact of exiting on cascades
function regression_cascades(firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits,dir,suffix)

    max_depth = size(nb_neigbors_up)[2]
    # std_error_factor = 1.96 # 5% error band
    std_error_factor = 1.645 # 10% error band

    fraction_down = nb_neigbors_down_exits./nb_neigbors_down
    fraction_up = nb_neigbors_up_exits./nb_neigbors_up
    fraction_all = nb_neigbors_all_exits./nb_neigbors_all
    fraction_all_sum = sum(nb_neigbors_all_exits[:,1:2],2)./sum(nb_neigbors_all[:,1:2],2)
    fraction_all_sum = fraction_all_sum[:]

    nb_neigbors_all_sum = sum(nb_neigbors_all[:,1:2],2)
    nb_neigbors_all_sum = nb_neigbors_all_sum[:]

    fraction_down = convert(Array{Union{Missing,Float64}}, fraction_down)
    fraction_up = convert(Array{Union{Missing,Float64}}, fraction_up)
    fraction_all = convert(Array{Union{Missing,Float64}}, fraction_all)
    fraction_all_sum = convert(Array{Union{Missing,Float64}}, fraction_all_sum)

    data_all_firms = DataFrame(firm_id=firm_id
                                ,year=year
                                ,firm_exits=firm_exits
                                ,indegree=indegree
                                ,outdegree=outdegree
                                ,centrality=centrality
                                ,fraction_all_sum=fraction_all_sum)

    # add the remaining variables
    for i = 1:max_depth
        data_all_firms[Symbol("nb_neigh$(i)u")] = nb_neigbors_up[:,i]
        data_all_firms[Symbol("nb_neigh$(i)d")] = nb_neigbors_down[:,i]
        data_all_firms[Symbol("nb_neigh$(i)a")] = nb_neigbors_all[:,i]
        data_all_firms[Symbol("nb_neigh$(i)ue")] = nb_neigbors_up_exits[:,i]
        data_all_firms[Symbol("nb_neigh$(i)de")] = nb_neigbors_down_exits[:,i]
        data_all_firms[Symbol("nb_neigh$(i)ae")] = nb_neigbors_all_exits[:,i]
        data_all_firms[Symbol("frac_$(i)u")] = fraction_up[:,i]
        data_all_firms[Symbol("frac_$(i)d")] = fraction_down[:,i]
        data_all_firms[Symbol("frac_$(i)a")] = fraction_all[:,i]


        data_all_firms[Base.isnan.(data_all_firms[Symbol("frac_$(i)u")]),Symbol("frac_$(i)u")] = missing
        data_all_firms[Base.isnan.(data_all_firms[Symbol("frac_$(i)d")]),Symbol("frac_$(i)d")] = missing
        data_all_firms[Base.isnan.(data_all_firms[Symbol("frac_$(i)a")]),Symbol("frac_$(i)a")] = missing
    end
    data_all_firms[Base.isnan.(data_all_firms[Symbol("fraction_all_sum")]),Symbol("fraction_all_sum")] = missing



    pct_thresh = 95
    print_with_color(:black, "\n\n ... percentile for high indeg and outdeg is set at $pct_thresh \n",bold=true)
    data_indeg = data_all_firms[:indegree]
    data_outdeg = data_all_firms[:outdegree]
    data_deg = data_all_firms[:outdegree]+data_all_firms[:indegree]
    thresh_indeg  = percentile(data_indeg[data_indeg .> 0],pct_thresh)
    thresh_outdeg  = percentile(data_outdeg[data_outdeg .> 0],pct_thresh)
    thresh_deg  = percentile(data_deg[data_deg .> 0],pct_thresh)

    println("The indegree threshold for high indeg is $thresh_indeg")
    println("The outdegree threshold for high outdeg is $thresh_outdeg")
    println("The degree threshold for high deg is $thresh_deg")

    data_high_indegree = data_all_firms[data_all_firms[:,:indegree].>thresh_indeg,:]
    data_high_outdegree = data_all_firms[data_all_firms[:,:outdegree].>thresh_outdeg,:]
    data_high_degree = data_all_firms[data_all_firms[:,:outdegree]+data_all_firms[:,:indegree] .> thresh_deg,:]

    # println("thresh_indeg = $thresh_indeg")
    # println("thresh_outdeg = $thresh_outdeg")
    # println("thresh_deg = $thresh_deg")

    # Compute the average amount of neighbors in all datasets
    mean_neighbors_down_all = mean(nb_neigbors_down[(firm_exits .== 1),:],1)'
    mean_neighbors_up_all = mean(nb_neigbors_up[(firm_exits .== 1),:],1)'
    mean_neighbors_all_all = mean(nb_neigbors_all[(firm_exits .== 1),:],1)'
    mean_neighbors_all_sum_all = mean(nb_neigbors_all_sum[(firm_exits .== 1),:],1)'
    mean_neighbors_down_hi = mean(nb_neigbors_down[(indegree .> thresh_indeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_up_hi = mean(nb_neigbors_up[(indegree .> thresh_indeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_all_hi = mean(nb_neigbors_all[(indegree .> thresh_indeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_all_sum_hi = mean(nb_neigbors_all_sum[(indegree .> thresh_indeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_down_ho = mean(nb_neigbors_down[(outdegree .> thresh_outdeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_up_ho = mean(nb_neigbors_up[(outdegree .> thresh_outdeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_all_ho = mean(nb_neigbors_all[(outdegree .> thresh_outdeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_all_sum_ho = mean(nb_neigbors_all_sum[(outdegree .> thresh_outdeg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_down_hd = mean(nb_neigbors_down[(outdegree + indegree .> thresh_deg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_up_hd = mean(nb_neigbors_up[(outdegree + indegree .> thresh_deg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_all_hd = mean(nb_neigbors_all[(outdegree + indegree .> thresh_deg) .& (firm_exits .== 1),:],1)'
    mean_neighbors_all_sum_hd = mean(nb_neigbors_all_sum[(outdegree + indegree .> thresh_deg) .& (firm_exits .== 1),:],1)'


    # Data structures for the regressions

    # For all firms
    reg_coeff_down_all,reg_coeff_up_all,reg_coeff_all_all,reg_coeff_all_sum_all = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)     # Regression coeff
    reg_lb_down_all,reg_lb_up_all,reg_lb_all_all,reg_lb_all_sum_all = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)           # Lower bounds on interval
    reg_ub_down_all,reg_ub_up_all,reg_ub_all_all,reg_ub_all_sum_all = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)           # Upper bounds on interval

    # For high indegree
    reg_coeff_down_hi,reg_coeff_up_hi,reg_coeff_all_hi,reg_coeff_all_sum_hi = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)
    reg_lb_down_hi,reg_lb_up_hi,reg_lb_all_hi,reg_lb_all_sum_hi = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)
    reg_ub_down_hi,reg_ub_up_hi,reg_ub_all_hi,reg_ub_all_sum_hi = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)


    # For high outdegree
    reg_coeff_down_ho,reg_coeff_up_ho,reg_coeff_all_ho,reg_coeff_all_sum_ho = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)
    reg_lb_down_ho,reg_lb_up_ho,reg_lb_all_ho,reg_lb_all_sum_ho  = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)
    reg_ub_down_ho,reg_ub_up_ho,reg_ub_all_ho,reg_ub_all_sum_ho = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)

    # For high degree
    reg_coeff_down_hd,reg_coeff_up_hd,reg_coeff_all_hd,reg_coeff_all_sum_hd = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)
    reg_lb_down_hd,reg_lb_up_hd,reg_lb_all_hd,reg_lb_all_sum_hd = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)
    reg_ub_down_hd,reg_ub_up_hd,reg_ub_all_hd,reg_ub_all_sum_hd = zeros(max_depth),zeros(max_depth),zeros(max_depth),zeros(1)


    # Downstream impact of exit on all firms
    for i=1:max_depth
        formula_temp = Formula(Symbol("frac_$(i)d"), :(firm_exits + indegree + outdegree))


        # formula_temp = Formula(Symbol("frac_$(i)d"), :(firm_exits + year))
        try
            reg_temp_all = lm(formula_temp,data_all_firms)
            reg_coeff_down_all[i] = coef(reg_temp_all)[2]
            reg_lb_down_all[i] = coef(reg_temp_all)[2] - std_error_factor*stderror(reg_temp_all)[2]
            reg_ub_down_all[i] = coef(reg_temp_all)[2] + std_error_factor*stderror(reg_temp_all)[2]
        catch
            reg_coeff_down_all[i] = 0.0
            reg_lb_down_all[i] = 0.0
            reg_ub_down_all[i] = 0.0
        end
        try
            reg_temp_hi = lm(formula_temp,data_high_indegree)
            reg_coeff_down_hi[i] = coef(reg_temp_hi)[2]
            reg_lb_down_hi[i] = coef(reg_temp_hi)[2] - std_error_factor*stderror(reg_temp_hi)[2]
            reg_ub_down_hi[i] = coef(reg_temp_hi)[2] + std_error_factor*stderror(reg_temp_hi)[2]
        catch
            reg_coeff_down_hi[i] = 0.0
            reg_lb_down_hi[i] = 0.0
            reg_ub_down_hi[i] = 0.0
        end
        try
            reg_temp_ho = lm(formula_temp,data_high_outdegree)
            reg_coeff_down_ho[i] = coef(reg_temp_ho)[2]
            reg_lb_down_ho[i] = coef(reg_temp_ho)[2] - std_error_factor*stderror(reg_temp_ho)[2]
            reg_ub_down_ho[i] = coef(reg_temp_ho)[2] + std_error_factor*stderror(reg_temp_ho)[2]
        catch
            reg_coeff_down_ho[i] = 0.0
            reg_lb_down_ho[i] = 0.0
            reg_ub_down_ho[i] = 0.0
        end
        try
            reg_temp_hd = lm(formula_temp,data_high_degree)
            reg_coeff_down_hd[i] = coef(reg_temp_hd)[2]
            reg_lb_down_hd[i] = coef(reg_temp_hd)[2] - std_error_factor*stderror(reg_temp_hd)[2]
            reg_ub_down_hd[i] = coef(reg_temp_hd)[2] + std_error_factor*stderror(reg_temp_hd)[2]
        catch
            reg_coeff_down_hd[i] = 0.0
            reg_lb_down_hd[i] = 0.0
            reg_ub_down_hd[i] = 0.0
        end

        # Upstream
        # formula_temp = Formula(Symbol("frac_$(i)u"), :(firm_exits + year + indegree + outdegree))
        formula_temp = Formula(Symbol("frac_$(i)u"), :(firm_exits + indegree + outdegree))
        # formula_temp = Formula(Symbol("frac_$(i)u"), :(firm_exits + centrality))
        # formula_temp = Formula(Symbol("frac_$(i)u"), :(firm_exits + year + centrality))
        # formula_temp = Formula(Symbol("frac_$(i)u"), :(firm_exits + year))
        # formula_temp = Formula(Symbol("frac_$(i)u"), :(firm_exits))
        try
            reg_temp_all = lm(formula_temp,data_all_firms)
            reg_coeff_up_all[i] = coef(reg_temp_all)[2]
            reg_lb_up_all[i] = coef(reg_temp_all)[2] - std_error_factor*stderror(reg_temp_all)[2]
            reg_ub_up_all[i] = coef(reg_temp_all)[2] + std_error_factor*stderror(reg_temp_all)[2]
        catch
            reg_coeff_up_all[i] = 0.0
            reg_lb_up_all[i] = 0.0
            reg_ub_up_all[i] = 0.0
        end
        try
            reg_temp_hi = lm(formula_temp,data_high_indegree)
            reg_coeff_up_hi[i] = coef(reg_temp_hi)[2]
            reg_lb_up_hi[i] = coef(reg_temp_hi)[2] - std_error_factor*stderror(reg_temp_hi)[2]
            reg_ub_up_hi[i] = coef(reg_temp_hi)[2] + std_error_factor*stderror(reg_temp_hi)[2]
        catch
            reg_coeff_up_hi[i] = 0.0
            reg_lb_up_hi[i] = 0.0
            reg_ub_up_hi[i] = 0.0
        end
        try
            reg_temp_ho = lm(formula_temp,data_high_outdegree)
            reg_coeff_up_ho[i] = coef(reg_temp_ho)[2]
            reg_lb_up_ho[i] = coef(reg_temp_ho)[2] - std_error_factor*stderror(reg_temp_ho)[2]
            reg_ub_up_ho[i] = coef(reg_temp_ho)[2] + std_error_factor*stderror(reg_temp_ho)[2]
        catch
            reg_coeff_up_ho[i] = 0.0
            reg_lb_up_ho[i] = 0.0
            reg_ub_up_ho[i] = 0.0
        end
        try
            reg_temp_hd = lm(formula_temp,data_high_degree)
            reg_coeff_up_hd[i] = coef(reg_temp_hd)[2]
            reg_lb_up_hd[i] = coef(reg_temp_hd)[2] - std_error_factor*stderror(reg_temp_hd)[2]
            reg_ub_up_hd[i] = coef(reg_temp_hd)[2] + std_error_factor*stderror(reg_temp_hd)[2]
        catch
            reg_coeff_up_hd[i] = 0.0
            reg_lb_up_hd[i] = 0.0
            reg_ub_up_hd[i] = 0.0
        end



        # All neighbors
        formula_temp = Formula(Symbol("frac_$(i)a"), :(firm_exits + indegree + outdegree))

        try
            reg_temp_all = lm(formula_temp,data_all_firms)
            reg_coeff_all_all[i] = coef(reg_temp_all)[2]
            reg_lb_all_all[i] = coef(reg_temp_all)[2] - std_error_factor*stderror(reg_temp_all)[2]
            reg_ub_all_all[i] = coef(reg_temp_all)[2] + std_error_factor*stderror(reg_temp_all)[2]
        catch
            reg_coeff_all_all[i] = 0.0
            reg_lb_all_all[i] = 0.0
            reg_ub_all_all[i] = 0.0
        end
        try
            reg_temp_hi = lm(formula_temp,data_high_indegree)
            reg_coeff_all_hi[i] = coef(reg_temp_hi)[2]
            reg_lb_all_hi[i] = coef(reg_temp_hi)[2] - std_error_factor*stderror(reg_temp_hi)[2]
            reg_ub_all_hi[i] = coef(reg_temp_hi)[2] + std_error_factor*stderror(reg_temp_hi)[2]
        catch
            reg_coeff_all_hi[i] = 0.0
            reg_lb_all_hi[i] = 0.0
            reg_ub_all_hi[i] = 0.0
        end
        try
            reg_temp_ho = lm(formula_temp,data_high_outdegree)
            reg_coeff_all_ho[i] = coef(reg_temp_ho)[2]
            reg_lb_all_ho[i] = coef(reg_temp_ho)[2] - std_error_factor*stderror(reg_temp_ho)[2]
            reg_ub_all_ho[i] = coef(reg_temp_ho)[2] + std_error_factor*stderror(reg_temp_ho)[2]
        catch
            reg_coeff_all_ho[i] = 0.0
            reg_lb_all_ho[i] = 0.0
            reg_ub_all_ho[i] = 0.0
        end
        try
            reg_temp_hd = lm(formula_temp,data_high_degree)
            reg_coeff_all_hd[i] = coef(reg_temp_hd)[2]
            reg_lb_all_hd[i] = coef(reg_temp_hd)[2] - std_error_factor*stderror(reg_temp_hd)[2]
            reg_ub_all_hd[i] = coef(reg_temp_hd)[2] + std_error_factor*stderror(reg_temp_hd)[2]
        catch
            reg_coeff_all_hd[i] = 0.0
            reg_lb_all_hd[i] = 0.0
            reg_ub_all_hd[i] = 0.0
        end
    end

    # All neighbors sum
    formula_temp = Formula(Symbol("fraction_all_sum"), :(firm_exits + indegree + outdegree))
    try
        reg_temp_all_sum = lm(formula_temp,data_all_firms)
        reg_coeff_all_sum_all = coef(reg_temp_all_sum)[2]
        reg_lb_all_sum_all = coef(reg_temp_all_sum)[2] - std_error_factor*stderror(reg_temp_all_sum)[2]
        reg_ub_all_sum_all = coef(reg_temp_all_sum)[2] + std_error_factor*stderror(reg_temp_all_sum)[2]
    catch
        reg_coeff_all_sum_all = 0.0
        reg_lb_all_sum_all = 0.0
        reg_ub_all_sum_all = 0.0
    end
    try
        reg_temp_hi = lm(formula_temp,data_high_indegree)
        reg_coeff_all_sum_hi = coef(reg_temp_hi)[2]
        reg_lb_all_sum_hi = coef(reg_temp_hi)[2] - std_error_factor*stderror(reg_temp_hi)[2]
        reg_ub_all_sum_hi = coef(reg_temp_hi)[2] + std_error_factor*stderror(reg_temp_hi)[2]
    catch
        reg_coeff_all_sum_hi = 0.0
        reg_lb_all_sum_hi = 0.0
        reg_ub_all_sum_hi = 0.0
    end
    try
        reg_temp_ho = lm(formula_temp,data_high_outdegree)
        reg_coeff_all_sum_ho = coef(reg_temp_ho)[2]
        reg_lb_all_sum_ho = coef(reg_temp_ho)[2] - std_error_factor*stderror(reg_temp_ho)[2]
        reg_ub_all_sum_ho = coef(reg_temp_ho)[2] + std_error_factor*stderror(reg_temp_ho)[2]
    catch
        reg_coeff_all_sum_ho = 0.0
        reg_lb_all_sum_ho = 0.0
        reg_ub_all_sum_ho = 0.0
    end
    try
        reg_temp_hd = lm(formula_temp,data_high_degree)
        reg_coeff_all_sum_hd = coef(reg_temp_hd)[2]
        reg_lb_all_sum_hd = coef(reg_temp_hd)[2] - std_error_factor*stderror(reg_temp_hd)[2]
        reg_ub_all_sum_hd = coef(reg_temp_hd)[2] + std_error_factor*stderror(reg_temp_hd)[2]
    catch
        reg_coeff_all_sum_hd = 0.0
        reg_lb_all_sum_hd = 0.0
        reg_ub_all_sum_hd = 0.0
    end


    number_coeff_up_all = reg_coeff_up_all.*mean_neighbors_up_all
    number_lb_up_all = reg_lb_up_all.*mean_neighbors_up_all
    number_ub_up_all = reg_ub_up_all.*mean_neighbors_up_all

    number_coeff_down_all = reg_coeff_down_all.*mean_neighbors_down_all
    number_lb_down_all = reg_lb_down_all.*mean_neighbors_down_all
    number_ub_down_all = reg_ub_down_all.*mean_neighbors_down_all

    number_coeff_all_all = reg_coeff_all_all.*mean_neighbors_all_all
    number_lb_all_all = reg_lb_all_all.*mean_neighbors_all_all
    number_ub_all_all = reg_ub_all_all.*mean_neighbors_all_all

    number_coeff_all_sum_all = reg_coeff_all_sum_all.*mean_neighbors_all_sum_all
    number_lb_all_sum_all = reg_lb_all_sum_all.*mean_neighbors_all_sum_all
    number_ub_all_sum_all = reg_ub_all_sum_all.*mean_neighbors_all_sum_all

    number_coeff_up_hi = reg_coeff_up_hi.*mean_neighbors_up_hi
    number_lb_up_hi = reg_lb_up_hi.*mean_neighbors_up_hi
    number_ub_up_hi = reg_ub_up_hi.*mean_neighbors_up_hi

    number_coeff_down_hi = reg_coeff_down_hi.*mean_neighbors_down_hi
    number_lb_down_hi = reg_lb_down_hi.*mean_neighbors_down_hi
    number_ub_down_hi = reg_ub_down_hi.*mean_neighbors_down_hi

    number_coeff_all_hi = reg_coeff_all_hi.*mean_neighbors_all_hi
    number_lb_all_hi = reg_lb_all_hi.*mean_neighbors_all_hi
    number_ub_all_hi = reg_ub_all_hi.*mean_neighbors_all_hi

    number_coeff_all_sum_hi = reg_coeff_all_sum_hi.*mean_neighbors_all_sum_hi
    number_lb_all_sum_hi = reg_lb_all_sum_hi.*mean_neighbors_all_sum_hi
    number_ub_all_sum_hi = reg_ub_all_sum_hi.*mean_neighbors_all_sum_hi

    number_coeff_up_ho = reg_coeff_up_ho.*mean_neighbors_up_ho
    number_lb_up_ho = reg_lb_up_ho.*mean_neighbors_up_ho
    number_ub_up_ho = reg_ub_up_ho.*mean_neighbors_up_ho

    number_coeff_down_ho = reg_coeff_down_ho.*mean_neighbors_down_ho
    number_lb_down_ho = reg_lb_down_ho.*mean_neighbors_down_ho
    number_ub_down_ho = reg_ub_down_ho.*mean_neighbors_down_ho

    number_coeff_all_ho = reg_coeff_all_ho.*mean_neighbors_all_ho
    number_lb_all_ho = reg_lb_all_ho.*mean_neighbors_all_ho
    number_ub_all_ho = reg_ub_all_ho.*mean_neighbors_all_ho

    number_coeff_all_sum_ho = reg_coeff_all_sum_ho.*mean_neighbors_all_sum_ho
    number_lb_all_sum_ho = reg_lb_all_sum_ho.*mean_neighbors_all_sum_ho
    number_ub_all_sum_ho = reg_ub_all_sum_ho.*mean_neighbors_all_sum_ho

    number_coeff_up_hd = reg_coeff_up_hd.*mean_neighbors_up_hd
    number_lb_up_hd = reg_lb_up_hd.*mean_neighbors_up_hd
    number_ub_up_hd = reg_ub_up_hd.*mean_neighbors_up_hd

    number_coeff_down_hd = reg_coeff_down_hd.*mean_neighbors_down_hd
    number_lb_down_hd = reg_lb_down_hd.*mean_neighbors_down_hd
    number_ub_down_hd = reg_ub_down_hd.*mean_neighbors_down_hd

    number_coeff_all_hd = reg_coeff_all_hd.*mean_neighbors_all_hd
    number_lb_all_hd = reg_lb_all_hd.*mean_neighbors_all_hd
    number_ub_all_hd = reg_ub_all_hd.*mean_neighbors_all_hd

    number_coeff_all_sum_hd = reg_coeff_all_sum_hd.*mean_neighbors_all_sum_hd
    number_lb_all_sum_hd = reg_lb_all_sum_hd.*mean_neighbors_all_sum_hd
    number_ub_all_sum_hd = reg_ub_all_sum_hd.*mean_neighbors_all_sum_hd

    # Write everything to files
    print_with_color(:blue, "\n\nCascades fractions\n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  All firms upstream         = $reg_coeff_up_all")
    println("  High indegree upstream     = $reg_coeff_up_hi")
    println("  High outdegree upstream    = $reg_coeff_up_ho")
    println("  High degree upstream       = $reg_coeff_up_hd")
    println()
    println("  All firms downstream       = $reg_coeff_down_all")
    println("  High indegree downstream   = $reg_coeff_down_hi")
    println("  High outdegree downstream  = $reg_coeff_down_ho")
    println("  High degree downstream     = $reg_coeff_down_hd")
    println()
    println("  All firms all neighbors    = $reg_coeff_all_all")
    println("  High indegree all          = $reg_coeff_all_hi")
    println("  High outdegree all         = $reg_coeff_all_ho")
    println("  High degree all            = $reg_coeff_all_hd")
    println()
    println("  All firms all neighbors sum = $reg_coeff_all_sum_all")
    println("  High indegree all sum       = $reg_coeff_all_sum_hi")
    println("  High outdegree all sum      = $reg_coeff_all_sum_ho")
    println("  High degree all sum         = $reg_coeff_all_sum_hd")

    print_with_color(:blue, "\n\nCascades numbers\n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  All firms upstream         = $number_coeff_up_all")
    println("  High indegree upstream     = $number_coeff_up_hi")
    println("  High outdegree upstream    = $number_coeff_up_ho")
    println("  High degree upstream       = $number_coeff_up_hd")
    println()
    println("  All firms downstream       = $number_coeff_down_all")
    println("  High indegree downstream   = $number_coeff_down_hi")
    println("  High outdegree downstream  = $number_coeff_down_ho")
    println("  High degree downstream     = $number_coeff_down_hd")
    println()
    println("  All firms all neighbors    = $number_coeff_all_all")
    println("  High indegree all          = $number_coeff_all_hi")
    println("  High outdegree all         = $number_coeff_all_ho")
    println("  High degree all            = $number_coeff_all_hd")
    println()
    println("  All firms all neighbors sum = $number_coeff_all_sum_all")
    println("  High indegree all sum       = $number_coeff_all_sum_hi")
    println("  High outdegree all sum      = $number_coeff_all_sum_ho")
    println("  High degree all sum         = $number_coeff_all_sum_hd")

    nb_neighbors = 2
    print_with_color(:blue, "\n\nNumber of exits up to $nb_neighbors neighbors\n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  All firms                  = $(sum(number_coeff_up_all[1:nb_neighbors]+number_coeff_down_all[1:nb_neighbors]))")
    println("  High indegree              = $(sum(number_coeff_up_hi[1:nb_neighbors]+number_coeff_down_hi[1:nb_neighbors]))")
    println("  High outdegree             = $(sum(number_coeff_up_ho[1:nb_neighbors]+number_coeff_down_ho[1:nb_neighbors]))")
    println("  High degree                = $(sum(number_coeff_up_hd[1:nb_neighbors]+number_coeff_down_hd[1:nb_neighbors]))")
    println()
    println("  All firms all neighbors")
    println("  All firms                  = $(sum(number_coeff_all_all[1:nb_neighbors]))")
    println("  High indegree              = $(sum(number_coeff_all_hi[1:nb_neighbors]))")
    println("  High outdegree             = $(sum(number_coeff_all_ho[1:nb_neighbors]))")
    println("  High degree                = $(sum(number_coeff_all_hd[1:nb_neighbors]))")
    println()
    println("  All firms all neighbors sum")
    println("  All firms                  = $(number_coeff_all_sum_all)")
    println("  High indegree              = $(number_coeff_all_sum_hi)")
    println("  High outdegree             = $(number_coeff_all_sum_ho)")
    println("  High degree                = $(number_coeff_all_sum_hd)")
    println()



    writedlm("$dir/cascades_fraction_up_all_$suffix",[(1:max_depth) reg_coeff_up_all reg_lb_up_all reg_ub_up_all])
    writedlm("$dir/cascades_fraction_down_all_$suffix",[(1:max_depth) reg_coeff_down_all reg_lb_down_all reg_ub_down_all])
    writedlm("$dir/cascades_fraction_all_all_$suffix",[(1:max_depth) reg_coeff_all_all reg_lb_all_all reg_ub_all_all])
    writedlm("$dir/cascades_fraction_up_hi_$suffix",[(1:max_depth) reg_coeff_up_hi reg_lb_up_hi reg_ub_up_hi])
    writedlm("$dir/cascades_fraction_down_hi_$suffix",[(1:max_depth) reg_coeff_down_hi reg_lb_down_hi reg_ub_down_hi])
    writedlm("$dir/cascades_fraction_all_hi_$suffix",[(1:max_depth) reg_coeff_all_hi reg_lb_all_hi reg_ub_all_hi])
    writedlm("$dir/cascades_fraction_up_ho_$suffix",[(1:max_depth) reg_coeff_up_ho reg_lb_up_ho reg_ub_up_ho])
    writedlm("$dir/cascades_fraction_down_ho_$suffix",[(1:max_depth) reg_coeff_down_ho reg_lb_down_ho reg_ub_down_ho])
    writedlm("$dir/cascades_fraction_all_ho_$suffix",[(1:max_depth) reg_coeff_all_ho reg_lb_all_ho reg_ub_all_ho])
    writedlm("$dir/cascades_fraction_up_hd_$suffix",[(1:max_depth) reg_coeff_up_hd reg_lb_up_hd reg_ub_up_hd])
    writedlm("$dir/cascades_fraction_down_hd_$suffix",[(1:max_depth) reg_coeff_down_hd reg_lb_down_hd reg_ub_down_hd])
    writedlm("$dir/cascades_fraction_all_hd_$suffix",[(1:max_depth) reg_coeff_all_hd reg_lb_all_hd reg_ub_all_hd])

    writedlm("$dir/cascades_number_up_all",[(1:max_depth) number_coeff_up_all number_lb_up_all number_ub_up_all])
    writedlm("$dir/cascades_number_down_all",[(1:max_depth) number_coeff_down_all number_lb_down_all number_ub_down_all])
    writedlm("$dir/cascades_number_all_all",[(1:max_depth) number_coeff_all_all number_lb_all_all number_ub_all_all])
    writedlm("$dir/cascades_number_up_hi",[(1:max_depth) number_coeff_up_hi number_lb_up_hi number_ub_up_hi])
    writedlm("$dir/cascades_number_down_hi",[(1:max_depth) number_coeff_down_hi number_lb_down_hi number_ub_down_hi])
    writedlm("$dir/cascades_number_all_hi",[(1:max_depth) number_coeff_all_hi number_lb_all_hi number_ub_all_hi])
    writedlm("$dir/cascades_number_up_ho",[(1:max_depth) number_coeff_up_ho number_lb_up_ho number_ub_up_ho])
    writedlm("$dir/cascades_number_down_ho",[(1:max_depth) number_coeff_down_ho number_lb_down_ho number_ub_down_ho])
    writedlm("$dir/cascades_number_all_ho",[(1:max_depth) number_coeff_all_ho number_lb_all_ho number_ub_all_ho])
    writedlm("$dir/cascades_number_up_hd",[(1:max_depth) number_coeff_up_hd number_lb_up_hd number_ub_up_hd])
    writedlm("$dir/cascades_number_down_hd",[(1:max_depth) number_coeff_down_hd number_lb_down_hd number_ub_down_hd])
    writedlm("$dir/cascades_number_all_hd",[(1:max_depth) number_coeff_all_hd number_lb_all_hd number_ub_all_hd])

    # Option of returning something to calibrate model
    loss = Inf
    return loss
end



# This function uses the output of build_cascades_data and computes the probability
# that a firm exits as a function of its indegree and outdegree

function compute_exit_probability(firm_id,year,firm_exits,indegree,outdegree,dir,suffix)
    max_depth = 5

    data_all_firms = DataFrame(firm_id=firm_id
                                ,year=year
                                ,firm_exits=firm_exits
                                ,indegree=indegree
                                ,outdegree=outdegree)


    pct_thresh = 95
    thresh_indeg  = percentile(data_all_firms[:indegree],pct_thresh)
    thresh_outdeg  = percentile(data_all_firms[:outdegree],pct_thresh)
    thresh_deg  = percentile(data_all_firms[:outdegree]+data_all_firms[:indegree],pct_thresh)

    data_high_indegree = data_all_firms[data_all_firms[:,:indegree].>thresh_indeg,:]
    data_high_outdegree = data_all_firms[data_all_firms[:,:outdegree].>thresh_outdeg,:]
    data_high_degree = data_all_firms[data_all_firms[:,:outdegree] + data_all_firms[:,:indegree] .> thresh_deg,:]

    proba_exit_all = mean(data_all_firms[:firm_exits])
    proba_exit_hi = mean(data_high_indegree[:firm_exits])
    proba_exit_ho = mean(data_high_outdegree[:firm_exits])
    proba_exit_hd = mean(data_high_degree[:firm_exits])

    print_with_color(:blue, "\n\nProbability of firm exit \n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  All firms      = $proba_exit_all")
    println("  High indegree  = $proba_exit_hi")
    println("  High outdegree = $proba_exit_ho")
    println("  High degree    = $proba_exit_hd")
    println()
    println()


    writedlm("$dir/exit_probability_$suffix",hcat(["proba_exit_all","proba_exit_hi","proba_exit_ho","proba_exit_hd"],[proba_exit_all,proba_exit_hi,proba_exit_ho,proba_exit_hd]))

    # Use the following to compute a loss to calibrate the model
    # These numbers are with 90 threshold
    proba_exit_all_data = 0.12166279698482872
    proba_exit_hi_data = 0.026797217212058747
    proba_exit_ho_data = 0.041641151255358236
    proba_exit_hd_data = 0.03362456976436325

    # loss_contrib(x,y) = sum(abs.((x-y)./y))
        loss_contrib(x,y) = sum(abs.(x-y))

    # loss = loss_contrib(proba_exit_all,proba_exit_all_data)
    #      + loss_contrib(proba_exit_hi,proba_exit_hi_data)
    #      + loss_contrib(proba_exit_ho,proba_exit_ho_data)
    #      + loss_contrib(proba_exit_hd,proba_exit_hd_data)

    loss = (loss_contrib(proba_exit_all,proba_exit_all_data)
         + loss_contrib(proba_exit_hd,proba_exit_hd_data))

    return loss
end


function analyze_cascades(simul_array,dir,suffix)
    n = simul_array[1].param.n
    number_seeds = length(simul_array)
    n_simul_per_seed = simul_array[1].n_simul

    direct_networks_dict = Dict{Int64,LightGraphs.DiGraph}()
    reverse_networks_dict = Dict{Int64,LightGraphs.DiGraph}()
    undirected_network_dict = Dict{Int64,LightGraphs.DiGraph}()

    valid_exit_year_dict = Dict{Int64,Bool}()

    current_year = 0

    # Use only some of the seeds to avoid overlong computations
    # Warning the code must be adapted if more than 1
    number_seeds_to_use = number_seeds
    # number_seeds_to_use = 1

    # Build a network for each year
    for i_seed = 1:number_seeds_to_use
        Ω = copy(simul_array[i_seed].param.Ω)
        for i_simul = 1:n_simul_per_seed
            current_year += 1

            valid_exit_year_dict[current_year] = (i_simul == n_simul_per_seed ? false : true)

            # Initialize an n-network
            Θ = copy(simul_array[i_seed].Θ_stor[i_simul,:])
            g = copy(LightGraphs.DiGraph(build_active_network_matrix(Ω,Θ)))

            direct_networks_dict[current_year] = g
            reverse_networks_dict[current_year] = build_inverse_graph(g)
            undirected_network_dict[current_year] = build_undirected_graph(g)
        end
    end

    # Keep track of firms destroyed in a given year
    firm_destruct = falses(number_seeds_to_use*n_simul_per_seed,n)

    current_year = 0
    for i_seed = 1:number_seeds_to_use
        for i_simul = 1:n_simul_per_seed
            current_year += 1
            if valid_exit_year_dict[current_year]
                for i = 1:n
                    if simul_array[i_seed].Θ_stor[i_simul,i] == 1 && simul_array[i_seed].Θ_stor[i_simul+1,i] == 0
                        firm_destruct[current_year,i] = true
                    end
                end
            end
        end
    end


    firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits = build_cascades_data(direct_networks_dict,reverse_networks_dict,undirected_network_dict,valid_exit_year_dict,n,1,number_seeds_to_use*n_simul_per_seed,firm_destruct,dir,suffix)

    loss_cascade = regression_cascades(firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits,dir,suffix)

    loss_exit = compute_exit_probability(firm_id,year,firm_exits,indegree,outdegree,dir,suffix)
    # return loss_cascade + loss_exit
    return loss_exit
end
