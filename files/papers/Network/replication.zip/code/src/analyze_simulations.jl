# Functions to compute simulations moments

function analyze_simulations(array_simul,dir,label,compute_cascades=false,compute_omega=false)

    C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul)


    array_networks = build_graph(array_simul,true) # Network of active connections
    array_networks_omega = build_graph(array_simul,false) # Network described by Ω

    indeg_alpha,outdeg_alpha,central_alpha,clustering,nb_active_firms = compute_network_aggregate(array_networks)
    indeg,outdeg,central,local_clustering_coeff = compute_network_firm_char(array_networks)

    if compute_omega
        indeg_alpha_omega,outdeg_alpha_omega,central_alpha_omega,clustering_omega,nb_active_firms_omega = compute_network_aggregate(array_networks_omega)
        indeg_omega,outdeg_omega,central_omega,local_clustering_coeff_omega = compute_network_firm_char(array_networks_omega)
    end




    q,y,l = compute_firm_char(array_simul)

    print_degree_distributions(array_networks,"simulated_data/time_series/$dir",label)

    loss = print_aggregates(C,Q,sumΘ,L_less_f,indeg_alpha,outdeg_alpha,central_alpha,clustering,nb_active_firms,"simulated_data/time_series/$dir",label)
    print_ind_char_active(q,y,l,indeg,outdeg,central,"simulated_data/time_series/$dir",label)

    if compute_omega
        # Print moments using Ω as network
        print_aggregates(C,Q,sumΘ,L_less_f,indeg_alpha_omega,outdeg_alpha_omega,central_alpha_omega,clustering_omega,nb_active_firms_omega,"simulated_data/time_series/$dir","$(label)_omega")
        print_ind_char_active(q,y,l,indeg_omega,outdeg_omega,central_omega,"simulated_data/time_series/$dir","$(label)_omega")

        # Compute how far apart are local_custering in the network vs in Ω
        percent_dev = distance_local_clustering(local_clustering_coeff,local_clustering_coeff_omega)
        println("The percentage of the abolute value of the difference in local clustering coeff between the network and ⁠Ω is $percent_dev %")
    end

    if compute_cascades
        loss_cascades = analyze_cascades(array_simul,"simulated_data/time_series/$dir","free")
        loss = loss + loss_cascades
    end

    return loss
end


# These functions compute the aggregates related to the business cycles (C,Q,sum(θ),L-f*sum(θ))
function compute_business_cycles_aggregate(array_simul::Array{Simulation})
    nb_seeds = length(array_simul)
    n_simul = array_simul[1].n_simul

    C,Q,sumΘ,L_less_f = zeros(nb_seeds,n_simul),zeros(nb_seeds,n_simul),zeros(nb_seeds,n_simul),zeros(nb_seeds,n_simul)

    for i_seed = 1:nb_seeds
        C[i_seed,:],Q[i_seed,:],sumΘ[i_seed,:],L_less_f[i_seed,:] = compute_business_cycles_aggregate(array_simul[i_seed])
    end

    return C,Q,sumΘ,L_less_f
end


function compute_business_cycles_aggregate(simul::Simulation)
    n_simul = simul.n_simul
    n = simul.param.n
    f = simul.param.f
    σ = simul.param.σ
    L = 1.0

    C,Q,sumΘ,L_less_f = zeros(n_simul),zeros(n_simul),zeros(n_simul),zeros(n_simul)

    for t = 1:n_simul
        Q[t] = (sum(simul.q_stor[t,:].^(σ-1)))^(1/(σ-1))
        sumΘ[t] = sum(simul.Θ_stor[t,:])
        L_less_f[t] = L - f*sumΘ[t]
        C[t] = Q[t]*L_less_f[t]
    end

    return C,Q,sumΘ,L_less_f
end

# This function returns firm-specific quantities: q,y,l
function compute_firm_char(array_simul::Array{Simulation})
    nb_seeds = length(array_simul)
    n_simul = array_simul[1].n_simul
    n = array_simul[1].param.n

    q,y,l,c = zeros(nb_seeds,n_simul,n),zeros(nb_seeds,n_simul,n),zeros(nb_seeds,n_simul,n),zeros(nb_seeds,n_simul,n)

    for i_seed = 1:nb_seeds
        q[i_seed,:,:],y[i_seed,:,:],l[i_seed,:,:],c[i_seed,:,:] = compute_firm_char(array_simul[i_seed])
    end

    return q,y,l,c
end


function compute_firm_char(simul::Simulation)
    n_simul = simul.n_simul
    n = simul.param.n

    q,y,l,c = zeros(n_simul,n),zeros(n_simul,n),zeros(n_simul,n),zeros(n_simul,n)

    for t = 1:n_simul
        q[t,:] = simul.q_stor[t,:]
        y[t,:],l[t,:],c[t,:] = solve_ind_from_q(simul.param,q[t,:],simul.Θ_stor[t,:],simul.z_stor[t,:])
    end

    return q,y,l,c
end




# These functions compute the aggregates related to the active network (indeg_alpha,outdeg_alpha,clustering)

function compute_network_aggregate(array_networks::Array{DiGraph})

    n_seeds = size(array_networks)[1]
    n_simul = size(array_networks)[2]
    n = nv(array_networks[1])

    print_with_color(:black, "\n ... indeg and outdeg shape parameters only on firms with more than 1 nodes\n",bold=true)

    indeg_alpha,outdeg_alpha,central_alpha,clustering,nb_active_firms = zeros(n_seeds,n_simul),zeros(n_seeds,n_simul),zeros(n_seeds,n_simul),zeros(n_seeds,n_simul),zeros(n_seeds,n_simul)

    for i_seed = 1:n_seeds
        for i_simul = 1:n_simul
            indeg_temp = indegree(array_networks[i_seed,i_simul])
            outdeg_temp = outdegree(array_networks[i_seed,i_simul])
            central_temp = eigenvector_centrality(array_networks[i_seed,i_simul])

            # println("Careful here")
            indeg_alpha[i_seed,i_simul] = pareto_alpha_estimate_only_pos(indeg_temp,1)
            outdeg_alpha[i_seed,i_simul] = pareto_alpha_estimate_only_pos(outdeg_temp,1)
            central_alpha[i_seed,i_simul] = pareto_alpha_estimate_only_pos(central_temp,eps()) # Firms below eps() are not operating

            clustering[i_seed,i_simul] = custom_clustering_coefficient(array_networks[i_seed,i_simul],false) # Normalized clustering coeff
            nb_active_firms[i_seed,i_simul] = count_active_firms(array_networks[i_seed,i_simul])
        end
    end

    return indeg_alpha,outdeg_alpha,central_alpha,clustering,nb_active_firms
end

# Compute the individual indeg and outdeg of each firm
function compute_network_firm_char(array_networks::Array{DiGraph})
    # array_networks is the network of active links
    # array_networks_omega is the network Omega


    n_seeds = size(array_networks)[1]
    n_simul = size(array_networks)[2]
    n = nv(array_networks[1])

    indeg,outdeg,central,local_clustering_coeff = zeros(n_seeds,n_simul,n),zeros(n_seeds,n_simul,n),zeros(n_seeds,n_simul,n),zeros(n_seeds,n_simul,n)

    for i_seed = 1:n_seeds
        for i_simul = 1:n_simul
            indeg[i_seed,i_simul,:] = indegree(array_networks[i_seed,i_simul])
            outdeg[i_seed,i_simul,:] = outdegree(array_networks[i_seed,i_simul])
            central[i_seed,i_simul,:] = degree_centrality(array_networks[i_seed,i_simul])
            local_clustering_coeff[i_seed,i_simul,:] = local_clustering_coefficient(array_networks[i_seed,i_simul],1:n)
        end
    end
    return indeg,outdeg,central,local_clustering_coeff
end

# This functions compute how far apart are local_clustering_coeff and local_clustering_coeff_omega
# The metric is percentage deviation
function distance_local_clustering(local_clustering_coeff,local_clustering_coeff_omega)

    percent_dev = (local_clustering_coeff - local_clustering_coeff_omega)./local_clustering_coeff_omega
    avg_percent_dev = mean(percent_dev[local_clustering_coeff.>eps()])
    return avg_percent_dev*100
end


# Print the degree distribution in files
function print_degree_distributions(array_networks::Array{DiGraph},dir,suffix)
    x_in,y_in,x_out,y_out = degree_distributions(array_networks)

    writedlm("$dir/indegree_$suffix",[x_in y_in])
    writedlm("$dir/outdegree_$suffix",[x_out y_out])
end


# This function prints several moments of aggregate variables and their correlation with output
function print_aggregates(C,Q,sumΘ,L_less_f,indeg_alpha,outdeg_alpha,central_alpha,clustering,nb_active_firms,dir,suffix)

    data = Dict("C" => log.(C), "Q" => log.(Q), "sumΘ" => log.(sumΘ), "L_less_f" => log.(L_less_f), "indeg_alpha" => log.(indeg_alpha), "outdeg_alpha" => log.(outdeg_alpha), "central_alpha" => log.(central_alpha), "clustering" => log.(clustering))

    mean_C,mean_Q,mean_sumΘ,mean_L_less_f,mean_indeg_alpha,mean_outdeg_alpha,mean_central_alpha,mean_clustering = 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
    std_C,std_Q,std_sumΘ,std_L_less_f,std_indeg_alpha,std_outdeg_alpha,std_central_alpha,std_clustering        = 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
    skew_C,skew_Q,skew_sumΘ,skew_L_less_f,skew_indeg_alpha,skew_outdeg_alpha,skew_central_alpha,skew_clustering = 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
    kurt_C,kurt_Q,kurt_sumΘ,kurt_L_less_f,kurt_indeg_alpha,kurt_outdeg_alpha,kurt_central_alpha,kurt_clustering = 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0

    corr_C_C,corr_C_Q,corr_C_sumΘ,corr_C_L_less_f,corr_C_indeg_alpha,corr_C_outdeg_alpha,corr_C_central_alpha,corr_C_clustering = 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0

    means = Dict("C" => mean_C, "Q" => mean_Q, "sumΘ" => mean_sumΘ, "L_less_f" => mean_L_less_f, "indeg_alpha" => mean_indeg_alpha, "outdeg_alpha" => mean_outdeg_alpha, "central_alpha" => mean_central_alpha, "clustering" => mean_clustering)
    stds = Dict("C" => std_C, "Q" => std_Q, "sumΘ" => std_sumΘ, "L_less_f" => std_L_less_f, "indeg_alpha" => std_indeg_alpha, "outdeg_alpha" => std_outdeg_alpha, "central_alpha" => std_central_alpha, "clustering" => std_clustering)
    skews = Dict("C" => skew_C, "Q" => skew_Q, "sumΘ" => skew_sumΘ, "L_less_f" => skew_L_less_f, "indeg_alpha" => skew_indeg_alpha, "outdeg_alpha" => skew_outdeg_alpha, "central_alpha" => skew_central_alpha, "clustering" => skew_clustering)
    kurts = Dict("C" => kurt_C, "Q" => kurt_Q, "sumΘ" => kurt_sumΘ, "L_less_f" => kurt_L_less_f, "indeg_alpha" => kurt_indeg_alpha, "outdeg_alpha" => kurt_outdeg_alpha, "central_alpha" => kurt_central_alpha, "clustering" => kurt_clustering)
    corr_Cs = Dict("C" => corr_C_C, "Q" => corr_C_Q, "sumΘ" => corr_C_sumΘ, "L_less_f" => corr_C_L_less_f, "indeg_alpha" => corr_C_indeg_alpha, "outdeg_alpha" => corr_C_outdeg_alpha, "central_alpha" => corr_C_central_alpha, "clustering" => corr_C_clustering)

    # Compute the means
    for symb = ["C","Q","sumΘ","L_less_f","indeg_alpha","outdeg_alpha","central_alpha","clustering"]
        means[symb]   = mean(StatsBase.mean(data[symb],2))
        stds[symb]    = mean(StatsBase.std(data[symb],2))
        # skews[symb]   = mean(StatsBase.skewness(data[symb],2))
        # kurts[symb]   = mean(StatsBase.kurtosis(data[symb],2))
        skews[symb]   = mean(skewness_col(data[symb]))
        kurts[symb]   = mean(kurtosis_col(data[symb]))
        corr_Cs[symb] = avg_corr_row(data[symb],data["C"])
    end

    to_print = ["moment" "C" "Q" "sumΘ" "L_less_f" "indeg_alpha" "outdeg_alpha" "central_alpha" "clustering"]

    to_print_means,to_print_stds,to_print_skews,to_print_kurts,to_print_corr_Cs = "mean","std","skew","kurt","corr_C"

    for symb = ["C","Q","sumΘ","L_less_f","indeg_alpha","outdeg_alpha","central_alpha","clustering"]
        to_print_means = hcat(to_print_means,means[symb])
        to_print_stds = hcat(to_print_stds,stds[symb])
        to_print_skews = hcat(to_print_skews,skews[symb])
        to_print_kurts = hcat(to_print_kurts,kurts[symb])
        to_print_corr_Cs = hcat(to_print_corr_Cs,corr_Cs[symb])
    end

    to_print = vcat(to_print,to_print_means,to_print_stds,to_print_skews,to_print_kurts,to_print_corr_Cs)

    writedlm("$dir/aggregates_$suffix",to_print)

    print_with_color(:blue, "\n\nBusiness cycles means (not logs) \n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  Mean of C                   = $(exp(means["C"]))")
    println("  Mean of Q                   = $(exp(means["Q"]))")
    println("  Mean of sumΘ                = $(exp(means["sumΘ"]))")

    print_with_color(:blue, "\n\nBusiness cycles standard deviations (logs) \n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  Std of C                    = $(stds["C"])")
    println("  Std of Q                    = $(stds["Q"])")
    println("  Std of sumΘ                 = $(stds["sumΘ"])")

    print_with_color(:blue, "\n\nBusiness cycles skewnesses (logs) \n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  Skew of C                    = $(skews["C"])")
    println("  Skew of Q                    = $(skews["Q"])")
    println("  Skew of sumΘ                 = $(skews["sumΘ"])")

    print_with_color(:blue, "\n\nBusiness cycles kurtosis (logs) \n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  Kurt of C                    = $(kurts["C"])")
    println("  Kurt of Q                    = $(kurts["Q"])")
    println("  Kurt of sumΘ                 = $(kurts["sumΘ"])")

    print_with_color(:blue, "\n\nMoments of the network (not logs)\n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  Mean of indegree alpha              = $(mean(indeg_alpha))")
    println("  Mean of outdegree alpha             = $(mean(outdeg_alpha))")
    println("  Mean of central alpha               = $(mean(central_alpha))")
    println("  Mean of clustering (normalized)     = $(mean(clustering.*sqrt.(nb_active_firms)))")
    println("  Mean of clustering (not normalized) = $(mean(clustering))")

    print_with_color(:blue, "\n\nCorrelation network and business cycles (logs) \n",bold=true)
    print_with_color(:red, "  $suffix network \n")
    println("  Corr C and indegree         = $(corr_Cs["indeg_alpha"])")
    println("  Corr C and outdegree        = $(corr_Cs["outdeg_alpha"])")
    println("  Corr C and central          = $(corr_Cs["central_alpha"])")
    println("  Corr C and clustering       = $(corr_Cs["clustering"])")
    println()
    println()

    # Compute some loss if we want to target moments
    loss = Inf

    return loss
end


# This function prints several moments of individual characteristics and their correlations (only for active firms! i.e. indeg>0,outdeg>0)
function print_ind_char_active(q,y,l,indeg,outdeg,central,dir,suffix)

    data = Dict("q" => log.(q), "y" => log.(y), "l" => log.(l), "indeg" => log.(indeg), "outdeg" => log.(outdeg), "central" => log.(central), "sales" => log.(y./q))

    mean_q,mean_y,mean_l,mean_indeg,mean_outdeg,mean_central,mean_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    std_q,std_y,std_l,std_indeg,std_outdeg,std_central,std_sales       = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    skew_q,skew_y,skew_l,skew_indeg,skew_outdeg,skew_central,skew_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    kurt_q,kurt_y,kurt_l,kurt_indeg,kurt_outdeg,kurt_central,kurt_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0

    corr_q_q,corr_q_y,corr_q_l,corr_q_indeg,corr_q_outdeg,corr_q_central,corr_q_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    corr_y_q,corr_y_y,corr_y_l,corr_y_indeg,corr_y_outdeg,corr_y_central,corr_y_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    corr_l_q,corr_l_y,corr_l_l,corr_l_indeg,corr_l_outdeg,corr_l_central,corr_l_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    corr_indeg_q,corr_indeg_y,corr_indeg_l,corr_indeg_indeg,corr_indeg_outdeg,corr_indeg_central,corr_indeg_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    corr_outdeg_q,corr_outdeg_y,corr_outdeg_l,corr_outdeg_indeg,corr_outdeg_outdeg,corr_outdeg_central,corr_outdeg_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    corr_central_q,corr_central_y,corr_central_l,corr_central_indeg,corr_central_outdeg,corr_central_central,corr_central_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0
    corr_sales_q,corr_sales_y,corr_sales_l,corr_sales_indeg,corr_sales_outdeg,corr_sales_central,corr_sales_sales = 0.0,0.0,0.0,0.0,0.0,0.0,0.0


    means = Dict("q" => mean_q, "y" => mean_y, "l" => mean_l, "indeg" => mean_indeg, "outdeg" => mean_outdeg, "central" => mean_central, "sales" => mean_sales)
    stds = Dict("q" => std_q, "y" => std_y, "l" => std_l, "indeg" => std_indeg, "outdeg" => std_outdeg, "central" => std_central, "sales" => std_sales)
    skews = Dict("q" => skew_q, "y" => skew_y, "l" => skew_l, "indeg" => skew_indeg, "outdeg" => skew_outdeg, "central" => skew_central, "sales" => skew_sales)
    kurts = Dict("q" => kurt_q, "y" => kurt_y, "l" => kurt_l, "indeg" => kurt_indeg, "outdeg" => kurt_outdeg, "central" => kurt_central, "sales" => kurt_sales)

    corr_qs = Dict("q" => corr_q_q, "y" => corr_q_y, "l" => corr_q_l, "indeg" => corr_q_indeg, "outdeg" => corr_q_outdeg, "central" => corr_q_central, "sales" => corr_q_sales)
    corr_ys = Dict("q" => corr_y_q, "y" => corr_y_y, "l" => corr_y_l, "indeg" => corr_y_indeg, "outdeg" => corr_y_outdeg, "central" => corr_y_central, "sales" => corr_y_sales)
    corr_ls = Dict("q" => corr_l_q, "y" => corr_l_y, "l" => corr_l_l, "indeg" => corr_l_indeg, "outdeg" => corr_l_outdeg, "central" => corr_l_central, "sales" => corr_l_sales)
    corr_indegs = Dict("q" => corr_indeg_q, "y" => corr_indeg_y, "l" => corr_indeg_l, "indeg" => corr_indeg_indeg, "outdeg" => corr_indeg_outdeg, "central" => corr_indeg_central, "sales" => corr_indeg_sales)
    corr_outdegs = Dict("q" => corr_outdeg_q, "y" => corr_outdeg_y, "l" => corr_outdeg_l, "indeg" => corr_outdeg_indeg, "outdeg" => corr_outdeg_outdeg, "central" => corr_outdeg_central, "sales" => corr_outdeg_sales)
    corr_centrals = Dict("q" => corr_central_q, "y" => corr_central_y, "l" => corr_central_l, "indeg" => corr_central_indeg, "outdeg" => corr_central_outdeg, "central" => corr_central_central, "sales" => corr_central_sales)
    corr_saless = Dict("q" => corr_sales_q, "y" => corr_sales_y, "l" => corr_sales_l, "indeg" => corr_sales_indeg, "outdeg" => corr_sales_outdeg, "central" => corr_sales_central, "sales" => corr_sales_sales)

    println(" ... mean q (no logs) = $(mean(q[q.>0]))")
    println(" ... Mean l (no logs) = $(mean(l[l.>0]))")

    # Compute the means
    for symb = ["q","y","l","indeg","outdeg","central","sales"]
        means[symb],stds[symb],skews[symb],kurts[symb] = mean_std_skew_kurt_noInf_dim3(data[symb])

        corr_qs[symb] = avg_corr_noInf_dim3(data[symb],data["q"])
        corr_ys[symb] = avg_corr_noInf_dim3(data[symb],data["y"])
        corr_ls[symb] = avg_corr_noInf_dim3(data[symb],data["l"])
        corr_indegs[symb] = avg_corr_noInf_dim3(data[symb],data["indeg"])
        corr_outdegs[symb] = avg_corr_noInf_dim3(data[symb],data["outdeg"])
        corr_centrals[symb] = avg_corr_noInf_dim3(data[symb],data["central"])
        corr_saless[symb] = avg_corr_noInf_dim3(data[symb],data["sales"])
    end

    to_print = ["moment" "q" "y" "l" "indeg" "outdeg" "central" "sales"]

    to_print_means,to_print_stds,to_print_skews,to_print_kurts,to_print_corr_qs,to_print_corr_ys,to_print_corr_ls,to_print_corr_indegs,to_print_corr_outdegs,to_print_corr_centrals,to_print_corr_saless = "mean","std","skew","kurt","corr_q","corr_y","corr_l","corr_indeg","corr_outdeg","corr_central","corr_sales"

    print_with_color(:blue, "\n\nFirm-level moments (logs) \n",bold=true)
    print_with_color(:red, "  $suffix network \n")

    for symb = ["q","y","l","indeg","outdeg","central","sales"]
        to_print_means = hcat(to_print_means,means[symb])
        to_print_stds = hcat(to_print_stds,stds[symb])
        to_print_skews = hcat(to_print_skews,skews[symb])
        to_print_kurts = hcat(to_print_kurts,kurts[symb])

        to_print_corr_qs = hcat(to_print_corr_qs,corr_qs[symb])
        to_print_corr_ys = hcat(to_print_corr_ys,corr_ys[symb])
        to_print_corr_ls = hcat(to_print_corr_ls,corr_ls[symb])
        to_print_corr_indegs = hcat(to_print_corr_indegs,corr_indegs[symb])
        to_print_corr_outdegs = hcat(to_print_corr_outdegs,corr_outdegs[symb])
        to_print_corr_saless = hcat(to_print_corr_saless,corr_saless[symb])

        println("  $symb")
        println("    mean = $(means[symb])")
        println("    std  = $(stds[symb])")
        println("    skew = $(skews[symb])")
        println("    kurt = $(kurts[symb])")
        println()
        println("    corr with q       = $(corr_qs[symb])")
        println("    corr with y       = $(corr_ys[symb])")
        println("    corr with l       = $(corr_ls[symb])")
        println("    corr with indeg   = $(corr_indegs[symb])")
        println("    corr with outdeg  = $(corr_outdegs[symb])")
        println("    corr with central = $(corr_centrals[symb])")
        println("    corr with sales   = $(corr_saless[symb])")
        println("")
    end

    to_print = vcat(to_print,to_print_means,to_print_stds,to_print_skews,to_print_kurts,to_print_corr_qs,to_print_corr_ys,to_print_corr_ls,to_print_corr_indegs,to_print_corr_outdegs,to_print_corr_saless)

    writedlm("$dir/firm_char_$suffix",to_print)
end
