
using Distributions
using LightGraphs
using GSL
using StatsBase


function zipfNetwork(n,seed)
    scaleFreeNetwork(n,seed,1)
end

# Create scare free networks
function scaleFreeNetwork(n,seed,shape=2,minimum=1,corr=false)
    # The degree distribution of link is P(k) \sim k^(-shape)

    # Put a limit on how many links a firm can have otherwise computation times explode
    if n <= 10000
        max_k = n-1
    else
        max_k = 999
    end

    if corr
        # Code for correlated random draws
        # Bivariate Pareto distribution of the first kind
        # https://en.wikipedia.org/wiki/Multivariate_Pareto_distribution

        # println("Using correlated random variables for indegree and outdegree")
        pdf = zeros(max_k,max_k)

        # Define the pdf
        for k1 = 1:max_k
            for k2 = 1:max_k
                if k1 < minimum || k2 < minimum
                    pdf[k1,k2] = 0.0
                else
                    pdf[k1,k2] = shape*(shape-1)*(minimum^2)^shape*(minimum*k1 + minimum*k2 - minimum^2)^(-shape-1)
                end
            end
        end

        # Normalize PDF
        pdf = pdf./sum(pdf)

        Pk = Distributions.Categorical(pdf[:])
        return buildNetworkFromDist(Pk,n,seed,minimum,0,true)
    else
        # Code for uncorrelated random draws
        # See: https://en.wikipedia.org/wiki/Zipf%27s_law
        # println("Using uncorrelated random variables for indegree and outdegree")

        # pdf = (float(1:max_k)).^(-shape)./GSL.sf_zeta(shape)
        # pdf = pdf./(sum(pdf))

        pdf = zeros(max_k)

        for k=1:max_k
            pdf[k] = float(k)^(-shape)/generalized_harmonic_number(max_k,k)
        end
        pdf = pdf./(sum(pdf))

        Pk = Distributions.Categorical(pdf)
        return buildNetworkFromDist(Pk,n,seed,minimum,0,false)
    end
end

function buildNetworkFromDist(Pk,n,seed,minimum=1,add_firms=0,corr=false)

    srand(seed)

    at_least_one_input = true # Only keep network if each firm has access to at least one input
    allow_self_link = false # Can a node be connected with itself

    # at_least_one_input ? println("Firms required to have one input in Ω") : println("Firms not required to have one input in Ω")
    # allow_self_link ? println("Self link allowed in Ω") : println("Self link not allowed in Ω")

    Ω = spzeros(Bool,n,n)

    # We might need to iterate to find a suitable Ω if one firm has no input
    iter_suit = 0
    iter_suit_max = 5000

    suitable_matrix = false

    while ~suitable_matrix && iter_suit<iter_suit_max
        # println("Constructing Ω: Iteration = $iter_suit")
        iter_suit = iter_suit + 1

        Ω = spzeros(Bool,n,n)

        z_in,z_out = zeros(Int64,n),ones(Int64,n)

        while sum(z_in) != sum(z_out)
            if corr == false
                z_out = rand(Pk,n) + add_firms
                z_in  = rand(Pk,n) + add_firms
            else
                z_in,z_out = ind2sub((Int64(sqrt(Pk.K)),Int64(sqrt(Pk.K))),rand(Pk,n))
            end

            z_out = max.(z_out,minimum)
            z_in = max.(z_in,minimum)
        end


        # Create lists of stubs
        list_of_stubs_out = zeros(Int64,sum(z_out))
        list_of_stubs_in = zeros(Int64,sum(z_in))

        counter_out = 0
        counter_in = 0

        for i = 1:n
            for j = 1:z_out[i]
                counter_out += 1
                list_of_stubs_out[counter_out] = i
            end

            for j = 1:z_in[i]
                counter_in += 1
                list_of_stubs_in[counter_in] = i
            end
        end

        # Shuffle the stubs
        list_of_stubs_in_shuffled = shuffle(list_of_stubs_in)
        list_of_stubs_out_shuffled = shuffle(list_of_stubs_out)

        for i = 1:length(list_of_stubs_in_shuffled)
            Ω[list_of_stubs_out_shuffled[i],list_of_stubs_in_shuffled[i]] = 1
        end

        if !allow_self_link
            Ω[diagind(Ω)] = 0
        end

        if any(sum(Ω,1).==0) && at_least_one_input
            suitable_matrix = false
            # println("Some firms have no inputs. Draw new Ω")
        else
            suitable_matrix = true
        end
    end

    if iter_suit>=iter_suit_max
        println("Unable to generate scale-free matrix. Increase n")
        error("Unable to generate scale-free matrix. Increase n")
    end

    return Ω
end



# The following functions are used when running tests

using StatsBase

function randomNetwork(n,seed,threshold)
    srand(seed)
    Ω = round.(Int64,rand(n,n).<threshold)
    return Ω
end

randomNetwork1(n,seed) = randomNetwork(n,seed,1/n*1)
randomNetwork2(n,seed) = randomNetwork(n,seed,1/n*2)
randomNetwork3(n,seed) = randomNetwork(n,seed,1/n*3)
randomNetwork4(n,seed) = randomNetwork(n,seed,1/n*4)
randomNetwork5(n,seed) = randomNetwork(n,seed,1/n*5)
randomNetwork6(n,seed) = randomNetwork(n,seed,1/n*6)
randomNetwork7(n,seed) = randomNetwork(n,seed,1/n*7)
randomNetwork8(n,seed) = randomNetwork(n,seed,1/n*8)
randomNetwork9(n,seed) = randomNetwork(n,seed,1/n*9)
randomNetwork10(n,seed) = randomNetwork(n,seed,1/n*10)
randomNetwork11(n,seed) = randomNetwork(n,seed,1/n*11)
randomNetwork12(n,seed) = randomNetwork(n,seed,1/n*12)
randomNetwork13(n,seed) = randomNetwork(n,seed,1/n*13)
randomNetwork14(n,seed) = randomNetwork(n,seed,1/n*14)


# With empty diagonal
function randomNetwork_nodiag(n,seed,threshold)
    # threshold = 1/(n-1)*a means that each node has an average of a links since the diagonal is empty
    srand(seed)
    Ω = round.(Int64,rand(n,n).<threshold)
    Ω[diagind(Ω)] = 0
    return Ω
end


# # # Use since n-1 since the diagnonal is removed
randomNetwork1_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*1)
randomNetwork2_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*2)
randomNetwork3_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*3)
randomNetwork4_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*4)
randomNetwork5_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*5)
randomNetwork6_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*6)
randomNetwork7_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*7)
randomNetwork8_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*8)
randomNetwork9_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*9)
randomNetwork10_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*10)
randomNetwork11_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*11)
randomNetwork12_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*12)
randomNetwork13_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*13)
randomNetwork14_nodiag(n,seed) = randomNetwork_nodiag(n,seed,1/(n-1)*14)
