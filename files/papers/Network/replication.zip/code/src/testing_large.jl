
function find_1dev(array_simul::Array{Simulation})
    nb_seeds = length(array_simul)

    nb_deviations = zeros(nb_seeds)
    fraction_error_theta = zeros(nb_seeds)
    change_in_C = zeros(nb_seeds)

    future_vec = Array{Future,1}((nb_seeds,))

    nb_deviations_future = Array{Future,1}((nb_seeds,))
    fraction_error_theta_future = Array{Future,1}((nb_seeds,))
    change_in_C_future = Array{Future,1}((nb_seeds,))


    for i_seed = 1:nb_seeds
        # println("Looking for deviations in seed $i_seed")
        future_vec[i_seed] = @spawn find_1dev(array_simul[i_seed])
    end

    for i_seed = 1:nb_seeds
        future_vec_fetched = collect(fetch(future_vec[i_seed]))
        nb_deviations[i_seed] = future_vec_fetched[1]
        fraction_error_theta[i_seed] = future_vec_fetched[2]
        change_in_C[i_seed] = future_vec_fetched[3]
    end

    return mean(nb_deviations),mean(fraction_error_theta),mean(change_in_C)
end


function find_1dev(simul::Simulation)
    param = simul.param
    n_simul = simul.n_simul
    n = simul.param.n

    Θ_stor = simul.Θ_stor
    q_stor = simul.q_stor
    z_stor = simul.z_stor

    σ = param.σ
    f = param.f

    nb_deviations = zeros(n_simul)
    change_in_C = zeros(n_simul)
    fraction_error_theta = zeros(n_simul)

    for i_simul = 1:n_simul
        # println("   Looking for deviations in simul $i_simul")

        # If problem delete the next lines and uncomment what follows
        Θ_best = simul.Θ_stor[i_simul,:]
        q_best = solveq(param,z_stor[i_simul,:],Θ_best,true)
        Q_best = (sum(q_best.^(σ-1)))^(1/(σ-1))
        C_best = (1-f*sum(Θ_best))*Q_best

        C_init = copy(C_best)
        Θ_init = copy(Θ_best)

        C_best,Θ_best = find_1dev(param,z_stor[i_simul,:],simul.Θ_stor[i_simul,:])

        nb_deviations[i_simul] = sum(abs.(Θ_init-Θ_best))
        fraction_error_theta[i_simul] = sum(abs.(Θ_init-Θ_best))./sum(Θ_init)
        change_in_C[i_simul] = abs(C_best-C_init)/C_init
    end

    return mean(nb_deviations),mean(fraction_error_theta),mean(change_in_C)
end

function find_1dev(param::Parameters,z,Θ,indexes_to_check=1:param.n)
    n = param.n
    σ = param.σ
    f = param.f

    Θ_best = copy(Θ)
    q_best = solveq(param,z,Θ_best,true)
    Q_best = (sum(q_best.^(σ-1)))^(1/(σ-1))
    C_best = (1-f*sum(Θ_best))*Q_best

    Θ_init = copy(Θ_best)
    C_init = copy(C_best)

    still_deviations = true

    while still_deviations
        still_deviations = false

        for i in indexes_to_check

            Θ_trial = copy(Θ_best)
            if Θ_trial[i] == true
                Θ_trial[i] = false
            else
                Θ_trial[i] = true
            end

            q_trial = solveq(param,z,Θ_trial,true)

            Q_trial = (sum(q_trial.^(σ-1)))^(1/(σ-1))

            C_trial = (1-f*sum(Θ_trial))*Q_trial

            if C_trial > C_best
                still_deviations = true
                # println("1 dev found")

                C_best = copy(C_trial)
                Θ_best = copy(Θ_trial)
                q_best = copy(q_trial)
            end
        end
    end
    return C_best,Θ_best

end
