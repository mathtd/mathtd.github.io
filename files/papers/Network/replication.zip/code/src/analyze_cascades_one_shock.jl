# This file contains function to analyze cascades from a model solved using mode_shocks = 1
# Each period, one firm is set to z=0

function build_cascades_data_one_shock(shocked_firm,Ω_networks,Θ_vec,indeg_firm,outdeg_firm,percent_drop_in_C,dir,suffix)
    # We only consider neighbors up to max_depth
    max_depth = 5

    nb_seed,nb_simul = size(indeg_firm)

    nb_data = nb_seed*(nb_simul-1)

    n = size(Ω_networks[1,:,:])[1]

    # Build empty vectors that will contain the data

    # Characteristics of the firm
    indegree = Array{Int64,1}(nb_data)
    outdegree = Array{Int64,1}(nb_data)

    # Keep track of the neighbors
    nb_neigbors_up = Matrix{Int64}(nb_data, max_depth)
    nb_neigbors_down = Matrix{Int64}(nb_data, max_depth)

    nb_neigbors_up_exits = Matrix{Int64}(nb_data, max_depth)
    nb_neigbors_down_exits = Matrix{Int64}(nb_data, max_depth)

    drop_in_C = Array{Float64,1}(nb_data)


    i_data = 0

    # Now go over all the firms, year by year and add them to tge data vectors
    # The last year does not teach us anything since all firms exit then
    for i_seed in 1:nb_seed

        shortest_down = zeros(n)
        shortest_up = zeros(n)

        direct_net = LightGraphs.DiGraph(build_active_network_matrix(Ω_networks[i_seed,:,:],Θ_vec[i_seed,1,:]))
        reverse_net = build_inverse_graph(direct_net)


        for i_simul = 2:nb_simul
            i_data += 1

            drop_in_C[i_data] = percent_drop_in_C[i_seed,i_simul]

            indegree[i_data] = indeg_firm[i_seed,i_simul]
            outdegree[i_data] = outdeg_firm[i_seed,i_simul]

            i = shocked_firm[i_seed,i_simul]

            shortest_down = LightGraphs.dijkstra_shortest_paths(direct_net,i)
            shortest_up = LightGraphs.dijkstra_shortest_paths(reverse_net,i)

            nb_neigbors_up_tmp = zeros(Int64,1,max_depth)
            nb_neigbors_down_tmp = zeros(Int64,1,max_depth)

            nb_neigbors_up_exits_tmp = zeros(Int64,1,max_depth)
            nb_neigbors_down_exits_tmp = zeros(Int64,1,max_depth)

            # Look at all other nodes ...
            for j = 1:n
                # ... that are different from the current one ...
                if i!=j
                    # ... and are within the max depth of exploration ...
                    if shortest_down.dists[j] <= max_depth
                        # ... and keep track of them ...
                        nb_neigbors_down_tmp[shortest_down.dists[j]] += 1
                        # ... and if they shut down afterwards keep track fo that too
                        if Θ_vec[i_seed,1,j] == true && Θ_vec[i_seed,i_simul,j] == false
                            nb_neigbors_down_exits_tmp[shortest_down.dists[j]] += 1
                        end
                    end

                    # same thing going upstream
                    if shortest_up.dists[j] <= max_depth
                        # ... and keep track of them ...
                        nb_neigbors_up_tmp[shortest_up.dists[j]] += 1
                        # ... and if they shut down afterwards keep track fo that too
                        if Θ_vec[i_seed,1,j] == true && Θ_vec[i_seed,i_simul,j] == false
                            nb_neigbors_up_exits_tmp[shortest_up.dists[j]] += 1
                        end
                    end
                end
            end

            # Add the neighbors vectors to the data
            nb_neigbors_up[i_data,:] = nb_neigbors_up_tmp
            nb_neigbors_down[i_data,:] = nb_neigbors_down_tmp

            nb_neigbors_up_exits[i_data,:] = nb_neigbors_up_exits_tmp
            nb_neigbors_down_exits[i_data,:] = nb_neigbors_down_exits_tmp

        end
    end

    # Percentiles for groups
    pct_thresh = 90
    thresh_indeg  = percentile(indegree,pct_thresh)
    thresh_outdeg  = percentile(outdegree,pct_thresh)
    thresh_deg  = percentile(indegree + outdegree,pct_thresh)

    println("The $pct_thresh % threshold for indegree is  $thresh_indeg")
    println("The $pct_thresh % threshold for outdegree is $thresh_outdeg")
    println("The $pct_thresh % threshold for degree is    $thresh_deg")

    vpct_thresh = 99
    vthresh_indeg  = percentile(indegree,vpct_thresh)
    vthresh_outdeg  = percentile(outdegree,vpct_thresh)
    vthresh_deg  = percentile(indegree + outdegree,vpct_thresh)

    println("The $vpct_thresh % threshold for indegree is  $vthresh_indeg")
    println("The $vpct_thresh % threshold for outdegree is $vthresh_outdeg")
    println("The $vpct_thresh % threshold for degree is    $vthresh_deg")

    # Impact on consumption by groups

    println("Impact on consumption")
    println("  all  cascades             = $(mean(drop_in_C))")
    println("  high in-degree cascades   = $(mean(drop_in_C[indegree.>thresh_indeg]))")
    println("  high out-degree cascades  = $(mean(drop_in_C[outdegree.>thresh_outdeg]))")
    println("  high degree cascades      = $(mean(drop_in_C[outdegree+indegree.>thresh_deg]))")
    println("  vhigh in-degree cascades  = $(mean(drop_in_C[indegree.>vthresh_indeg]))")
    println("  vhigh out-degree cascades = $(mean(drop_in_C[outdegree.>vthresh_outdeg]))")
    println("  vhigh degree cascades     = $(mean(drop_in_C[outdegree+indegree.>vthresh_deg]))")

    println()
    println("Downstream shutdowns")
    println("  all  cascades             = $(mean(nb_neigbors_down_exits,1))")
    println("  high in-degree cascades   = $(mean(nb_neigbors_down_exits[indegree.>thresh_indeg,:],1))")
    println("  high out-degree cascades  = $(mean(nb_neigbors_down_exits[outdegree.>thresh_outdeg,:],1))")
    println("  high degree cascades      = $(mean(nb_neigbors_down_exits[outdegree+indegree.>thresh_deg,:],1))")
    println("  vhigh in-degree cascades  = $(mean(nb_neigbors_down_exits[indegree.>vthresh_indeg,:],1))")
    println("  vhigh out-degree cascades = $(mean(nb_neigbors_down_exits[outdegree.>vthresh_outdeg,:],1))")
    println("  vhigh degree cascades     = $(mean(nb_neigbors_down_exits[outdegree+indegree.>vthresh_deg,:],1))")
    println()
    println("Upstream shutdowns")
    println("  all  cascades            = $(mean(nb_neigbors_up_exits,1))")
    println("  high in-degree cascades  = $(mean(nb_neigbors_up_exits[indegree.>thresh_indeg,:],1))")
    println("  high out-degree cascades = $(mean(nb_neigbors_up_exits[outdegree.>thresh_outdeg,:],1))")
    println("  high degree cascades     = $(mean(nb_neigbors_up_exits[outdegree+indegree.>thresh_deg,:],1))")
    println("  vhigh in-degree cascades  = $(mean(nb_neigbors_up_exits[indegree.>vthresh_indeg,:],1))")
    println("  vhigh out-degree cascades = $(mean(nb_neigbors_up_exits[outdegree.>vthresh_outdeg,:],1))")
    println("  vhigh degree cascades     = $(mean(nb_neigbors_up_exits[outdegree+indegree.>vthresh_deg,:],1))")

    # Export the data to csv files
    # Build big data matrix for Stata (we might want to do everything in Julia at some point)

    writedlm("$dir/cascades_one_shock_data_consumption_$suffix.txt",(
        mean(drop_in_C),
        mean(drop_in_C[indegree.>thresh_indeg]),
        mean(drop_in_C[outdegree.>thresh_outdeg]),
        mean(drop_in_C[outdegree+indegree.>thresh_deg]),
        mean(drop_in_C[indegree.>vthresh_indeg]),
        mean(drop_in_C[outdegree.>vthresh_outdeg]),
        mean(drop_in_C[outdegree+indegree.>vthresh_deg]))
        )

    writedlm("$dir/cascades_one_shock_data_downstream_$suffix.txt",hcat(
        (1:max_depth),
        mean(nb_neigbors_down_exits,1)',
        mean(nb_neigbors_down_exits[indegree.>thresh_indeg,:],1)',
        mean(nb_neigbors_down_exits[outdegree.>thresh_outdeg,:],1)',
        mean(nb_neigbors_down_exits[outdegree+indegree.>thresh_deg,:],1)',
        mean(nb_neigbors_down_exits[indegree.>vthresh_indeg,:],1)',
        mean(nb_neigbors_down_exits[outdegree.>vthresh_outdeg,:],1)',
        mean(nb_neigbors_down_exits[outdegree+indegree.>vthresh_deg,:],1)'
        ))

    writedlm("$dir/cascades_one_shock_data_uptream_$suffix.txt",hcat(
        (1:max_depth),
        mean(nb_neigbors_up_exits,1)',
        mean(nb_neigbors_up_exits[indegree.>thresh_indeg,:],1)',
        mean(nb_neigbors_up_exits[outdegree.>thresh_outdeg,:],1)',
        mean(nb_neigbors_up_exits[outdegree+indegree.>thresh_deg,:],1)',
        mean(nb_neigbors_up_exits[indegree.>vthresh_indeg,:],1)',
        mean(nb_neigbors_up_exits[outdegree.>vthresh_outdeg,:],1)',
        mean(nb_neigbors_up_exits[outdegree+indegree.>vthresh_deg,:],1)'
        ))
end


function analyze_cascades_one_shock(simul_array,C,indeg,outdeg,dir,suffix)
    n = simul_array[1].param.n
    number_seeds = length(simul_array)
    n_simul_per_seed = simul_array[1].n_simul

    Ω_networks = Array{Bool}(number_seeds,n,n)
    Θ_vec = Array{Bool}(number_seeds,n_simul_per_seed,n)

    percent_drop_in_C = Array{Float64}(number_seeds,n_simul_per_seed)
    shocked_firm = Array{Int64}(number_seeds,n_simul_per_seed)
    indeg_firm = Array{Float64}(number_seeds,n_simul_per_seed)
    outdeg_firm = Array{Float64}(number_seeds,n_simul_per_seed)

    number_seeds_to_use = number_seeds

    # Build a network for each year
    for i_seed = 1:number_seeds_to_use
        Ω = copy(simul_array[i_seed].param.Ω)
        Ω_networks[i_seed,:,:] = Ω

        z_before = copy(simul_array[i_seed].z_stor[1,:])
        Θ_before = copy(simul_array[i_seed].Θ_stor[1,:])
        C_before = C[i_seed,1]

        for i_simul = 1:n_simul_per_seed
            Θ_vec[i_seed,i_simul,:] = copy(simul_array[i_seed].Θ_stor[i_simul,:])

            # Find the shocks firm
            z_after = copy(simul_array[i_seed].z_stor[i_simul,:])

            shocked_firm[i_seed,i_simul] = findmax(abs.(z_after-z_before))[2]
            indeg_firm[i_seed,i_simul] = indeg[i_seed,1,shocked_firm[i_seed,i_simul]]
            outdeg_firm[i_seed,i_simul] = outdeg[i_seed,1,shocked_firm[i_seed,i_simul]]
            C_after = C[i_seed,i_simul]

            percent_drop_in_C[i_seed,i_simul] = log(C_after) - log(C_before)
        end
    end


    build_cascades_data_one_shock(shocked_firm,Ω_networks,Θ_vec,indeg_firm,outdeg_firm,percent_drop_in_C,dir,suffix)

    percent_drop_in_C,indeg_firm,outdeg_firm,shocked_firm
end
