# This files contains simple functions to compute various moments on a graph


function corr(x,y)
    return cov(x,y)/(sqrt(var(x))*sqrt(var(y)))
end

function corr_active(x_in,y_in)
    x=x_in[(x_in.>0) & (y_in.>0)]
    y=y_in[(x_in.>0) & (y_in.>0)]

    return cov(x,y)/(sqrt(var(x))*sqrt(var(y)))
end

function generalized_harmonic_number(n,m)
    output = 0.0
    for k=1:n
        output = output + 1/(k^m)
    end
    return output
end

# This function computes stats on the last dimensions of x, ignoring NaN, and then averaging over the first two dimenions
function mean_std_skew_kurt_noInf_dim3(x)
    n1,n2,n3 = size(x)

    mean_out = zeros(n1,n2)
    std_out = zeros(n1,n2)
    skew_out = zeros(n1,n2)
    kurt_out = zeros(n1,n2)

    for i1 = 1:n1
        for i2 = 1:n2
            x_no_inf = x[i1,i2,:][.!Base.isinf.(x[i1,i2,:])]

            mean_out[i1,i2] = StatsBase.mean(x_no_inf)
            std_out[i1,i2]  = StatsBase.std(x_no_inf)
            skew_out[i1,i2] = StatsBase.skewness(x_no_inf)
            kurt_out[i1,i2] = StatsBase.kurtosis(x_no_inf)
        end
    end

    return mean(mean_out)[1],mean(std_out)[1],mean(skew_out)[1],mean(kurt_out)[1]
end


function avg_corr_dim3(x,y)
    n1,n2,n3 = size(y)

    corr_out = zeros(n1,n2)

    for i1 = 1:n1
        for i2 = 1:n2
            corr_out[i1,i2] = corr(x[i1,i2,:],y[i1,i2,:])
        end
    end

    return mean(corr_out)[1]
end

function avg_corr_row(x,y)
    n_simul,n = size(y)

    corr_out = zeros(n_simul,1)

    for j = 1:n_simul
        corr_out[j] = corr(x[j,:],y[j,:])
    end

    return mean(corr_out,1)[1]
end

function avg_corr_noInf_dim3(x,y)
    n1,n2,n3 = size(y)
    corr_out = zeros(n1,n2)

    for i1 = 1:n1
        for i2 = 1:n2
            x_no_inf = x[i1,i2,:][.!Base.isinf.(x[i1,i2,:]) .& .!Base.isinf.(y[i1,i2,:])]
            y_no_inf = y[i1,i2,:][.!Base.isinf.(x[i1,i2,:]) .& .!Base.isinf.(y[i1,i2,:])]

            corr_out[i1,i2] = corr(x_no_inf,y_no_inf)
        end
    end

    return mean(corr_out)[1]

end


# This function returns the log-log data for rank plotting
function log_log_ranking(x,include_zero=false)

    bin = Float64[]
    mass_to_the_right = Float64[]

    x_sorted = sort(x[:])
    n = length(x[:])

    for i = 1:n-1
        if x_sorted[i] != x_sorted[i+1]
            push!(bin,x_sorted[i])
            push!(mass_to_the_right,1-i/n)
        end
    end

    if include_zero
        push!(bin,bin[end]+1)
        push!(mass_to_the_right,0)
    end


    return bin,mass_to_the_right
end


function pareto_alpha_estimate_only_pos(x,remove_below = 0.0)
    # uses Rank-1/2: A Simple Way to Improve the OLS Estimation of Tail Exponents Xavier Gabaix, Rustam Ibragimov
    # This approach works well for the discrete power law of indeg and outdeg
    # I have tested it in test_pareto_est.jl

    if (maximum(x)<remove_below) || (length(x[x.>=remove_below]) < 2)
      println(" ... no data above threshold")
      return 0.0
    else
      sorted = sort(x[x .>= remove_below],rev=true)
      rank = 1:length(sorted)

      data = DataFrame(rank = log.(rank-1/2), sorted=log.(sorted))
      try
          OLS = GLM.lm(@formula(rank ~ sorted), data)
          return -coef(OLS)[2] # The first coefficient is the intercept
      catch
          println(" ... colinearity in regression")
          return NaN
      end
    end
end

function skewness_col(v::Array{Float64})
    n_1,n_2 = size(v)[1],size(v)[2]
    skewnesses = zeros(n_1)
    for i=1:n_1
        skewnesses[i] = StatsBase.skewness(v[i,:])
    end
    return skewnesses
end

function kurtosis_col(v::Array{Float64})
    n_1,n_2 = size(v)[1],size(v)[2]
    kurtosises = zeros(n_1)
    for i=1:n_1
        kurtosises[i] = StatsBase.kurtosis(v[i,:])
    end
    return kurtosises
end
