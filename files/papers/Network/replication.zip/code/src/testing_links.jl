# Compare to solution.jl algorithms

# Construct economy for simulation
function build_econ_link(m,seed,f_firm_in,f_link_lb,f_link_ub,α_firm_in,α_link_lb,α_link_ub,ϵ_in,σ_in,std_firm_in,std_link_in,p_link)
    n = []
    Ω = []

    # Dummy to keep track of draw
    good_draw_Ω = false

    # Emprty matrix for links
    link_exist = zeros(m*(m-1))

    allow_self_link = false # Can a node be connected with itself
    at_least_one_input = true # Only keep network if each firm has access to at least one input


    nb_attempt = 0

    while ~good_draw_Ω && nb_attempt<100
        nb_attempt += 1

        good_draw_Ω = true
        # Figure out which links exist out of a potential of m(m-1) (we force no self-link)
        link_exist = rand(m*(m-1)) .<= p_link

        # Total number of links
        n = m + sum(link_exist)

        # Defined directed graph
        G = DiGraph(n)

        # Create all the links
        counter = m+1
        for i=1:m
            for j=1:m
                if i !== j
                    if link_exist[counter-m]
                        add_edge!(G, i, counter)
                        add_edge!(G, counter, j)
                    end
                    counter += 1
                end
            end
        end

        Ω = adjacency_matrix(G)

        if !allow_self_link
            Ω[diagind(Ω)] = 0
        end

        # Make sure that all firms have at least one link
        if any(sum(Ω[m:end,1:m],1).==0) && at_least_one_input
            good_draw_Ω = false
        end
    end

    if nb_attempt == 100
        error("Unable to find a network")
    end

    # Build the parameters of the economy

    # We have m*(m-1) links plus m nodes
    # Firms 1 to m are real firms, the other ones are links

    f,ϵ,α,β,z = zeros(n),zeros(n),zeros(n),zeros(n),zeros(n)

    σ = σ_in

    z_firm = exp.(rand(Normal(0.0, std_firm_in),n))
    z_link = exp.(rand(Normal(0.0, std_link_in),n))
    f_link = rand(n) * (f_link_ub - f_link_lb) + f_link_lb
    α_link = rand(n) * (α_link_ub - α_link_lb) + α_link_lb

    for i = 1:n
        if i<=m
            # We have a real firm
            z[i] = z_firm[i]
            f[i] = f_firm_in
            ϵ[i] = ϵ_in
            α[i] = α_firm_in
            β[i] = 1.0
        else
            # We have a link
            z[i] = z_link[i]#*0 + 1.0
            f[i] = f_link[i]
            ϵ[i] = ϵ_in
            α[i] = α_link[i]
            β[i] = 0.0
        end
    end


    param = Parameters_hetero(n,f/n,std_firm_in,0,σ,ϵ,α,β,Ω)
    return param,z
end


# Compares the performance of two functions f1 and f2
function test(f1::Function,f2::Function,trials,m,seed,f_firm_in,f_link_lb,f_link_ub,α_firm_in,α_link_lb,α_link_ub,ϵ_in,σ_in,std_firm_in,std_link_in,p_link,mute,dev_mode)


    # Vectors to store results
    theta_identical_reshape = SharedArray{Bool}(trials)
    fraction_discr_theta_reshape = convert(SharedArray,ones(trials))
    C_diff_reshape = convert(SharedArray,ones(trials))
    error_solution_reshape = SharedArray{Bool}(trials)
    sum_theta_reshape = convert(SharedArray,zeros(trials))
    fraction_theta_non_convergence_01_reshape = convert(SharedArray,zeros(trials))

    theta_identical_noreshape = SharedArray{Bool}(trials)
    fraction_discr_theta_noreshape = convert(SharedArray,ones(trials))
    C_diff_noreshape = convert(SharedArray,ones(trials))
    error_solution_noreshape = SharedArray{Bool}(trials)
    sum_theta_noreshape = convert(SharedArray,zeros(trials))
    fraction_theta_non_convergence_01_noreshape = convert(SharedArray,zeros(trials))


    @sync @parallel for trial in 1:trials
    # for trial in 1:trials

        # Draw relevant variables for all firms
        srand(seed+trial)

        repeat_draw = true # Dummy to repeat the draw if pathological
        nb_draw = 0

        while repeat_draw
            nb_draw = nb_draw + 1
            repeat_draw = false


            param,z = build_econ_link(m,seed,f_firm_in,f_link_lb,f_link_ub,α_firm_in,α_link_lb,α_link_ub,ϵ_in,σ_in,std_firm_in,std_link_in,p_link)


            β = param.β
            σ = param.σ
            ϵ = param.ϵ
            n = param.n
            f = param.f*n
            α = param.α

            L = 1


            if dev_mode == false
                # Solve the model using the exhaustive search
                Θ1 = f1(param,z,true,m+1)
                Θ1[f .== 0] = 1
                q1 = solveq(param,z,Θ1,mute)
                Q1 = (sum(β.*q1.^(σ-1)))^(1/(σ-1))
                C1 = (L-sum(f/n.*Θ1))*Q1
            end
            # Solve the model using reshaping algorithm
            Θ2_reshape,flag_error_reshape,nb_non_converged_theta_reshape = f2(param,z,true,true,ones(n)./(σ-1),1-(ϵ-1)/(σ-1))
            Θ2_reshape[f .== 0] = 1
            q2_reshape = solveq(param,z,Θ2_reshape,mute)
            Q2_reshape = (sum(β.*q2_reshape.^(σ-1)))^(1/(σ-1))
            C2_reshape = (L-sum(f/n.*Θ2_reshape))*Q2_reshape

            if dev_mode
                # We look for 1-nb_deviations
                Θ1 = find_1dev_links(param,z,n::Int64,m,Θ2_reshape)
                Θ1[f .== 0] = 1
                q1 = solveq(param,z,Θ1,mute)
                Q1 = (sum(β.*q1.^(σ-1)))^(1/(σ-1))
                C1 = (L-sum(f/n.*Θ1))*Q1
            end

            # Print the fraction of active links
            # println(sum(Θ1[m+1:n])/(n-m))

            C_diff_reshape[trial] = abs((C2_reshape-C1)/C1)

            if C2_reshape == 0.0
                # Pathological case with division by 0, exclude
                repeat_draw = true
            end

            fraction_discr_theta_reshape[trial] = sum(abs.(Θ1-Θ2_reshape))/n
            fraction_theta_non_convergence_01_reshape[trial] = nb_non_converged_theta_reshape/n


            if Θ1 == Θ2_reshape
                theta_identical_reshape[trial] = true
            end

            error_solution_reshape[trial] = false

            if flag_error_reshape
                # The FOC did not converge to {0,1}
                if ~mute; println("Error in trial reshape $trial"); end
                error_solution_reshape[trial] = true
            end

            if !flag_error_reshape && C2_reshape>C1
                error("higher consumption in foc_iterations reshape")
            end

            # Deal with simulation under no reshaping now

            Θ2_noreshape,flag_error_noreshape,nb_non_converged_theta_noreshape = f2(param,z,true,false,ones(n),zeros(n))
            Θ2_noreshape[f .== 0] = 1
            q2_noreshape = solveq(param,z,Θ2_noreshape,mute)
            Q2_noreshape = (sum(β.*q2_noreshape.^(σ-1)))^(1/(σ-1))
            C2_noreshape = (L-sum(f/n.*Θ2_noreshape))*Q2_noreshape

            if dev_mode
                # We look for 1-nb_deviations
                Θ1 = find_1dev_links(param,z,n::Int64,m,Θ2_noreshape)
                Θ1[f .== 0] = 1
                q1 = solveq(param,z,Θ1,mute)
                Q1 = (sum(β.*q1.^(σ-1)))^(1/(σ-1))
                C1 = (L-sum(f/n.*Θ1))*Q1
            end

            C_diff_noreshape[trial] = abs((C2_noreshape-C1)/C1)

            if C2_noreshape == 0.0
                # Pathological case with division by 0, exclude
                repeat_draw = true
            end

            fraction_discr_theta_noreshape[trial] = sum(abs.(Θ1-Θ2_noreshape))/n
            fraction_theta_non_convergence_01_noreshape[trial] = nb_non_converged_theta_noreshape/n

            if Θ1 == Θ2_noreshape
                theta_identical_noreshape[trial] = true
            end

            error_solution_noreshape[trial] = false

            if flag_error_noreshape
                if ~mute; println("Error in trial noreshape $trial"); end
                error_solution_noreshape[trial] = true
            end

            if !flag_error_noreshape && C2_noreshape>C1
                error("higher consumption in foc_iterations noreshape")
            end
        end
    end




    return theta_identical_reshape,fraction_discr_theta_reshape,C_diff_reshape,error_solution_reshape,theta_identical_noreshape,fraction_discr_theta_noreshape,C_diff_noreshape,error_solution_noreshape,fraction_theta_non_convergence_01_reshape,fraction_theta_non_convergence_01_noreshape

end



function series_of_test(m,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,dev_mode)

    combinations = product((1:length(f_firm_vec)),(1:length(α_firm_vec)),(1:length(ϵ_vec)),(1:length(σ_vec)),(1:length(std_firm_vec)),(1:length(std_link_vec)),(1:length(p_link_vec)))
    comb_no_iter = collect(combinations)

    nb_trials = length(f_firm_vec)*length(α_firm_vec)*length(ϵ_vec)*length(σ_vec)*length(std_firm_vec)*length(std_link_vec)*length(p_link_vec)


    # Build containers for parallel computations
    nb_error_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_sh_reshape_with_error = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    sum_theta_no_err_sh_reshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_theta_non_convergence_01_sh_reshape = convert(SharedArray,zeros(nb_trials,1))

    nb_error_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    success_theta_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    C_err_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_sh_noreshape_with_error = convert(SharedArray,zeros(nb_trials,1))
    fraction_discr_theta_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    sum_theta_no_err_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))
    fraction_theta_non_convergence_01_sh_noreshape = convert(SharedArray,zeros(nb_trials,1))

    mute = true
    seed = 1

    # @sync @parallel for i = 1:nb_trials
    for i = 1:nb_trials
        f_firm = f_firm_vec[comb_no_iter[i][1]]
        α_firm = α_firm_vec[comb_no_iter[i][2]]
        ϵ = ϵ_vec[comb_no_iter[i][3]]
        σ = σ_vec[comb_no_iter[i][4]]
        std_firm = std_firm_vec[comb_no_iter[i][5]]
        std_link = std_link_vec[comb_no_iter[i][6]]
        p_link = p_link_vec[comb_no_iter[i][7]]

        # Shift the seed so that each trial gets different productivity draws
        theta_identical_reshape,fraction_discr_theta_reshape,C_diff_reshape,error_solution_reshape,theta_identical_noreshape,fraction_discr_theta_noreshape,C_diff_noreshape,error_solution_noreshape,fraction_theta_non_convergence_01_reshape,fraction_theta_non_convergence_01_noreshape = test(solveExhaustive,foc_iterations,nb_sim_per_trials,m,seed+m*nb_trials*i,f_firm,f_link_lb,f_link_ub,α_firm,α_link_lb,α_link_ub,ϵ,σ,std_firm,std_link,p_link,mute,dev_mode)


        # the no_err variables refer to cases with FOC convergence
        nb_error_sh_reshape[i] = sum(error_solution_reshape)/nb_sim_per_trials*100
        success_theta_sh_reshape[i] = (sum(theta_identical_reshape)/nb_sim_per_trials*100)
        success_theta_no_err_sh_reshape[i] = sum(theta_identical_reshape .& .~error_solution_reshape)/sum(.~error_solution_reshape)*100
        C_err_sh_reshape[i] = sum(C_diff_reshape)/nb_sim_per_trials*100
        C_err_no_err_sh_reshape[i] = sum(C_diff_reshape.*(.~error_solution_reshape))/sum(.~error_solution_reshape)*100
        fraction_discr_theta_sh_reshape_with_error[i] = sum(fraction_discr_theta_reshape)/nb_sim_per_trials*100
        fraction_discr_theta_no_err_sh_reshape[i] = sum(fraction_discr_theta_reshape[.~error_solution_reshape])/sum(.~error_solution_reshape)*100



        # Without reshaping
        nb_error_sh_noreshape[i] = sum(error_solution_noreshape)/nb_sim_per_trials*100
        success_theta_sh_noreshape[i] = (sum(theta_identical_noreshape)/nb_sim_per_trials*100)
        success_theta_no_err_sh_noreshape[i] = sum(theta_identical_noreshape .& .~error_solution_noreshape)/sum(.~error_solution_noreshape)*100
        C_err_sh_noreshape[i] = sum(C_diff_noreshape)/nb_sim_per_trials*100
        C_err_no_err_sh_noreshape[i] = sum(C_diff_noreshape.*(.~error_solution_noreshape))/sum(.~error_solution_noreshape)*100
        fraction_discr_theta_sh_noreshape_with_error[i] = sum(fraction_discr_theta_noreshape)/nb_sim_per_trials*100
        fraction_discr_theta_no_err_sh_noreshape[i] = sum(fraction_discr_theta_noreshape[.~error_solution_noreshape])/sum(.~error_solution_noreshape)*100


    end

    println(success_theta_no_err_sh_reshape)

    println("")
    println("---------------------------------------------------")
    println("Parameters")
    println("---------------------------------------------------")
    println("    n           = $n")
    println("    nb_sim      = $nb_sim_per_trials")
    println("")
    println("WITH RESHAPING")
    println("   nb_sim_per_trials = $nb_sim_per_trials")
    println("   % FOC converge on {0,1} $(100-sum(nb_error_sh_reshape)/nb_trials)%")
    println("   % Success over full Θ (all cases) $(sum(success_theta_sh_reshape)/nb_trials)%")
    println("   % Success over full Θ (when FOC converge on {0,1}) $(sum(success_theta_no_err_sh_reshape)/nb_trials)%")
    println("   % Average error in C (all cases) $(sum(C_err_sh_reshape)/nb_trials)%")
    println("   % Average error in C (when FOC converge on {0,1}) $(sum(C_err_no_err_sh_reshape)/nb_trials)%")
    println("   % Success over individual θ (all cases) $(100-sum(fraction_discr_theta_sh_reshape_with_error)/nb_trials)%")
    println("   % Success over individual θ (when FOC converge on {0,1}) $(100-sum(fraction_discr_theta_no_err_sh_reshape)/nb_trials)%")
    println("")
    println("WITHOUT RESHAPING")
    println("   nb_sim_per_trials = $nb_sim_per_trials")
    println("   % FOC converge on {0,1} $(100-sum(nb_error_sh_noreshape)/nb_trials)%")
    println("   % Success over full Θ (all cases) $(sum(success_theta_sh_noreshape)/nb_trials)%")
    println("   % Success over full Θ (when FOC converge on {0,1}) $(sum(success_theta_no_err_sh_noreshape)/nb_trials)%")
    println("   % Average error in C (all cases) $(sum(C_err_sh_noreshape)/nb_trials)%")
    println("   % Average error in C (when FOC converge on {0,1}) $(sum(C_err_no_err_sh_noreshape)/nb_trials)%")
    println("   % Success over individual θ (all cases) $(100-sum(fraction_discr_theta_sh_noreshape_with_error)/nb_trials)%")
    println("   % Success over individual θ (when FOC converge on {0,1}) $(100-sum(fraction_discr_theta_no_err_sh_noreshape)/nb_trials)%")
    println("")
end



function find_1dev_links(param::Parameters_hetero,z,n::Int64,m::Int64,Θ)

    σ = param.σ
    f = param.f

    β = param.β

    L = 1.0

    Θ_best = Θ
    q_best = solveq(param,z,Θ_best,true)
    Q_best = (sum(β.*q_best.^(σ-1)))^(1/(σ-1))
    C_best = (L-sum(f.*Θ_best))*Q_best

    Θ_init = copy(Θ_best)
    C_init = copy(C_best)

    still_deviations = true

    while still_deviations
        still_deviations = false

        for i in m+1:n
        # for i in 1:n
            Θ_trial = copy(Θ_best)
            if Θ_trial[i] == true
                Θ_trial[i] = false
            else
                Θ_trial[i] = true
            end

            q_trial = solveq(param,z,Θ_trial,true)
            Q_trial = (sum(β.*q_trial.^(σ-1)))^(1/(σ-1))
            C_trial = (L-sum(f.*Θ_trial))*Q_trial

            if C_trial > C_best
                still_deviations = true
                # println("1 dev found")

                C_best = copy(C_trial)
                Θ_best = copy(Θ_trial)
                q_best = copy(q_trial)
            end
        end
    end

    return Θ_best
end
