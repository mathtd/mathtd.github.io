# Takes the data in dir and compute the cascades
# The cascades are computed as compared ro firms that do not exit

# Build a dictionary of each year-network
function dict_of_networks(N_nodes,N_links,start_year,end_year,year_link,supp_link,cust_link,undirected)
    # Put a fake network in otherwise things don't work
    networks = Dict{Int64,LightGraphs.DiGraph}(-1 => LightGraphs.DiGraph(N_nodes))

    # Build a network for each year
    for current_year = start_year:end_year

        # Initialize an N_nodes-network
        g = LightGraphs.DiGraph(N_nodes)

        # Go through all the links ...
        for link = 1:N_links
            # ... if the link is in the current year
            if year_link[link] == current_year
                # ... add the link to the network
                LightGraphs.add_edge!(g,supp_link[link],cust_link[link])
                if undirected
                    LightGraphs.add_edge!(g,cust_link[link],supp_link[link])
                end
            end
        end
        # ... and store the network in the dictionary
        networks[current_year] = g
    end

    # Clear the fake network
    delete!(networks,-1)
    networks
end

function build_networks(dir)

    A,B = readdlm("$(homedir())/Dropbox/Research/Network_and_exit/replication_files/data/Datasets/$dir/network.csv",',',Int64,'\n',header=true)

    year_link = A[:,1]
    supp_link = A[:,2]
    cust_link = A[:,3]

    N_links = length(year_link)

    # First and last year of the whole sample
    start_year = minimum(year_link)
    end_year = maximum(year_link)
    years = start_year:end_year

    nb_years = end_year - start_year + 1

    println("$dir")
    println("start_year = $start_year")
    println("end_year = $end_year")

    C,D = readdlm("$(homedir())/Dropbox/Research/Network_and_exit/replication_files/data/Datasets/$dir/myid_last_year.csv",',',Int64,'\n',header=true)

    # Last year for each firm
    last_year = C[:,1]

    # Number of nodes in the sample
    N_nodes = length(last_year)

    # We store all the networks in a dictionary
    networks = dict_of_networks(N_nodes,N_links,start_year,end_year,year_link,supp_link,cust_link,false)

    networks_reverse = dict_of_networks(N_nodes,N_links,start_year,end_year,year_link,cust_link,supp_link,false)

    networks_undirected = dict_of_networks(N_nodes,N_links,start_year,end_year,year_link,supp_link,cust_link,true)

    return networks,networks_reverse,networks_undirected,N_nodes,last_year,start_year,end_year
end


# This function computes the clustering coefficient, the indegree and outdegree power law shape as well as their correlation
# with output
function compute_moments_networks(dir)
    # Gather network data
    networks,networks_reverse,networks_undirected,N_nodes,last_year,start_year,end_year = build_networks(dir)
    nb_years = end_year - start_year + 1
    years = start_year:end_year

    # Gather gdp data
    A,B = readdlm("$(homedir())/Dropbox/Research/Network_and_exit/replication_files/data/Datasets/BEA/gdp.csv",',',Float64,'\n',header=true)

    year_gdp_data = A[:,1]
    log_gdp_data  = A[:,2]


    # keep relevant years for GDP
    log_gdp = log_gdp_data[(year_gdp_data .>= start_year) .& (year_gdp_data .<= end_year)]


    indeg_alpha       = zeros(nb_years)
    outdeg_alpha      = zeros(nb_years)
    clustering        = zeros(nb_years)
    corr_indeg_outdeg = zeros(nb_years)
    nb_active_firms   = zeros(nb_years)

    threshold_degree = 1

    println("Power law parameter above $threshold_degree neighbors")

    i_year = 0
    for current_year = start_year:end_year
        i_year += 1
        g = networks[current_year]

        indeg = indegree(g)
        outdeg = outdegree(g)
        deg = degree(g)

        indeg_alpha[i_year]     = pareto_alpha_estimate_only_pos(indegree(g),threshold_degree)
        outdeg_alpha[i_year]    = pareto_alpha_estimate_only_pos(outdegree(g),threshold_degree)

        clustering[i_year]      = custom_clustering_coefficient(g,false)
        nb_active_firms[i_year] = count_active_firms(g)

        corr_indeg_outdeg[i_year] = corr(indeg[deg.>0],outdeg[deg.>0])



        println("Year = $current_year")
        println("  log_gdp = $(log_gdp[i_year])")
        println("  Indeg = $(indeg_alpha[i_year])")
        println("  Outdeg = $(outdeg_alpha[i_year])")
        println("  Clustering = $(clustering[i_year])")
        println("  Clustering (normalized) = $(clustering[i_year].*sqrt(nb_active_firms[i_year]))")
        println("  Corr indeg outdeg = $(corr_indeg_outdeg[i_year])")
    end


    indeg_alpha[indeg_alpha .<0 ] = NaN
    outdeg_alpha[outdeg_alpha .<0 ] = NaN
    clustering[clustering .<0 ] = NaN
    nb_active_firms[nb_active_firms .<0 ] = NaN


    data = DataFrame(years = years, log_gdp = log_gdp,log_indeg_alpha = log.(indeg_alpha), log_outdeg_alpha = log.(outdeg_alpha), log_clustering = log.(clustering))

    # Linearly detrend everything
    if dir == "Factset_Revere" || dir == "Factset_Revere_diff_zipcode" || dir == "Factset_Revere_without_mergers"

        # CBO 10 year projection at beggining of 2003
        # https://www.cbo.gov/sites/default/files/recurringdata/51137-2003-08-potentialgdp.xls
        # =+(('Annual Data'!B83/'Annual Data'!B73)^(1/11)-1)*100
        log_gdp_detrended = log_gdp - 0.0258*years


        log_indeg_alpha_detrended = log.(indeg_alpha)
        log_outdeg_alpha_detrended = log.(outdeg_alpha)
        log_clustering_detrended = log.(clustering)
    else
        OLS_gdp = GLM.lm(Formula(:log_gdp, :years), data)
        log_gdp_detrended = log_gdp - predict(OLS_gdp)

        log_indeg_alpha_detrended = log.(indeg_alpha)
        log_outdeg_alpha_detrended = log.(outdeg_alpha)
        log_clustering_detrended = log.(clustering)
    end


    print_with_color(:blue, "\n\nMoments of the network (not logs)\n",bold=true)
    print_with_color(:red, "  $dir network \n")
    println("  Mean of indegree alpha          = $(mean(indeg_alpha[.!Base.isnan.(indeg_alpha)]))")
    println("  Mean of outdegree alpha         = $(mean(outdeg_alpha[.!Base.isnan.(outdeg_alpha)]))")
    println("  Mean of clustering (normalized) = $(mean(clustering[.!Base.isnan.(clustering) .& (clustering.!==0.0)].*sqrt.(nb_active_firms[.!Base.isnan.(clustering) .& (clustering.!==0.0)])))")
    println("  Mean of clustering (non-normalized) = $(mean(clustering[.!Base.isnan.(clustering) .& (clustering.!==0.0)]))")

    println("  Mean of corr indeg outdeg     = $(mean(corr_indeg_outdeg))")
    println("")
    println("  Std indegree                  = $(std(log_indeg_alpha_detrended))")
    println("  Std outdegree                 = $(std(log_outdeg_alpha_detrended))")
    println("  Std clustering                = $(std(log_clustering_detrended[.!Base.isinf.(log_clustering_detrended)]))")
    println("")

    print_with_color(:blue, "\n\nCorrelation network and business cycles (logs, linearly detrended) \n",bold=true)
    print_with_color(:red, "  $dir network \n")
    println("  Corr C and indegree              = $(corr(log_gdp_detrended[data[:log_indeg_alpha].!==missing],log_indeg_alpha_detrended))")
    println("  Corr C and outdegree             = $(corr(log_gdp_detrended[data[:log_outdeg_alpha].!==missing],log_outdeg_alpha_detrended))")
    println("  Corr C and clustering            = $(corr(log_gdp_detrended[.!Base.isinf.(log_clustering_detrended)],log_clustering_detrended[.!Base.isinf.(log_clustering_detrended)]))")
    println()
    println()


    if dir == "Factset_Revere" || dir == "Factset_Revere_diff_zipcode" || dir == "Factset_Revere_without_mergers"
        # Now print the indegree and outdegree distribution for a given year for the pictures
        year_dist = 2016
        x_in,y_in,x_out,y_out = degree_distributions(networks[year_dist])


        writedlm("$dir/indegree_$year_dist",[x_in y_in])
        writedlm("$dir/outdegree_$year_dist",[x_out y_out])

        # Now print all the in- and out-degrees of each firm in a given year
        year_dist = 2016
        writedlm("$dir/indegree_all_firms_$year_dist",indegree(networks[year_dist]))
        writedlm("$dir/outdegree_all_firms_$year_dist",outdegree(networks[year_dist]))
    end
end


function compute_cascades_data(dir)
    networks,networks_reverse,networks_undirected,N_nodes,last_year,start_year,end_year = build_networks(dir)

    valid_exit_year_dict = Dict{Int64,Bool}()

    years = start_year:end_year
    nb_years = end_year - start_year + 1

    # Construct the list of firm destruction
    firm_destruct = falses(nb_years,N_nodes)
    for i_year = 1:nb_years
        valid_exit_year_dict[years[i_year]] = (i_year == nb_years ? false : true)
        for i = 1:N_nodes
            if last_year[i] == years[i_year]
                firm_destruct[i_year,i] = true
            end
        end
    end


    firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits =    build_cascades_data(networks,networks_reverse,networks_undirected,valid_exit_year_dict,N_nodes,start_year,end_year,firm_destruct,dir,"data Factset")

    regression_cascades(firm_id,year,firm_exits,indegree,outdegree,centrality,nb_neigbors_up,nb_neigbors_down,nb_neigbors_all,nb_neigbors_up_exits,nb_neigbors_down_exits,nb_neigbors_all_exits,dir,"data Factset")

    compute_exit_probability(firm_id,year,firm_exits,indegree,outdegree,dir,"data Factset")
end
