# This file contains the functions to simulate the impact of shocks on the network

# Keeps track of the parameters used for a simulation
mutable struct Parameters
    n::Int64                        # Number of firms
    f::Float64                      # Cost of operation
    std_z::Float64                  # Standard deviation of z shocks
    ρ_z::Float64                    # Persistence of z shocks
    σ::Float64                      # Elasticity of substitution consumption
    ϵ::Float64                      # Elasticity of substitution production
    α::Float64                      # Labor intensity
    Ω::SparseMatrixCSC{Bool,Int64}  # Matrix of potential connections
end

# Store the results of a simulation
mutable struct Simulation
    param::Parameters                           # Keep track of the parameters for this simulation
    n_simul::Int64                              # Number of one-period economies

    Θ_stor::Array{Bool}                         # Θ across simulations
    q_stor::Array{Float64}                      # Efficienies across simulations
    z_stor::Array{Float64}                      # Exogenous productivity shocks
end

# Construct an array of simulations and solve the economy for each of them
function multi_seeds_simulations(param,network,number_seeds,n_simul_per_seed,initial_seed,exercise_type=0,forced_theta=zeros(Bool,number_seeds,n_simul_per_seed,param.n),reshaping=true,allow_error=false)
    # The argument forced_theta is a boolean vector that sets theta exogenously for some firms. It is use in the too-big-to-fail exercise.

    array_simulations = Array{Simulation}(number_seeds)
    array_parameters  = Array{Parameters}(number_seeds)

    # Store the computations done in parallel
    Ω_iter_Future = Array{Future,1}((number_seeds,))

    # Construct the networks on parallel processors
    print_with_color(:green, "\n\nConstructing networks Ω \n\n",bold=true)

    for i = 1:number_seeds
        Ω_iter_Future[i] = @spawn network(n,initial_seed + i - 1)
    end

    # fetch the networks and allocate them
    for i = 1:number_seeds
        param_iter = deepcopy(param)
        param_iter.Ω = fetch(Ω_iter_Future[i])
        array_parameters[i] = param_iter
    end

    # Solve each simulation independently in parallel
    simulation_iter_Future = Array{Future,1}((number_seeds,))

    print_with_color(:green, "\n\nSolving planner's problem ",bold=true)
    print_with_color(:red, "free ",bold=false)
    print_with_color(:green, "network\n\n",bold=true)

    for i = 1:number_seeds
        simulation_iter_Future[i] = @spawn solve_simulation(array_parameters[i],n_simul_per_seed,initial_seed + i,exercise_type,forced_theta[i,:,:],reshaping)
    end

    # fetch the simulations and allocate them
    for i = 1:number_seeds
        array_simulations[i] = fetch(simulation_iter_Future[i])
    end



    return array_simulations
end



# Takes the outcome of the flexible simulation and consider a random network instead
function multi_seeds_simulations_random(array_simul_free,initial_seed)

    print_with_color(:red, "random ",bold=false)
    print_with_color(:green, "network\n\n",bold=true)


    # Prepare a new array of simulation for the output
    array_simul_random = deepcopy(array_simul_free)
    number_seeds = length(array_simul_random)

    # Go over all the seeds
    for i_seed = 1:number_seeds
        n_simul = array_simul_random[i_seed].n_simul
        n = array_simul_random[i_seed].param.n

        # Compute the average number of active firm in the optimal network
        avg_n_active = mean(sum(array_simul_random[i_seed].Θ_stor,2),1)[1,1]
        println("avg_n_active = $avg_n_active")
        θ = find_allocation_random_network(array_simul_random[i_seed].param,array_simul_random[i_seed].param.Ω,avg_n_active,initial_seed+i_seed)

        # Create a network with the same number of active firms
        array_simul_random[i_seed].Θ_stor[:,:] = repmat(θ',n_simul,1)

        for t = 1:n_simul
            array_simul_random[i_seed].q_stor[t,:] = solveq(array_simul_random[i_seed].param,array_simul_random[i_seed].z_stor[t,:],array_simul_random[i_seed].Θ_stor[t,:],true)
        end
    end

    return array_simul_random
end


# Finds a random vector θ such that there are exactly n_active firms
function find_allocation_random_network(param,Ω,n_active_desired,seed)
    n = size(Ω)[1]

    θ = zeros(Bool,n)

    success_bisection = false
    iter_bissection = 0
    iter_bissection_max = 100

    # Keep doing this operation until it succeeds
    # The issue is that the number of active firms can jump between two close θ's
    while !success_bisection && (iter_bissection < iter_bissection_max)
        iter_bissection += 1
        n_active = 0

        srand(seed+iter_bissection)

        # Randomly shuffle the firms
        rank_all_the_firms = shuffle(1:n)

        # Define starting threshold such that all firms lower than the threshold in a reshuffling
        # are operating

        thresh_up = n       # All firms operate
        thresh_down = 0     # No firms operate

        iter = 0
        iter_max = n

        while abs(n_active - n_active_desired) >= 1 && iter < iter_max && abs(thresh_up-thresh_down) >= 1
            iter += 1

            thresh_med = (thresh_up + thresh_down)/2
            θ = zeros(Bool,n)
            θ[rank_all_the_firms .<= thresh_med] = 1

            # Compute the q assuming that the z=1 (does not matter since we only want to know active or not)
            q = solveq(param,ones(n),θ,true)
            n_active = sum(q.>0.0000001)

            if n_active>n_active_desired
                thresh_up = thresh_med
            elseif n_active<n_active_desired
                thresh_down = thresh_med
            end
        end

        if abs(n_active - n_active_desired) < 1
            success_bisection = true
            # println(" ... success bisection")
        end
    end

    if iter_bissection >= iter_bissection_max
        error("No convergence find_allocation_random_network")
    end

    return θ
end

# Takes the outcome of the flexible simulation and consider a fixed network instead (theta fixed)
function multi_seeds_simulations_fixed(array_simul_free,initial_seed)

    print_with_color(:red, "fixed ",bold=false)
    print_with_color(:green, "network\n\n",bold=true)

    # Prepare a new array of simulation for the output
    array_simul_fixed = deepcopy(array_simul_free)
    number_seeds = length(array_simul_fixed)

    # Go over all the seeds
    for i_seed = 1:number_seeds
        n_simul = array_simul_fixed[i_seed].n_simul
        n = array_simul_fixed[i_seed].param.n

        # Fix the network to the first simulation
        array_simul_fixed[i_seed].Θ_stor[:,:] = repmat((array_simul_free[i_seed].Θ_stor[1,:])',n_simul,1)

        for t = 1:n_simul
            array_simul_fixed[i_seed].q_stor[t,:] = solveq(array_simul_fixed[i_seed].param,array_simul_fixed[i_seed].z_stor[t,:],array_simul_fixed[i_seed].Θ_stor[t,:],true)
        end
    end

    return array_simul_fixed
end

# Takes the outcome of the flexible simulation and consider a fixed network instead (theta fixed)
# The shocked firm is still set to \theta=0
function multi_seeds_simulations_fixed_cascades_one_shock(array_simul_free,initial_seed,shocked_firm)

    print_with_color(:red, "fixed ",bold=false)
    print_with_color(:green, "network\n\n",bold=true)

    # Prepare a new array of simulation for the output
    array_simul_fixed = deepcopy(array_simul_free)
    number_seeds = length(array_simul_fixed)

    # Go over all the seeds
    for i_seed = 1:number_seeds
        n_simul = array_simul_fixed[i_seed].n_simul
        n = array_simul_fixed[i_seed].param.n

        # Fix the network to the first simulation
        array_simul_fixed[i_seed].Θ_stor[:,:] = repmat((array_simul_free[i_seed].Θ_stor[1,:])',n_simul,1)

        for t = 2:n_simul
            array_simul_fixed[i_seed].Θ_stor[t,shocked_firm[i_seed,t]] = false
            array_simul_fixed[i_seed].q_stor[t,:] = solveq(array_simul_fixed[i_seed].param,array_simul_fixed[i_seed].z_stor[t,:],array_simul_fixed[i_seed].Θ_stor[t,:],true)
        end
    end

    return array_simul_fixed
end

function multi_seeds_simulations_bailout_cascades_one_shock(array_simul_free,initial_seed,shocked_firm)

    print_with_color(:red, "bailout ",bold=false)
    print_with_color(:green, "network\n\n",bold=true)

    # Prepare a new array of simulation for the output
    number_seeds = length(array_simul_free)
    n_simul = array_simul_free[1].n_simul
    n = array_simul_free[1].param.n

    forced_theta = zeros(Bool,number_seeds,n_simul,n)

    for i_seed=1:number_seeds
        for i_simul=2:n_simul_per_seed
            forced_theta[i_seed,i_simul,shocked_firm_free[i_seed,i_simul]] = true
        end
    end

    simulation_iter_Future = Array{Future,1}((number_seeds,))

    for i = 1:number_seeds
        simulation_iter_Future[i] = @spawn solve_simul_bailouts_one_shock(array_simul_free[i],forced_theta[i,:,:])
    end

    array_simul_bailouts = Array{Simulation}(number_seeds)

    for i = 1:number_seeds
        array_simul_bailouts[i] = fetch(simulation_iter_Future[i])
    end

    return array_simul_bailouts
end



# Looks at the impact of the z shocks when nothing else changes (theta and inputs are the same)
# It directly prints the std of C since that's the only variable of interest here
function multi_seeds_simulations_all_fixed(array_simul_free,initial_seed)

    print_with_color(:green, "\n\nSolving planner's problem ",bold=true)
    print_with_color(:red, "all inputs fixed ",bold=false)
    print_with_color(:green, "network\n\n",bold=true)

    # Prepare a new array of simulation for the output
    array_simul_all_fixed = deepcopy(array_simul_free)
    number_seeds = length(array_simul_all_fixed)

    n_simul = array_simul_all_fixed[1].n_simul
    σ = array_simul_all_fixed[1].param.σ

    C = zeros(number_seeds,n_simul)

    # Go over all the seeds
    for i_seed = 1:number_seeds

        n = array_simul_all_fixed[i_seed].param.n

        # Gather quantities from the FIRST free simulation
        q_temp,y_temp,l_temp,c_temp = compute_firm_char(array_simul_free[i_seed])
        base_y = y_temp[1,:] # Output of all firms in the original free simulation
        base_c = c_temp[1,:] # Consumption of each good in the original free simulation
        base_z = array_simul_free[i_seed].z_stor[1,:]

        # Keep these inputs fixed from now own and compute the new c
        for t = 1:n_simul
            new_z = array_simul_free[i_seed].z_stor[t,:]
            new_y = base_y./base_z.*new_z
            new_c = max.(base_c - base_y + new_y,0)

            C[i_seed,t] = (sum(new_c.^((σ-1)/σ)))^(σ/(σ-1))
        end
    end

    std_C = mean(StatsBase.std(log.(C),2))

    println("STD C for fixed all inputs = $std_C")
end


function solve_simul_bailouts_one_shock(array_simul_free_single,forced_theta)
    array_simul_bailouts_single = deepcopy(array_simul_free_single)
    n_simul_per_seed = array_simul_free_single.n_simul
    for t = 1:n_simul_per_seed
        Θ,flag_error = foc_iterations(array_simul_free_single.param,array_simul_free_single.z_stor[t,:],forced_theta[t,:])
        array_simul_bailouts_single.Θ_stor[t,:] = Θ
        array_simul_bailouts_single.q_stor[t,:] = solveq(array_simul_free_single.param,array_simul_free_single.z_stor[t,:],Θ,true)
        array_simul_bailouts_single.z_stor[t,:] = array_simul_free_single.z_stor[t,:]
    end
    return array_simul_bailouts_single
end
