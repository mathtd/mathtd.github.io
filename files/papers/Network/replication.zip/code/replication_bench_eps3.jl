# This script launch the benchmark simulation from the paper
# Code written for Julia 0.6.4

# if Sys.KERNEL==:Linux
#     addprocs(16)
# else
#     addprocs(4)
# end

addprocs(4)

@everywhere begin
    using Distributions
    using Iterators
    using LightGraphs
    using GLM
    using StatsBase
    using DataFrames

    include("src/creation_network.jl")
    include("src/simulations.jl")
    include("src/solutions.jl")
    include("src/analysis_stats.jl")
    include("src/analysis_graphs.jl")
    include("src/analyze_simulations.jl")
    include("src/analyze_cascades.jl")
end


# Benchmark parametrization
# Number of different parallel simulations to run
number_seeds = 20

# free skew C=0.4295
# free kurt C=0.1889958
# fixed skew C=0.33546
# fixed kurt C=0.08027

# Number of periods for each seed
n_simul_per_seed = 100
initial_seed = 2


# exercise_type determines the type of simulations
# exercise_type = 0: comparison with random network
# exercise_type = 1: one-firm shock to compute cascades
# exercise_type = 2: comparison with network fixed to its t=1 shape
# exercise_type = 3: half of the firms are randomly assigned with 0 fixed cost
# exercise_type = 4: reduce by half the future fixed cost of operating firms
# exercise_type = 5: aggregate shocks of 5%

exercise_type = 2


n = 1000                    # Number of firms
f_size = 0.05               # Share of labor going to fixed cost when all firms operate

std_z = 0.39                # Standard deviation productivity shocks
ρ_z = 0.81                  # Persistence productivity shocks

σ = 5.0                     # Elasticity final goods
ϵ = 3.0                     # Elasticity intermediate inputs
α = 0.5                     # Share of intermediate in production


@everywhere shape = 1.79    # Power law coefficient for distribution of potential connection
@everywhere correl = true   # Allow for correlation between potential firm in-degree and out-degree

# Define a network generator using these parameters
@everywhere network_fct(n_in,seed_in) = scaleFreeNetwork(n_in,seed_in,shape,1,correl)



# Define the Parameters object
param = Parameters(n,f_size/n,std_z,ρ_z,σ,ϵ,α,spzeros(Bool, n, n))

# Directory where to store the results
dir = "bench_eps3"
# Create directory if it does not exist
try
    mkdir("simulated_data/time_series/$dir")
end

# Do the simulations
array_simul_free = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type)
analyze_simulations(array_simul_free,dir,"free",true)


# Now simulate the model with purely random network
# We use the data computed above so that we have the exact same Ω and z for more accurate comparison
array_simul_random = multi_seeds_simulations_random(array_simul_free,initial_seed)
analyze_simulations(array_simul_random,dir,"random",false)
# #
array_simul_fixed = multi_seeds_simulations_fixed(array_simul_free,initial_seed)
analyze_simulations(array_simul_fixed,dir,"fixed",false)
#
# Simulate the same economy but with the x% most connected firms in Ω forced to operate
#
# # Now fix all the inputs and recompute the std of log C
# multi_seeds_simulations_all_fixed(array_simul_free,initial_seed)

# Free added processors
rmprocs(workers());
