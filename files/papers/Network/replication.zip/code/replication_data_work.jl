# This script does all the data work
# It relies on data in csv network in data/Datasets/
# Code written for Julia 0.6.4

using Distributions
using Iterators
using LightGraphs
using GLM
using StatsBase
using DataFrames
using Missings

include("src/analyze_cascades.jl")
include("src/analyze_data.jl")
include("src/simulations.jl")
include("src/analysis_stats.jl")
include("src/analysis_graphs.jl")

cd("data_work")

# Uncomment the dataset to use

# dir = "Factset_Revere_diff_zipcode"
dir = "Factset_Revere_without_mergers"

compute_moments_networks(dir)
compute_cascades_data(dir)

dir = "AHRS"
compute_moments_networks(dir)

dir = "CohenFrazzini"
compute_moments_networks(dir)

cd("..")
