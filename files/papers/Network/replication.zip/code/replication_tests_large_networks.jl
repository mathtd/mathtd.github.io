# This script tests the solution approach
# This code was built for Julia 0.6.4

# Add processors for parallel computing
if Sys.KERNEL==:Linux
    addprocs(16)
else
    addprocs(4)
end

addprocs(60)

@everywhere using Distributions
@everywhere using Base.Iterators

@everywhere include("src/creation_network.jl")
@everywhere include("src/simulations.jl")
@everywhere include("src/solutions.jl")
@everywhere include("src/testing_large.jl")


# Define parameters of the simulation
number_seeds = 100

# Number of periods for each seed
n_simul_per_seed = 100
initial_seed = 2

# exercise_type determines the type of simulations
# exercise_type = 0: comparison with random network
# exercise_type = 1: one-firm shock to compute cascades
# exercise_type = 2: comparison with network fixed to its t=1 shape
# exercise_type = 3: half of the firms are randomly assigned with 0 fixed cost
# exercise_type = 4: reduce by half the future fixed cost of operating firms
# exercise_type = 5: aggregate shocks of 5%

# exercise_type = 0 and exercise_type = 2 are fine here (no network comparison)
exercise_type = 2


n = 1000                    # Number of firms
f_size = 0.05               # Share of labor going to fixed cost when all firms operate

std_z = 0.39                # Standard deviation productivity shocks
ρ_z = 0.81                  # Persistence productivity shocks

σ = 5.0                     # Elasticity final goods
ϵ = 5.0                     # Elasticity intermediate inputs
α = 0.5                     # Share of intermediate in production


@everywhere shape = 1.79    # Power law coefficient for distribution of potential connection
@everywhere correl = true   # Allow for correlation between potential firm in-degree and out-degree

# Define a network generator using these parameters
@everywhere network_fct(n_in,seed_in) = scaleFreeNetwork(n_in,seed_in,shape,1,correl)

# Define the Parameters object
param = Parameters(n,f_size/n,std_z,ρ_z,σ,ϵ,α,spzeros(Bool, n, n))

# Directory where to store the results
dir = "bench"
# Create directory if it does not exist
try
    mkdir("simulated_data/time_series/$dir")
end

# Do the simulations with reshaping
reshaping = true
allow_error = false
array_simul_reshaping = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type,zeros(Bool,number_seeds,n_simul_per_seed,param.n),reshaping,allow_error)

outcome_test = find_1dev(array_simul_reshaping)

println("Testing for 1dev with reshaping keep only convergence on {0,1}^n")
println("  mean nb_deviation = $(outcome_test[1])")
println("  mean fraction_error_theta = $(outcome_test[2])")
println("  mean change_in_C = $(outcome_test[3])")

# Do the simulations without reshaping
reshaping = false
allow_error = false
array_simul_noreshaping = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type,zeros(Bool,number_seeds,n_simul_per_seed,param.n),reshaping,allow_error)

outcome_test = find_1dev(array_simul_noreshaping)

println("Testing for 1dev with no reshaping keep only convergence on {0,1}^n")
println("  mean nb_deviation = $(outcome_test[1])")
println("  mean fraction_error_theta = $(outcome_test[2])")
println("  mean change_in_C = $(outcome_test[3])")



# Do the simulations with reshaping but keeping all solutions
reshaping = true
allow_error = true
array_simul_reshaping = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type,zeros(Bool,number_seeds,n_simul_per_seed,param.n),reshaping,allow_error)

outcome_test = find_1dev(array_simul_reshaping)

println("Testing for 1dev with reshaping keep all solutions")
println("  mean nb_deviation = $(outcome_test[1])")
println("  mean fraction_error_theta = $(outcome_test[2])")
println("  mean change_in_C = $(outcome_test[3])")

# Do the simulations without reshaping but keeping all solutions
reshaping = false
allow_error = true
array_simul_noreshaping = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type,zeros(Bool,number_seeds,n_simul_per_seed,param.n),reshaping,allow_error)

outcome_test = find_1dev(array_simul_noreshaping)

println("Testing for 1dev with no reshaping keep all solutions")
println("  mean nb_deviation = $(outcome_test[1])")
println("  mean fraction_error_theta = $(outcome_test[2])")
println("  mean change_in_C = $(outcome_test[3])")


# Remove processors if using parallel conputing
rmprocs(workers());
