# This script launch the benchmark simulation from the paper
# and run the cascades_one_shock exercise
# Code written for Julia 0.6.4

# if Sys.KERNEL==:Linux
#     addprocs(16)
# else
#     addprocs(4)
# end

addprocs(60)


@everywhere begin
    using Distributions
    using Iterators
    using LightGraphs
    using GLM
    using StatsBase
    using DataFrames

    include("src/creation_network.jl")
    include("src/simulations.jl")
    include("src/solutions.jl")
    include("src/analysis_stats.jl")
    include("src/analysis_graphs.jl")
    include("src/analyze_simulations.jl")
    include("src/analyze_cascades_one_shock.jl")
end


# Benchmark parametrization
# Number of different parallel simulations to run
number_seeds = 100


# Number of periods for each seed
n_simul_per_seed = 1000
initial_seed = 2




# exercise_type determines the type of simulations
# exercise_type = 0: comparison with random network
# exercise_type = 1: one-firm shock to compute cascades
# exercise_type = 2: comparison with network fixed to its t=1 shape
# exercise_type = 3: half of the firms are randomly assigned with 0 fixed cost
# exercise_type = 4: reduce by half the future fixed cost of operating firms
# exercise_type = 5: aggregate shocks of 5%

exercise_type = 1

#=
n = 1000                    # Number of firms
f_size = 0.05               # Share of labor going to fixed cost when all firms operate

std_z = 0.39                # Standard deviation productivity shocks
ρ_z = 0.81                  # Persistence productivity shocks

σ = 5.0                     # Elasticity final goods
ϵ = 5.0                     # Elasticity intermediate inputs
α = 0.5                     # Share of intermediate in production


@everywhere shape = 1.79    # Power law coefficient for distribution of potential connection
@everywhere correl = true   # Allow for correlation between potential firm in-degree and out-degree

# Define a network generator using these parameters
@everywhere network_fct(n_in,seed_in) = scaleFreeNetwork(n_in,seed_in,shape,1,correl)


# Define the Parameters object
param = Parameters(n,f_size/n,std_z,ρ_z,σ,ϵ,α,spzeros(Bool, n, n))

# Directory where to store the results
dir = "bench_cascades_one_shock"
# Create directory if it does not exist
try
    mkdir("simulated_data/time_series/$dir")
end

# Do the simulations
array_simul_free = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type)

C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul_free)
array_networks = build_graph(array_simul_free)
indeg,outdeg = compute_network_firm_char(array_networks)
drop_in_C_free,indeg_free,outdeg_free,shocked_firm_free = analyze_cascades_one_shock(array_simul_free,C,indeg,outdeg,"simulated_data/time_series/$dir","free")


# Forcing all firms to stay in same status (except shocked firm)
array_simul_fixed = multi_seeds_simulations_fixed_cascades_one_shock(array_simul_free,initial_seed,shocked_firm_free)

C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul_fixed)
array_networks = build_graph(array_simul_fixed)
indeg,outdeg = compute_network_firm_char(array_networks)
drop_in_C_fixed,indeg_fixed,outdeg_fixed,shocked_firm_fixed = analyze_cascades_one_shock(array_simul_fixed,C,indeg,outdeg,"simulated_data/time_series/$dir","fixed")


# Bailing out the shocked firm

array_simul_bailouts = multi_seeds_simulations_bailout_cascades_one_shock(array_simul_free,initial_seed,shocked_firm_free)
C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul_bailouts)
array_networks = build_graph(array_simul_bailouts)
indeg,outdeg = compute_network_firm_char(array_networks)
drop_in_C_bailedout,indeg_bailedout,outdeg_bailedout,shocked_firm_bailedout = analyze_cascades_one_shock(array_simul_bailouts,C,indeg,outdeg,"simulated_data/time_series/$dir","bailouts")
=#
#=

# Compare cascades in free and fixed

# Remove the useless first row

drop_in_C_free_vert = (drop_in_C_free[1:number_seeds,2:n_simul_per_seed])[:]
indeg_free_vert = (indeg_free[1:number_seeds,2:n_simul_per_seed])[:]
outdeg_free_vert = (outdeg_free[1:number_seeds,2:n_simul_per_seed])[:]

drop_in_C_fixed_vert = (drop_in_C_fixed[1:number_seeds,2:n_simul_per_seed])[:]
indeg_fixed_vert = (indeg_fixed[1:number_seeds,2:n_simul_per_seed])[:]
outdeg_fixed_vert = (outdeg_fixed[1:number_seeds,2:n_simul_per_seed])[:]

drop_in_C_bailedout_vert = (drop_in_C_bailedout[1:number_seeds,2:n_simul_per_seed])[:]
indeg_bailedout_vert = (indeg_bailedout[1:number_seeds,2:n_simul_per_seed])[:]
outdeg_bailedout_vert = (outdeg_bailedout[1:number_seeds,2:n_simul_per_seed])[:]

# Define threshold
pct_thresh = 90
thresh_indeg  = percentile(indeg_fixed_vert,pct_thresh)
thresh_outdeg  = percentile(outdeg_fixed_vert,pct_thresh)
thresh_deg  = percentile(indeg_fixed_vert + outdeg_fixed_vert,pct_thresh)

vpct_thresh = 99
vthresh_indeg  = percentile(indeg_fixed_vert,vpct_thresh)
vthresh_outdeg  = percentile(outdeg_fixed_vert,vpct_thresh)
vthresh_deg  = percentile(indeg_fixed_vert + outdeg_fixed_vert,vpct_thresh)

ratio_drop_in_C = drop_in_C_fixed_vert./drop_in_C_free_vert


degree = indeg_fixed_vert + outdeg_fixed_vert

println("Drop in C all firms mean = $(mean(ratio_drop_in_C))")
println("Drop in C all firms median = $(median(ratio_drop_in_C))")
println("Drop in C for high degree firms = $(mean(ratio_drop_in_C[degree.>thresh_deg]))")
println("Drop in C for vhigh degree firms = $(mean(ratio_drop_in_C[degree.>vthresh_deg]))")
println("Drop in C for high indegree firms = $(mean(ratio_drop_in_C[indeg_fixed_vert.>thresh_indeg]))")
println("Drop in C for vhigh indegree firms = $(mean(ratio_drop_in_C[indeg_fixed_vert.>vthresh_indeg]))")
println("Drop in C for high outdegree firms = $(mean(ratio_drop_in_C[outdeg_fixed_vert.>thresh_outdeg]))")
println("Drop in C for vhigh outdegree firms = $(mean(ratio_drop_in_C[outdeg_fixed_vert.>vthresh_outdeg]))")

=#

# We now repeat the same exercise but with ϵ = 3
println("Benchmark economy except for ϵ = 3")

n = 1000                    # Number of firms
f_size = 0.05               # Share of labor going to fixed cost when all firms operate

std_z = 0.39                # Standard deviation productivity shocks
ρ_z = 0.81                  # Persistence productivity shocks

σ = 5.0                     # Elasticity final goods
ϵ = 3.0                     # Elasticity intermediate inputs
α = 0.5                     # Share of intermediate in production


@everywhere shape = 1.79    # Power law coefficient for distribution of potential connection
@everywhere correl = true   # Allow for correlation between potential firm in-degree and out-degree

# Define a network generator using these parameters
@everywhere network_fct(n_in,seed_in) = scaleFreeNetwork(n_in,seed_in,shape,1,correl)


# Define the Parameters object
param = Parameters(n,f_size/n,std_z,ρ_z,σ,ϵ,α,spzeros(Bool, n, n))

# Directory where to store the results
dir = "bench_eps3_cascades_one_shock"
# Create directory if it does not exist
try
    mkdir("simulated_data/time_series/$dir")
end

# Do the simulations
array_simul_free = multi_seeds_simulations(param,network_fct,number_seeds,n_simul_per_seed,initial_seed,exercise_type)

C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul_free)
array_networks = build_graph(array_simul_free)
indeg,outdeg = compute_network_firm_char(array_networks)
drop_in_C_free,indeg_free,outdeg_free,shocked_firm_free = analyze_cascades_one_shock(array_simul_free,C,indeg,outdeg,"simulated_data/time_series/$dir","free")

# Forcing all firms to stay in same status (except shocked firm)
array_simul_fixed = multi_seeds_simulations_fixed_cascades_one_shock(array_simul_free,initial_seed,shocked_firm_free)

C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul_fixed)
array_networks = build_graph(array_simul_fixed)
indeg,outdeg = compute_network_firm_char(array_networks)
drop_in_C_fixed,indeg_fixed,outdeg_fixed,shocked_firm_fixed = analyze_cascades_one_shock(array_simul_fixed,C,indeg,outdeg,"simulated_data/time_series/$dir","fixed")

# Bailing out the shocked firm
array_simul_bailouts = multi_seeds_simulations_bailout_cascades_one_shock(array_simul_free,initial_seed,shocked_firm_free)
C,Q,sumΘ,L_less_f = compute_business_cycles_aggregate(array_simul_bailouts)
array_networks = build_graph(array_simul_bailouts)
indeg,outdeg = compute_network_firm_char(array_networks)
drop_in_C_bailedout,indeg_bailedout,outdeg_bailedout,shocked_firm_bailedout = analyze_cascades_one_shock(array_simul_bailouts,C,indeg,outdeg,"simulated_data/time_series/$dir","bailouts")


#=
# Compare cascades in free and fixed

# Remove the useless first row
drop_in_C_free_vert = (drop_in_C_free[1:number_seeds,2:n_simul_per_seed])[:]
indeg_free_vert = (indeg_free[1:number_seeds,2:n_simul_per_seed])[:]
outdeg_free_vert = (outdeg_free[1:number_seeds,2:n_simul_per_seed])[:]

drop_in_C_fixed_vert = (drop_in_C_fixed[1:number_seeds,2:n_simul_per_seed])[:]
indeg_fixed_vert = (indeg_fixed[1:number_seeds,2:n_simul_per_seed])[:]
outdeg_fixed_vert = (outdeg_fixed[1:number_seeds,2:n_simul_per_seed])[:]

# Define threshold
pct_thresh = 90
thresh_indeg  = percentile(indeg_fixed_vert,pct_thresh)
thresh_outdeg  = percentile(outdeg_fixed_vert,pct_thresh)
thresh_deg  = percentile(indeg_fixed_vert + outdeg_fixed_vert,pct_thresh)

vpct_thresh = 99
vthresh_indeg  = percentile(indeg_fixed_vert,vpct_thresh)
vthresh_outdeg  = percentile(outdeg_fixed_vert,vpct_thresh)
vthresh_deg  = percentile(indeg_fixed_vert + outdeg_fixed_vert,vpct_thresh)

ratio_drop_in_C = drop_in_C_fixed_vert./drop_in_C_free_vert


degree = indeg_fixed_vert + outdeg_fixed_vert

println("Drop in C all firms mean = $(mean(ratio_drop_in_C))")
println("Drop in C all firms median = $(median(ratio_drop_in_C))")
println("Drop in C for high degree firms = $(mean(ratio_drop_in_C[degree.>thresh_deg]))")
println("Drop in C for vhigh degree firms = $(mean(ratio_drop_in_C[degree.>vthresh_deg]))")
println("Drop in C for high indegree firms = $(mean(ratio_drop_in_C[indeg_fixed_vert.>thresh_indeg]))")
println("Drop in C for vhigh indegree firms = $(mean(ratio_drop_in_C[indeg_fixed_vert.>vthresh_indeg]))")
println("Drop in C for high outdegree firms = $(mean(ratio_drop_in_C[outdeg_fixed_vert.>thresh_outdeg]))")
println("Drop in C for vhigh outdegree firms = $(mean(ratio_drop_in_C[outdeg_fixed_vert.>vthresh_outdeg]))")
=#

# Free added processors
rmprocs(workers());
