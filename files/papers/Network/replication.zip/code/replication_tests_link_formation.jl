# This script tests the solution approach for networks with individual link formation
# This code was built for Julia 0.6.4

# Add processors for parallel computing
if Sys.KERNEL==:Linux
    addprocs(16)
else
    addprocs(4)
end

# addprocs(40)

@everywhere using Distributions
@everywhere using Base.Iterators
@everywhere using LightGraphs

@everywhere include("src/creation_network.jl")
@everywhere include("src/solutions_hetero.jl")
@everywhere include("src/testing_links.jl")


# Define parameters of the simulation

nb_sim_per_trials = 500

# Aggregate variables
f_firm_vec = [0.00]                 # Fixed cost for real firms
p_link_vec = [1.0]                  # Probability of a link-firm in Ω between any two real firms
std_firm_vec = [0.25]               # STDEV z for real firms
std_link_vec = [0.25]               # STDEV z for link firms
α_firm_vec = [0.5]                  # α for real firms
ϵ_vec = [6]                         # ϵ for real firms
σ_vec = [6]

# Link variables
f_link_lb = 0.0                     # lower bound uniorm draws f for links
f_link_ub = 0.1                     # upper bound uniorm draws f for links

α_link_lb = 0.5                     # lower bound uniorm draws α for links
α_link_ub = 1.0                     # upper bound uniorm draws α for links

println("Parameters of simulations")
println("  nb_sim_per_trials = $nb_sim_per_trials")
println("  f_firm_vec        = $f_firm_vec")
println("  p_link_vec        = $p_link_vec")
println("  std_firm_vec      = $std_firm_vec")
println("  std_link_vec      = $std_link_vec")
println("  α_firm_vec        = $α_firm_vec")
println("  ϵ_vec             = $ϵ_vec")
println("  σ_vec             = $σ_vec")
println("  f_link_lb         = $f_link_lb")
println("  f_link_ub         = $f_link_ub")
println("  α_link_lb         = $α_link_lb")
println("  α_link_ub         = $α_link_ub")


#
println("Replication Table 10 - Individual link formation - Small networks")
#
n = 3
series_of_test(n,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,false)

n = 4
series_of_test(n,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,false)

n = 5
series_of_test(n,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,false)
#
#
println("Replication Tables 11 and 12 - Individual link formation - Large networks")
#
n = 10
series_of_test(n,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,true)

n = 25
series_of_test(n,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,true)

n = 40
series_of_test(n,nb_sim_per_trials,f_firm_vec,f_link_lb,f_link_ub,α_firm_vec,α_link_lb,α_link_ub,ϵ_vec,σ_vec,std_firm_vec,std_link_vec,p_link_vec,true)



# Remove processors if using parallel conputing
rmprocs(workers());
