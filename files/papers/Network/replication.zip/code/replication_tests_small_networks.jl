# This script tests the solution approach
# This code was built for Julia 0.6.4

# Add processors for parallel computing
# if Sys.KERNEL==:Linux
#     addprocs(16)
# else
#     addprocs(4)
# end

addprocs(60)

@everywhere using Distributions
@everywhere using Base.Iterators

@everywhere include("src/creation_network.jl")
@everywhere include("src/solutions_hetero.jl")
@everywhere include("src/testing_small.jl")


# Define parameters of the simulation

nb_sim_per_trials = 500

# f, ϵ, α, β and Ω are drawn from uniform distribution with the following bounds

f_lb = 0.0
f_ub = 0.2

ϵ_lb = 4
ϵ_ub = 8

α_lb = 0.25
α_ub = 0.75

β_lb = 0.0
β_ub = 1.0

Ω_lb = 0.0
Ω_ub = 1.0


std_z_vec = [0.25]

# # Replicate Table 1 in the paper
# # Note the numbers are not exactly the same because of speed improvements in the algorithm have effectively changed the random seed

println("Replication Table 1 and Table 7 - Benchmark")

σ_vec = [4,6,8]

n = 8
network_vec = [randomNetwork3_nodiag,randomNetwork4_nodiag,randomNetwork5_nodiag,randomNetwork6_nodiag,randomNetwork7_nodiag,randomNetwork8_nodiag]
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 10
network_vec = [randomNetwork3_nodiag,randomNetwork4_nodiag,randomNetwork5_nodiag,randomNetwork6_nodiag,randomNetwork7_nodiag,randomNetwork8_nodiag,randomNetwork9_nodiag,randomNetwork10_nodiag]
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 12
network_vec = [randomNetwork3_nodiag,randomNetwork4_nodiag,randomNetwork5_nodiag,randomNetwork6_nodiag,randomNetwork7_nodiag,randomNetwork8_nodiag,randomNetwork9_nodiag,randomNetwork10_nodiag,randomNetwork10_nodiag,randomNetwork12_nodiag]
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 14
network_vec = [randomNetwork3_nodiag,randomNetwork4_nodiag,randomNetwork5_nodiag,randomNetwork6_nodiag,randomNetwork7_nodiag,randomNetwork8_nodiag,randomNetwork9_nodiag,randomNetwork10_nodiag,randomNetwork10_nodiag,randomNetwork12_nodiag,randomNetwork13_nodiag,randomNetwork14_nodiag]
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)


println("Replication Table X - Sparse Ω")

network_vec = [randomNetwork1_nodiag,randomNetwork2_nodiag]
σ_vec = [4,6,8]

n = 8
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 10
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 12
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)

n = 14
series_of_test(n,nb_sim_per_trials,f_lb,f_ub,ϵ_lb,ϵ_ub,α_lb,α_ub,β_lb,β_ub,Ω_lb,Ω_ub,network_vec,std_z_vec,σ_vec)




# Remove processors if using parallel conputing
rmprocs(workers());
